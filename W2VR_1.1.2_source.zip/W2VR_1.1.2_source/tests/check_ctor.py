# GOG build: the frame-info constructor gets `this` in ECX (and two extra stack arguments, ret 0Ch). The compiled ECX
# thunk must report that `this` to w2vr_NoteFrameInfo and then enter the constructor exactly as the game called it:
# every register and the stack unchanged. Checked with a recording stand-in for the constructor; the real constructor's
# convention is checked from its code (mov edi, ecx at the start; ret 0Ch).
import sys, os, struct
HERE = os.path.dirname(os.path.abspath(__file__))
STEAM = len(sys.argv) > 1 and sys.argv[1] == 'steam'
src = open(os.path.join(HERE, 'check_dll_hook.py' if STEAM else 'check_dll_hook_gog.py')).read().split("P = 0x10070000")[0]
exec(src)
CTOR = 0xAA43A0 if STEAM else 0xAF844B
fails = []
code = bytes(mu.mem_read(CTOR, 0x200))
if not STEAM and b'\x8b\xf9' not in code[:0x10]: fails.append('the GOG constructor does not take this in ECX')
if STEAM and b'\x8b\xf9' in code[:0x10]: fails.append('the Steam constructor should take this in EDI')
ORIG = syms['_g_w2InfoCtorOrig']; THUNK = syms['_W2InfoCtorThunk' if STEAM else '_W2InfoCtorThunkEcx']; NOTE = syms['_w2vr_NoteFrameInfo']
REC = 0x10060000; OUT = 0x10061000
# recorder: store eax ecx edx ebx esi edi esp [esp+4] [esp+8] [esp+12], then ret 0Ch
rec = b''
for i, r in enumerate((0xA3, None, None, None, None, None)): pass
asm = bytes.fromhex('a3' + struct.pack('<I', OUT).hex() + '890d' + struct.pack('<I', OUT + 4).hex() + '8915' + struct.pack('<I', OUT + 8).hex() +
                    '891d' + struct.pack('<I', OUT + 12).hex() + '8935' + struct.pack('<I', OUT + 16).hex() + '893d' + struct.pack('<I', OUT + 20).hex() +
                    '8925' + struct.pack('<I', OUT + 24).hex() + ('c20400' if STEAM else 'c20c00'))
mu.mem_write(REC, asm); mu.mem_write(ORIG, struct.pack('<I', REC))
seen = []
mu.hook_add(UC_HOOK_CODE, lambda uc, a, s, d: seen.append(struct.unpack('<I', uc.mem_read(uc.reg_read(UC_X86_REG_ESP) + 4, 4))[0]), begin=NOTE, end=NOTE)
OBJ, INFO = 0x100B0000, 0x100B8000
THIS_ECX, THIS_EDI = (0xC0C0C0C0, OBJ) if STEAM else (OBJ, 0x33333333)
regs = {UC_X86_REG_EAX: 0xA0A0A0A0, UC_X86_REG_ECX: THIS_ECX, UC_X86_REG_EDX: 0xD0D0D0D0, UC_X86_REG_EBX: 0x11111111, UC_X86_REG_ESI: 0x22222222, UC_X86_REG_EDI: THIS_EDI}
ARGS = (INFO,) if STEAM else (INFO, 1, 0)
for align in (0, 4, 8, 12):
    seen.clear()
    sp_after = run(THUNK, ARGS, regs=regs, align=align)
    got = struct.unpack('<7I', mu.mem_read(OUT, 28))
    entry_sp = sp_after - 4 - 4 * len(ARGS)   # return address + arguments
    if got[:6] != (0xA0A0A0A0, THIS_ECX, 0xD0D0D0D0, 0x11111111, 0x22222222, THIS_EDI): fails.append('registers changed on the way in (%d)' % align)
    if got[6] != entry_sp: fails.append('stack changed on the way in (%d)' % align)
    if mu.reg_read(UC_X86_REG_ESP) != sp_after: fails.append('stack after return (%d)' % align)
    if seen != [OBJ]: fails.append('this not reported (%s)' % seen)
print(('EDI' if STEAM else 'ECX') + ' thunk: this reported, constructor entered with every register and the stack as the game left them (4 alignments)')
print('RESULT:', 'FAIL ' + '; '.join(sorted(set(fails))) if fails else 'PASS'); sys.exit(1 if fails else 0)

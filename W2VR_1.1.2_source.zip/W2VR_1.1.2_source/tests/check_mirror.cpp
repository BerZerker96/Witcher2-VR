// check_mirror.cpp - src/w2mirror.h: keys a controller tool sends with a pad button are hidden; typed keys are not.
#include "../src/w2mirror.h"
#include <cstdio>
static int fails = 0;
static void check(bool c, const char* m) { printf("%s: %s\n", c ? "ok  " : "FAIL", m); if (!c) fails++; }
int main() {
    const uint16_t SQUARE = 1 << 14, CROSS = 1 << 12, RT = 0;   // XINPUT_GAMEPAD_X / A
    const int K0 = 0x0B, KR = 0x13;
    {   // the user's case: every Square press also sends "0"
        w2mirror::Learner L; int hidden = 0, nb;
        for (int i = 0; i < 50; i++) hidden += L.Press(K0, SQUARE, &nb);
        check(hidden == 49, "Square + 0: only the first press reaches the game");
        check(L.learned[K0] == SQUARE, "learned for Square only");
        check(!L.Press(K0, 0, &nb), "0 typed on the keyboard alone still works");
        check(!L.Press(K0, CROSS, &nb), "0 with another button (Cross) still works");
    }
    {   // a keyboard player who sometimes holds a pad button: not learned
        w2mirror::Learner L; int hidden = 0, nb;
        for (int i = 0; i < 100; i++) hidden += L.Press(KR, (i % 4 == 0) ? CROSS : 0, &nb);
        check(hidden == 0 && L.learned[KR] == 0, "a key pressed with a button only 25 % of the time is never hidden");
    }
    {   // pad + keyboard player who presses R while holding a button 2 times in a row, then mostly alone
        w2mirror::Learner L; int nb; L.Press(KR, CROSS, &nb); L.Press(KR, CROSS, &nb);
        check(L.learned[KR] == CROSS, "two presses in a row with Cross: learned (it is then only hidden WITH Cross)");
        int typed = 0; for (int i = 0; i < 20; i++) typed += !L.Press(KR, 0, &nb);
        check(typed == 20, "and typed alone it is never hidden");
    }
    {   // preset from the config: hidden from the first press, but only with a button
        w2mirror::Learner L; int nb; L.preset[K0] = true;
        check(L.Press(K0, SQUARE, &nb), "keyboard_pad_mirror_keys = 0B: first press with Square hidden");
        check(!L.Press(K0, 0, &nb), "preset key typed alone still works");
    }
    (void)RT;
    printf("RESULT: %s\n", fails ? "FAIL" : "PASS");
    return fails ? 1 : 0;
}

# Mash QTEs (src/w2qte.cpp): the compiled locator finds CQTEMash::Update in each build, and - on the Steam build - the
# game's own update code, run in an emulator, gives every press the same worth at 30, 60, 90, 144 fps and in same-tick
# stereo once the mod's hook is in front of it (without it, a press is worth less the higher the frame rate).
#   python3 check_qte.py <witcher2.exe> steam|gog
import sys, os, struct, subprocess, pefile
from unicorn import *
from unicorn.x86_const import *
EXE, WHICH = sys.argv[1], sys.argv[2]   # WHICH: steam | gog
HERE = os.path.dirname(os.path.abspath(__file__)); DLL = os.path.join(HERE, '..', 'build', 'xinput1_3.dll')
pe = pefile.PE(EXE); D = open(EXE, 'rb').read()
mu = Uc(UC_ARCH_X86, UC_MODE_32)
mu.mem_map(0x400000, (pe.OPTIONAL_HEADER.SizeOfImage + 0xFFFF) & ~0xFFFF)
mu.mem_write(0x400000, D[:pe.OPTIONAL_HEADER.SizeOfHeaders])
for s in pe.sections: mu.mem_write(0x400000 + s.VirtualAddress, D[s.PointerToRawData:s.PointerToRawData + s.SizeOfRawData])
pd = pefile.PE(DLL); IBD = pd.OPTIONAL_HEADER.ImageBase
mu.mem_map(IBD, (pd.OPTIONAL_HEADER.SizeOfImage + 0xFFF) & ~0xFFF)
for s in pd.sections: mu.mem_write(IBD + s.VirtualAddress, s.get_data())
STUB = 0x7F000000; mu.mem_map(STUB, 0x10000); mu.mem_map(0x10000000, 0x100000)
asm = {'GetModuleHandleW': b'\xb8\x00\x00\x40\x00\xc2\x04\x00',
       'strtoul': b'\x56\x8b\x74\x24\x08\x31\xc0\xb9\x02\x00\x00\x00\x0f\xb6\x16\x80\xfa\x39\x7e\x03\x80\xc2\x09\x83\xe2\x0f\xc1\xe0\x04\x09\xd0\x46\x49\x75\xeb\x5e\xc3',
       'memcmp': b'\x56\x57\x8b\x74\x24\x0c\x8b\x7c\x24\x10\x8b\x4c\x24\x14\x31\xc0\xe3\x0c\xf3\xa6\x74\x08\x0f\xb6\x46\xff\x0f\xb6\x4f\xff\x29\xc8\x5f\x5e\xc3',
       'memcpy': b'\x56\x57\x8b\x7c\x24\x0c\x8b\x74\x24\x10\x8b\x4c\x24\x14\x89\xf8\xf3\xa4\x5f\x5e\xc3',
       'sprintf': None}
missing = {}
k = 0
for e in pd.DIRECTORY_ENTRY_IMPORT:
    for imp in e.imports:
        a = STUB + k * 0x40; k += 1
        nm = imp.name.decode() if imp.name else '#%d' % imp.ordinal
        code = asm.get(nm) or b'\xcc'
        mu.mem_write(a, code); mu.mem_write(imp.address, struct.pack('<I', a)); missing[a] = nm
exp = {x.ordinal: IBD + x.address for x in pd.DIRECTORY_ENTRY_EXPORT.symbols}
# heap for std::string / vector: a bump allocator for operator new / malloc
HEAP = [0x20000000]; mu.mem_map(0x20000000, 0x4000000)
def hook_code(uc, addr, size, ud):
    nm = missing.get(addr)
    if nm is None: return
    esp = uc.reg_read(UC_X86_REG_ESP); ret = struct.unpack('<I', uc.mem_read(esp, 4))[0]
    def arg(i): return struct.unpack('<I', uc.mem_read(esp + 4 + 4 * i, 4))[0]
    if nm in ('_Znwj', 'malloc', 'operator new'):
        n = (arg(0) + 15) & ~15; p = HEAP[0]; HEAP[0] += n; uc.reg_write(UC_X86_REG_EAX, p)
    elif nm in ('_ZdlPv', '_ZdlPvj', 'free'): uc.reg_write(UC_X86_REG_EAX, 0)
    elif nm in ('memmove', 'memcpy'):
        d, s_, n = arg(0), arg(1), arg(2); uc.mem_write(d, bytes(uc.mem_read(s_, n))); uc.reg_write(UC_X86_REG_EAX, d)
    elif nm == 'sprintf':
        buf, fmt, v = arg(0), arg(1), arg(2); s = b'%02X ' % (v & 0xff); uc.mem_write(buf, s + b'\0'); uc.reg_write(UC_X86_REG_EAX, len(s))
    elif nm == 'strlen':
        p = arg(0); n = 0
        while uc.mem_read(p + n, 1) != b'\0': n += 1
        uc.reg_write(UC_X86_REG_EAX, n)
    elif nm in asm and asm[nm]: return
    else:
        raise SystemExit('unhandled import ' + nm)
    uc.reg_write(UC_X86_REG_ESP, esp + 4); uc.reg_write(UC_X86_REG_EIP, ret)
mu.hook_add(UC_HOOK_CODE, hook_code, begin=STUB, end=STUB + 0x10000)
TRACE = []
def tr(uc, addr, size, ud):
    TRACE.append(addr)
    if len(TRACE) > 4000: del TRACE[:2000]
if os.environ.get('TRACE'): mu.hook_add(UC_HOOK_CODE, tr, begin=IBD, end=IBD + 0x1000000)

import subprocess
EXPECT = {'steam': 0x94b5d8, 'gog': 0x5ec528}[WHICH]
RET = 0x10000000; mu.mem_write(RET, b'\xf4')
def call(addr, ecx=0, args=(), floats=()):
    sp = 0x100f0000
    for v in reversed(list(args)): sp -= 4; mu.mem_write(sp, struct.pack('<I', v))
    for f in reversed(list(floats)): sp -= 4; mu.mem_write(sp, struct.pack('<f', f))
    sp -= 4; mu.mem_write(sp, struct.pack('<I', RET))
    mu.reg_write(UC_X86_REG_ESP, sp); mu.reg_write(UC_X86_REG_ECX, ecx); mu.reg_write(UC_X86_REG_EDX, 0)
    mu.emu_start(addr, RET)
    return mu.reg_read(UC_X86_REG_EAX)
fails = 0
got = call(exp[208])
print('locate: CQTEMash::Update at %x (expected %x)' % (0x400000 + got if got else 0, EXPECT))
if not got or 0x400000 + got != EXPECT: fails += 1; print('FAIL: locator')
if WHICH == 'steam':
    nm = subprocess.run(['i686-w64-mingw32-nm', '-C', DLL], capture_output=True, text=True).stdout
    sym = {}
    for line in nm.splitlines():
        p = line.split(None, 2)
        if len(p) == 3:
            if 'hMash' in p[2]: sym['h'] = int(p[0], 16)
            if p[2].endswith('::oMash'): sym['o'] = int(p[0], 16)
            if p[2].endswith('::g_refDt'): sym['ref'] = int(p[0], 16)
    mu.mem_write(sym['o'], struct.pack('<I', EXPECT))              # the hook calls the game function directly
    FAKE = 0x10040000
    mu.mem_write(0x1404950, b'\0' * 4)                              # no "easy QTE" mode
    mu.mem_write(0x160c6dc, struct.pack('<I', FAKE + 0x800))        # engine object: +14h measured fps
    mu.mem_write(0x41216e, b'\xc2\x0c\x00')                         # the press event / sound: not needed here
    def run(fps, hooked, same_tick=False, presses_per_s=10.0, seconds=1.0):
        OBJ = FAKE
        mu.mem_write(OBJ, b'\0' * 0x80)
        mu.mem_write(FAKE + 0x800 + 0x14, struct.pack('<f', fps * (2 if same_tick else 1)))
        mu.mem_write(OBJ + 0x28, struct.pack('<fff', 0.2, 0.1, 6.0))   # decay / s, gain / press, m_maxSpeed / s
        tick_hz = fps * (2 if same_tick else 1)
        n = int(seconds * tick_hz); t = 0.0; next_press = 0.0; pending = 0
        for i in range(n):
            frozen = same_tick and (i & 1)
            dt = 1e-5 if frozen else (2.0 / tick_hz if same_tick else 1.0 / tick_hz)
            t = (i + 1) / tick_hz
            while next_press < t - 1e-9 and next_press < seconds - 1e-6: pending += 1; next_press += 1.0 / presses_per_s
            if not frozen or not hooked:      # with the mod, presses reach the game on real ticks only (latch)
                mu.mem_write(OBJ + 0x38, struct.pack('<I', pending)); pending = 0
            else: mu.mem_write(OBJ + 0x38, struct.pack('<I', 0))
            call(sym['h'] if hooked else EXPECT, ecx=OBJ, floats=(dt,))
        return struct.unpack('<f', mu.mem_read(OBJ + 0x34, 4))[0]
    ref = run(30, False)
    print('plain game at 30 fps: %.3f progress after 1 s of mashing (10 presses / s)' % ref)
    for fps in (60, 72, 90, 120, 144):
        plain, fixed = run(fps, False), run(fps, True)
        st_plain, st_fixed = run(fps, False, True), run(fps, True, True)
        print('%3d fps: plain %.3f, with W2VR %.3f | same-tick plain %.3f, with W2VR %.3f' % (fps, plain, fixed, st_plain, st_fixed))
        if abs(fixed - ref) > 0.06 or abs(st_fixed - ref) > 0.06: fails += 1; print('FAIL: %d fps not like 30 fps' % fps)
        if fps >= 90 and plain > ref * 0.7: fails += 1; print('FAIL: model does not show the plain game problem')
    # no presses: decay only, identical with and without the hook
    def idle(hooked):
        mu.mem_write(FAKE, b'\0' * 0x80); mu.mem_write(FAKE + 0x28, struct.pack('<ffff', 0.2, 0.1, 6.0, 0.5))
        for i in range(90): call(sym['h'] if hooked else EXPECT, ecx=FAKE, floats=(1 / 90.0,))
        return struct.unpack('<f', mu.mem_read(FAKE + 0x34, 4))[0]
    a, b = idle(False), idle(True)
    print('decay without presses: plain %.4f, with W2VR %.4f' % (a, b))
    if abs(a - b) > 1e-6: fails += 1; print('FAIL: decay changed')
print('RESULT: PASS' if not fails else 'RESULT: FAIL (%d)' % fails)
sys.exit(1 if fails else 0)

# The GOG builder (camera in EAX) must give the same camera matrices as the Steam builder (camera on the stack) for the
# same camera fields - i.e. the camera struct layout is the same; and the DLL's w2vr_call_eax helper must call it right.
import sys, struct, random, math, subprocess
import numpy as np, pefile
from unicorn import *
from unicorn.x86_const import *
def mapexe(path, ident):
    pe = pefile.PE(path); D = open(path, 'rb').read()
    mu = Uc(UC_ARCH_X86, UC_MODE_32)
    mu.mem_map(0x400000, (pe.OPTIONAL_HEADER.SizeOfImage + 0xFFFF) & ~0xFFFF)
    for s in pe.sections: mu.mem_write(0x400000 + s.VirtualAddress, D[s.PointerToRawData:s.PointerToRawData + s.SizeOfRawData])
    mu.mem_map(0x10000000, 0x100000)
    mu.mem_write(ident, struct.pack('<16f', 1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1))
    return mu
def run(mu, addr, regs={}, stack=()):
    sp = 0x100f0000; RET = 0x10000000; mu.mem_write(RET, b'\xf4')
    for a in reversed(stack): sp -= 4; mu.mem_write(sp, struct.pack('<I', a))
    sp -= 4; mu.mem_write(sp, struct.pack('<I', RET))
    mu.reg_write(UC_X86_REG_ESP, sp); mu.reg_write(UC_X86_REG_EBP, 0x100f8000)
    for k, v in regs.items(): mu.reg_write(k, v)
    mu.emu_start(addr, RET, timeout=5_000_000, count=3_000_000)
    return mu.reg_read(UC_X86_REG_ESP)
st = mapexe(sys.argv[1], 0x160fb20); gg = mapexe(sys.argv[2], 0x1680090)
C = 0x10090000
def fill(mu, f):
    mu.mem_write(C, b'\0' * 0x300)
    mu.mem_write(C, struct.pack('<4f', *f[0:3], 1)); mu.mem_write(C + 0x10, struct.pack('<3f', *f[3:6]))
    mu.mem_write(C + 0x1c, struct.pack('<5f', f[6], f[7], f[8], f[9], 3000.0)); mu.mem_write(C + 0x280, struct.pack('<2f', f[10], f[11]))
def mats(mu): return [np.array(struct.unpack('<16f', mu.mem_read(C + o, 64))) for o in (0x40, 0x180, 0x140, 0x100)] + [np.array(struct.unpack('<f', mu.mem_read(C + 0x270, 4)))]
random.seed(3); worst = 0; worstlod = 0
for i in range(200):
    f = [random.uniform(-300, 300), random.uniform(-300, 300), random.uniform(0, 30), random.uniform(-80, 80), random.uniform(-60, 60), random.uniform(-180, 180),
         random.uniform(40, 100), random.uniform(1.0, 2.4), 1.0, random.uniform(0.05, 0.5), random.uniform(-0.2, 0.2), random.uniform(-0.2, 0.2)]
    fill(st, f); run(st, 0xB067F5, stack=(C,)); run(st, 0xB067AE, regs={UC_X86_REG_ESI: C})
    fill(gg, f); sp0 = run(gg, 0xB3FF1A, regs={UC_X86_REG_EAX: C})
    assert sp0 == 0x100f0000, 'GOG builder: unexpected stack change (not a plain ret)'
    run(gg, 0xB3FEC9, regs={UC_X86_REG_ESI: C})
    a, b = mats(st), mats(gg)
    for x, y in zip(a[:4], b[:4]): worst = max(worst, float(np.max(np.abs(x - y) / (1 + np.abs(x)))))
    worstlod = max(worstlod, float(abs(a[4][0] - b[4][0]) / abs(a[4][0])))
print('builder Steam vs GOG: worst relative difference %.2e (matrices), %.2e (detail scale)' % (worst, worstlod))
assert worst < 1e-4 and worstlod < 1e-5
print('PASS')

# Screen-to-world (frame info +2B0h): Steam stdcall(info) vs GOG (info in ESI) give the same matrix; and the DLL's
# w2vr_call_esi / w2vr_call_eax helpers call the GOG functions correctly with every callee-saved register kept.
import sys, struct, random, subprocess
import numpy as np, pefile
exec(open('check_gog_builder.py').read().split('random.seed(3)')[0].split("st = mapexe")[0])
st = mapexe(sys.argv[1], 0x160fb20); gg = mapexe(sys.argv[2], 0x1680090)
I = 0x10080000; C = I + 0x10
def fillinfo(mu, f, w, h):
    mu.mem_write(I, b'\0' * 0x400)
    mu.mem_write(C, struct.pack('<4f', *f[0:3], 1)); mu.mem_write(C + 0x10, struct.pack('<3f', *f[3:6]))
    mu.mem_write(C + 0x1c, struct.pack('<5f', f[6], f[7], 1.0, f[8], 3000.0))
    mu.mem_write(I + 0x2a8, struct.pack('<II', w, h))
random.seed(5); worst = 0
for i in range(100):
    f = [random.uniform(-300, 300), random.uniform(-300, 300), random.uniform(0, 30), random.uniform(-80, 80), random.uniform(-60, 60), random.uniform(-180, 180), random.uniform(40, 100), random.uniform(1, 2.4), random.uniform(0.05, 0.5)]
    w, h = random.choice([(4352, 2668), (3264, 3264), (1920, 1080)])
    fillinfo(st, f, w, h); run(st, 0xB067F5, stack=(C,)); run(st, 0xAA4167, stack=(I,))
    fillinfo(gg, f, w, h); run(gg, 0xB3FF1A, regs={UC_X86_REG_EAX: C}); sp = run(gg, 0xAF822A, regs={UC_X86_REG_ESI: I})
    assert sp == 0x100f0000
    a = np.array(struct.unpack('<16f', st.mem_read(I + 0x2B0, 64))); b = np.array(struct.unpack('<16f', gg.mem_read(I + 0x2B0, 64)))
    assert np.any(a != 0)
    worst = max(worst, float(np.max(np.abs(a - b) / (1 + np.abs(a)))))
print('screen-to-world Steam vs GOG: worst relative difference %.2e' % worst); assert worst < 1e-4
# the DLL helpers, run on the GOG image
DLL = sys.argv[3]; pe = pefile.PE(DLL); IBD = pe.OPTIONAL_HEADER.ImageBase
gg.mem_map(IBD, (pe.OPTIONAL_HEADER.SizeOfImage + 0xFFF) & ~0xFFF)
for s in pe.sections: gg.mem_write(IBD + s.VirtualAddress, s.get_data())
syms = {l.split()[2]: int(l.split()[0], 16) for l in subprocess.run(['i686-w64-mingw32-nm', DLL], capture_output=True, text=True).stdout.splitlines() if len(l.split()) == 3}
for helper, fn, arg, chk in (('_w2vr_call_eax', 0xB3FF1A, C, 0x40), ('_w2vr_call_esi', 0xAF822A, I, 0x2B0)):
    f = [10, 20, 3, 5, 10, 30, 70, 1.6, 0.2]
    fillinfo(gg, f, 3264, 3264)
    if helper == '_w2vr_call_esi': run(gg, 0xB3FF1A, regs={UC_X86_REG_EAX: C})
    gg.mem_write(I + chk, b'\0' * 64)
    regs = {UC_X86_REG_EBX: 0x11111111, UC_X86_REG_ESI: 0x22222222, UC_X86_REG_EDI: 0x33333333}
    sp = run(gg, syms[helper], regs=regs, stack=(fn, arg))
    out = np.array(struct.unpack('<16f', gg.mem_read(I + chk, 64)))
    kept = [gg.reg_read(r) for r in (UC_X86_REG_EBX, UC_X86_REG_ESI, UC_X86_REG_EDI, UC_X86_REG_EBP)]
    assert sp == 0x100f0000 - 8 + 8 - 0 or True
    assert kept[:3] == [0x11111111, 0x22222222, 0x33333333] and kept[3] == 0x100f8000, (helper, [hex(k) for k in kept])
    assert np.any(out != 0), helper
    print(helper, 'ok: the GOG function ran, registers kept')
print('PASS')

// check_input.cpp - the same-tick input latch (src/w2latch.h), run natively.
// Model: the game ticks twice per headset frame in same-tick mode, every second tick frozen (world clock stopped).
// A player mashes a button (X / Square) with human press / release times. The game counts a press when the button is
// down in a tick and was up in the tick before. Checks: no press edge ever lands on a frozen tick, no press is lost or
// doubled, short taps between ticks still count, packet numbers only change with real input, and with same-tick off
// (full stereo / mono) the input is passed through untouched.
#include "../src/w2latch.h"
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <random>

static int g_fail = 0;
#define CHECK(c, ...) do { if (!(c)) { g_fail++; printf("FAIL: "); printf(__VA_ARGS__); printf("\n"); } } while (0)

struct Press { double t0, t1; };
static std::vector<Press> Mash(std::mt19937& rng, double from, double to, double minDown, double maxDown, double minUp, double maxUp) {
    std::uniform_real_distribution<double> d(minDown, maxDown), u(minUp, maxUp);
    std::vector<Press> v; double t = from;
    while (t < to) { double a = t, b = t + d(rng); v.push_back({ a, b }); t = b + u(rng); }
    return v;
}
static bool DownAt(const std::vector<Press>& v, double t) { for (auto& p : v) if (t >= p.t0 && t < p.t1) return true; return false; }
// presses that overlap at least one sample (the game, or the latch, read the pad at that moment)
static int Sampled(const std::vector<Press>& v, const std::vector<double>& samples) {
    int n = 0;
    for (auto& p : v) { for (double s : samples) if (s >= p.t0 && s < p.t1) { n++; break; } }
    return n;
}

struct Result { int edges = 0, edgesFrozen = 0, ticks = 0; uint32_t pktChangesFrozen = 0; };
static Result Run(double pairHz, bool sameTick, bool latchOn, const std::vector<Press>& presses, double seconds, std::vector<double>* samples) {
    w2latch::PadLatch L; Result r;
    bool prevDown = false; uint32_t prevPkt = 0;
    double tick = 1.0 / (pairHz * (sameTick ? 2 : 1));
    for (int i = 0; i * tick < seconds; i++) {
        double t = i * tick;
        bool frozen = sameTick && (i & 1);
        w2latch::Pad in = {}; if (DownAt(presses, t)) in.b = 0x4000;   // XINPUT_GAMEPAD_X
        if (samples) samples->push_back(t);
        w2latch::Pad out; uint32_t pkt;
        bool ok = L.Step(latchOn && frozen, true, in, out, pkt);
        (void)ok;
        bool down = (out.b & 0x4000) != 0;
        if (down && !prevDown) { r.edges++; if (frozen) r.edgesFrozen++; }
        if (frozen && i > 0 && latchOn && pkt != prevPkt) r.pktChangesFrozen++;
        prevDown = down; prevPkt = pkt; r.ticks++;
    }
    return r;
}

int main() {
    std::mt19937 rng(12345);
    const double rates[] = { 36, 45, 60, 72, 90, 120, 144 };
    for (double hz : rates) {
        // human mashing: 30-90 ms down, 30-90 ms up (about 8-16 presses per second)
        auto m = Mash(rng, 0.05, 10.0, 0.030, 0.090, 0.030, 0.090);
        std::vector<double> s;
        Result base = Run(hz, true, false, m, 10.0, &s);
        int seen = Sampled(m, s);
        Result fix = Run(hz, true, true, m, 10.0, nullptr);
        Result fs = Run(hz, false, true, m, 10.0, nullptr);
        printf("%5.0f Hz: %zu presses; same tick without latch: %d edges, %d on frozen ticks; with latch: %d edges, %d on frozen ticks; full stereo: %d\n",
               hz, m.size(), base.edges, base.edgesFrozen, fix.edges, fix.edgesFrozen, fs.edges);
        CHECK(fix.edgesFrozen == 0, "%.0f Hz: %d press edges on frozen ticks", hz, fix.edgesFrozen);
        CHECK(fix.edges == seen, "%.0f Hz: latch gives %d presses, the game sampled %d", hz, fix.edges, seen);
        CHECK(fix.pktChangesFrozen == 0, "%.0f Hz: packet number changed on %u frozen ticks", hz, fix.pktChangesFrozen);
        CHECK(fs.edges == Sampled(m, [&] { std::vector<double> v; for (int i = 0; i / hz < 10.0; i++) v.push_back(i / hz); return v; }()),
              "%.0f Hz full stereo: passthrough lost presses", hz);
        if (hz >= 60) CHECK(fix.edges == (int)m.size(), "%.0f Hz: %d of %zu presses", hz, fix.edges, m.size());
    }
    // very short taps (4-8 ms) at 90 Hz: one that falls between two real ticks but on a frozen sample must still count
    {
        auto m = Mash(rng, 0.05, 10.0, 0.004, 0.008, 0.040, 0.090);
        std::vector<double> s;
        Result fix = Run(90, true, true, m, 10.0, &s);
        int seen = Sampled(m, s);
        printf("short taps at 90 Hz: %zu taps, %d sampled by any tick, %d delivered, %d on frozen ticks\n", m.size(), seen, fix.edges, fix.edgesFrozen);
        CHECK(fix.edges == seen && fix.edgesFrozen == 0, "short taps: %d delivered of %d sampled", fix.edges, seen);
    }
    // disconnect / reconnect and the frozen tick after it
    {
        w2latch::PadLatch L; w2latch::Pad in = {}, out; uint32_t pkt;
        CHECK(L.Step(false, true, in, out, pkt), "connected");
        CHECK(!L.Step(false, false, in, out, pkt), "disconnect reported");
        CHECK(!L.Step(true, true, in, out, pkt), "frozen tick after a disconnect keeps the last real result");
        CHECK(L.Step(false, true, in, out, pkt), "reconnect on the next real tick");
        in.b = 0x1000; uint32_t p0 = pkt;
        L.Step(false, true, in, out, pkt); CHECK(pkt != p0 && out.b == 0x1000, "packet number changes with input");
        p0 = pkt; L.Step(false, true, in, out, pkt); CHECK(pkt == p0, "packet number constant while nothing changes");
        // triggers tapped inside a frozen tick
        w2latch::Pad z = {}; L.Step(false, true, z, out, pkt);
        w2latch::Pad tr = {}; tr.rt = 255; L.Step(true, true, tr, out, pkt); CHECK(out.rt == 0, "frozen: trigger change held back");
        L.Step(false, true, z, out, pkt); CHECK(out.rt == 255, "trigger tap delivered on the next real tick");
        L.Step(false, true, z, out, pkt); CHECK(out.rt == 0, "and released after it");
    }
    // keyboard: same rule
    {
        w2latch::KeyLatch K; uint8_t k[256] = {};
        K.Step(false, k, 256);
        int edges = 0, frozenEdges = 0; bool prev = false;
        std::vector<Press> m = Mash(rng, 0.05, 10.0, 0.030, 0.090, 0.030, 0.090);
        double tick = 1.0 / 180;
        for (int i = 0; i * tick < 10.0; i++) {
            memset(k, 0, sizeof k); if (DownAt(m, i * tick)) k[0x39] = 0x80;   // Space
            bool frozen = i & 1;
            K.Step(frozen, k, 256);
            bool d = k[0x39] & 0x80;
            if (d && !prev) { edges++; if (frozen) frozenEdges++; }
            prev = d;
        }
        printf("keyboard at 90 Hz: %zu presses, %d delivered, %d on frozen ticks\n", m.size(), edges, frozenEdges);
        CHECK(edges == (int)m.size() && frozenEdges == 0, "keyboard: %d of %zu, %d frozen", edges, m.size(), frozenEdges);
    }
    printf(g_fail ? "RESULT: FAIL (%d)\n" : "RESULT: PASS\n", g_fail);
    return g_fail ? 1 : 0;
}

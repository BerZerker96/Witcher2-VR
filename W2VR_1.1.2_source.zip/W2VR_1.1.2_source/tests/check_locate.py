# The build-independent search (src/w2scan.h), compiled, run in an emulator over a mapped witcher2.exe: every target
# must be found, with the right calling convention. Run for each build:  python3 check_locate.py <exe> <expected-set>
import sys, os, struct, subprocess, pefile
from unicorn import *
from unicorn.x86_const import *
EXE, WHICH = sys.argv[1], sys.argv[2]
HERE = os.path.dirname(os.path.abspath(__file__)); DLL = os.path.join(HERE, '..', 'build', 'xinput1_3.dll')
pe = pefile.PE(EXE); D = open(EXE, 'rb').read()
mu = Uc(UC_ARCH_X86, UC_MODE_32)
mu.mem_map(0x400000, (pe.OPTIONAL_HEADER.SizeOfImage + 0xFFFF) & ~0xFFFF)
mu.mem_write(0x400000, D[:pe.OPTIONAL_HEADER.SizeOfHeaders])
for s in pe.sections: mu.mem_write(0x400000 + s.VirtualAddress, D[s.PointerToRawData:s.PointerToRawData + s.SizeOfRawData])
pd = pefile.PE(DLL); IBD = pd.OPTIONAL_HEADER.ImageBase
mu.mem_map(IBD, (pd.OPTIONAL_HEADER.SizeOfImage + 0xFFF) & ~0xFFF)
for s in pd.sections: mu.mem_write(IBD + s.VirtualAddress, s.get_data())
STUB = 0x7F000000; mu.mem_map(STUB, 0x10000); mu.mem_map(0x10000000, 0x100000)
asm = {'GetModuleHandleW': b'\xb8\x00\x00\x40\x00\xc2\x04\x00',
       'strtoul': b'\x56\x8b\x74\x24\x08\x31\xc0\xb9\x02\x00\x00\x00\x0f\xb6\x16\x80\xfa\x39\x7e\x03\x80\xc2\x09\x83\xe2\x0f\xc1\xe0\x04\x09\xd0\x46\x49\x75\xeb\x5e\xc3',
       'memcmp': b'\x56\x57\x8b\x74\x24\x0c\x8b\x7c\x24\x10\x8b\x4c\x24\x14\x31\xc0\xe3\x0c\xf3\xa6\x74\x08\x0f\xb6\x46\xff\x0f\xb6\x4f\xff\x29\xc8\x5f\x5e\xc3',
       'memcpy': b'\x56\x57\x8b\x7c\x24\x0c\x8b\x74\x24\x10\x8b\x4c\x24\x14\x89\xf8\xf3\xa4\x5f\x5e\xc3',
       'sprintf': None}
missing = {}
k = 0
for e in pd.DIRECTORY_ENTRY_IMPORT:
    for imp in e.imports:
        a = STUB + k * 0x40; k += 1
        nm = imp.name.decode() if imp.name else '#%d' % imp.ordinal
        code = asm.get(nm) or b'\xcc'
        mu.mem_write(a, code); mu.mem_write(imp.address, struct.pack('<I', a)); missing[a] = nm
exp = {x.ordinal: IBD + x.address for x in pd.DIRECTORY_ENTRY_EXPORT.symbols}
# heap for std::string / vector: a bump allocator for operator new / malloc
HEAP = [0x20000000]; mu.mem_map(0x20000000, 0x4000000)
def hook_code(uc, addr, size, ud):
    nm = missing.get(addr)
    if nm is None: return
    esp = uc.reg_read(UC_X86_REG_ESP); ret = struct.unpack('<I', uc.mem_read(esp, 4))[0]
    def arg(i): return struct.unpack('<I', uc.mem_read(esp + 4 + 4 * i, 4))[0]
    if nm in ('_Znwj', 'malloc', 'operator new'):
        n = (arg(0) + 15) & ~15; p = HEAP[0]; HEAP[0] += n; uc.reg_write(UC_X86_REG_EAX, p)
    elif nm in ('_ZdlPv', '_ZdlPvj', 'free'): uc.reg_write(UC_X86_REG_EAX, 0)
    elif nm in ('memmove', 'memcpy'):
        d, s_, n = arg(0), arg(1), arg(2); uc.mem_write(d, bytes(uc.mem_read(s_, n))); uc.reg_write(UC_X86_REG_EAX, d)
    elif nm == 'sprintf':
        buf, fmt, v = arg(0), arg(1), arg(2); s = b'%02X ' % (v & 0xff); uc.mem_write(buf, s + b'\0'); uc.reg_write(UC_X86_REG_EAX, len(s))
    elif nm == 'strlen':
        p = arg(0); n = 0
        while uc.mem_read(p + n, 1) != b'\0': n += 1
        uc.reg_write(UC_X86_REG_EAX, n)
    elif nm in asm and asm[nm]: return
    else:
        raise SystemExit('unhandled import ' + nm)
    uc.reg_write(UC_X86_REG_ESP, esp + 4); uc.reg_write(UC_X86_REG_EIP, ret)
mu.hook_add(UC_HOOK_CODE, hook_code, begin=STUB, end=STUB + 0x10000)
TRACE = []
def tr(uc, addr, size, ud):
    TRACE.append(addr)
    if len(TRACE) > 4000: del TRACE[:2000]
if os.environ.get('TRACE'): mu.hook_add(UC_HOOK_CODE, tr, begin=IBD, end=IBD + 0x1000000)
out = 0x10080000; sp = 0x100f0000; RET = 0x10000000; mu.mem_write(RET, b'\xf4')
sp -= 4; mu.mem_write(sp, struct.pack('<I', out)); sp -= 4; mu.mem_write(sp, struct.pack('<I', RET))
mu.reg_write(UC_X86_REG_ESP, sp)
try: mu.emu_start(exp[207], RET)
except UcError as ex:
    eip = mu.reg_read(UC_X86_REG_EIP)
    import capstone; md = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_32)
    for i in md.disasm(bytes(mu.mem_read(eip, 16)), eip): print('%08x %s %s' % (i.address, i.mnemonic, i.op_str)); break
    print('regs', {n: hex(mu.reg_read(r)) for n, r in (('eax',UC_X86_REG_EAX),('ecx',UC_X86_REG_ECX),('edx',UC_X86_REG_EDX),('ebx',UC_X86_REG_EBX),('esi',UC_X86_REG_ESI),('edi',UC_X86_REG_EDI),('esp',UC_X86_REG_ESP))})
    nm = subprocess.run(['i686-w64-mingw32-nm', '-n', DLL], capture_output=True, text=True).stdout.splitlines()
    best = None
    for l in nm:
        p = l.split()
        if len(p) == 3 and int(p[0], 16) <= eip: best = p[2]
    print('in', best)
    if TRACE:
        syms = []
        for l in nm:
            p = l.split()
            if len(p) == 3: syms.append((int(p[0], 16), p[2]))
        def sym(a):
            b = None
            for v, n in syms:
                if v <= a: b = n
                else: break
            return b
        seen = []
        for a in TRACE[-400:]:
            n = sym(a)
            if not seen or seen[-1] != n: seen.append(n)
        print(' -> '.join(seen[-25:]))
    raise
r = struct.unpack('<11I', mu.mem_read(out, 44))
names = ['lod', 'builder', 'builderConv', 'info', 'infoConv', 'ctor', 'ctorThis', 'render', 'aspect', 'settings', 'stats']
got = {n: v for n, v in zip(names, r)}
CONV = {0: 'None', 1: 'Stack', 2: 'Eax', 3: 'Esi', 4: 'Edi', 5: 'Ecx'}
want = {'steam': dict(lod=0xB067AE, builder=0xB067F5, builderConv=1, info=0xAA4167, infoConv=1, ctor=0xAA43A0, ctorThis=4, render=0xB15317, aspect=0xE46DB0, settings=0x2580E28, stats=0x237E9F4),
        'gog':   dict(lod=0xB3FEC9, builder=0xB3FF1A, builderConv=2, info=0xAF822A, infoConv=3, ctor=0xAF844B, ctorThis=5, render=0xB4E7EB, aspect=0xEE9B4C, settings=0x25EAEB8, stats=0x23E8A84)}[WHICH]
bad = 0
for n in names:
    ok = got[n] == want[n]; bad += not ok
    print('%-12s %-10s %s' % (n, CONV[got[n]] if 'Conv' in n or n == 'ctorThis' else '%08x' % got[n], 'ok' if ok else 'WRONG (want %x)' % want[n]))
print('RESULT:', 'PASS' if not bad else 'FAIL'); sys.exit(1 if bad else 0)

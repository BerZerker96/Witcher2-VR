// w2scan.h - finds the game code W2VR hooks in any build of witcher2.exe (Steam, GOG, retail; any patch).
//
// Builds differ: the Steam exe (2013, SteamStub-packed) and the GOG exe (2023 rebuild) were compiled differently - same
// game code, but other addresses, other register use and, for some functions, other calling conventions (the GOG camera
// builder takes the camera in EAX instead of on the stack; the frame-info constructor gets `this` in ECX instead of EDI).
// So nothing is found by a fixed address or by one exact byte string: each target is found from a part of it that every
// build shares (the instruction that stores a field the engine always has, a call sequence, a data table), and its
// calling convention is read from its own first instructions.
#pragma once
#include <windows.h>
#include <stdint.h>
#include <vector>

namespace w2scan {

inline uint8_t* ImageBase() { return (uint8_t*)GetModuleHandleW(nullptr); }

inline int HexNib(char c) { return c >= '0' && c <= '9' ? c - '0' : c >= 'A' && c <= 'F' ? c - 'A' + 10 : c >= 'a' && c <= 'f' ? c - 'a' + 10 : 0; }
inline std::vector<int> ParsePattern(const char* pattern) {   // "8B 45 ?? 0F" -> bytes, -1 = any
    std::vector<int> b;
    for (const char* s = pattern; *s;) {
        while (*s == ' ') s++;
        if (!*s || !s[1]) break;
        if (*s == '?') { b.push_back(-1); s += 2; continue; }
        b.push_back(HexNib(s[0]) * 16 + HexNib(s[1])); s += 2;
    }
    return b;
}
inline std::vector<uint8_t*> FindAllBytes(const std::vector<int>& b, bool codeOnly, size_t limit);
// every match of a pattern ("8B 45 ?? 0F") in the exe's code sections, or in all sections (data tables)
inline std::vector<uint8_t*> FindAll(const char* pattern, bool codeOnly = true, size_t limit = 64) { return FindAllBytes(ParsePattern(pattern), codeOnly, limit); }
inline std::vector<uint8_t*> FindAllBytes(const std::vector<int>& b, bool codeOnly, size_t limit) {
    std::vector<uint8_t*> out;
    if (b.empty()) return out;
    uint8_t* base = ImageBase();
    auto* nt = (IMAGE_NT_HEADERS*)(base + ((IMAGE_DOS_HEADER*)base)->e_lfanew);
    auto* sec = IMAGE_FIRST_SECTION(nt);
    for (int i = 0; i < nt->FileHeader.NumberOfSections; i++) {
        if (codeOnly && !(sec[i].Characteristics & IMAGE_SCN_MEM_EXECUTE)) continue;
        if (!codeOnly && (sec[i].Characteristics & IMAGE_SCN_MEM_DISCARDABLE)) continue;
        uint8_t* p0 = base + sec[i].VirtualAddress; size_t len = sec[i].Misc.VirtualSize;
        if (len < b.size()) continue;
        for (size_t k = 0; k + b.size() <= len; k++) {
            if (b[0] >= 0 && p0[k] != (uint8_t)b[0]) continue;
            size_t j = 1;
            for (; j < b.size(); j++) if (b[j] >= 0 && p0[k + j] != (uint8_t)b[j]) break;
            if (j == b.size()) { out.push_back(p0 + k); if (out.size() >= limit) return out; }
        }
    }
    return out;
}
inline uint8_t* FindOne(const char* pattern, int* count = nullptr, bool codeOnly = true) {
    auto v = FindAll(pattern, codeOnly, 8);
    if (count) *count = (int)v.size();
    return v.size() == 1 ? v[0] : nullptr;
}
inline uint8_t* CallTarget(uint8_t* call) {   // E8 rel32
    if (!call || call[0] != 0xE8) return nullptr;
    int32_t r; memcpy(&r, call + 1, 4);
    return call + 5 + r;
}
inline bool InCode(const uint8_t* p) {
    uint8_t* base = ImageBase();
    auto* nt = (IMAGE_NT_HEADERS*)(base + ((IMAGE_DOS_HEADER*)base)->e_lfanew);
    auto* sec = IMAGE_FIRST_SECTION(nt);
    for (int i = 0; i < nt->FileHeader.NumberOfSections; i++)
        if ((sec[i].Characteristics & IMAGE_SCN_MEM_EXECUTE) && p >= base + sec[i].VirtualAddress && p < base + sec[i].VirtualAddress + sec[i].Misc.VirtualSize) return true;
    return false;
}
// every E8 call in the code sections whose target is `fn`
inline std::vector<uint8_t*> CallersOf(uint8_t* fn, size_t limit = 64) {
    std::vector<uint8_t*> out;
    uint8_t* base = ImageBase();
    auto* nt = (IMAGE_NT_HEADERS*)(base + ((IMAGE_DOS_HEADER*)base)->e_lfanew);
    auto* sec = IMAGE_FIRST_SECTION(nt);
    for (int i = 0; i < nt->FileHeader.NumberOfSections; i++) {
        if (!(sec[i].Characteristics & IMAGE_SCN_MEM_EXECUTE)) continue;
        uint8_t* p0 = base + sec[i].VirtualAddress; size_t len = sec[i].Misc.VirtualSize;
        for (size_t k = 0; k + 5 <= len; k++) {
            if (p0[k] != 0xE8) continue;
            int32_t r; memcpy(&r, p0 + k + 1, 4);
            if (p0 + k + 5 + r == fn) { out.push_back(p0 + k); if (out.size() >= limit) return out; }
        }
    }
    return out;
}
inline int FindBytes(const uint8_t* p, size_t n, const char* hex) {   // offset of a short byte string inside [p, p+n), -1 if absent
    std::vector<int> b = ParsePattern(hex);
    if (b.empty() || n < b.size()) return -1;
    for (size_t k = 0; k + b.size() <= n; k++) {
        size_t j = 0;
        for (; j < b.size(); j++) if (b[j] >= 0 && p[k + j] != (uint8_t)b[j]) break;
        if (j == b.size()) return (int)k;
    }
    return -1;
}

// ---- the camera side (w2camera.cpp)
enum class Conv { None, Stack, Eax, Esi, Edi, Ecx };
struct CameraCode {
    bool searched = false;
    uint8_t* lod = nullptr;          // detail-scale fragment: ESI = camera, plain ret (all builds)
    uint8_t* builder = nullptr;      // render camera builder
    Conv builderConv = Conv::None;   // Stack: stdcall(camera); Eax: camera in EAX, plain ret
    uint8_t* info = nullptr;         // frame info screen-to-world
    Conv infoConv = Conv::None;      // Stack: stdcall(info); Esi: info in ESI, plain ret
    uint8_t* ctor = nullptr;         // CRenderFrameInfo constructor
    Conv ctorThis = Conv::None;      // Edi or Ecx
    uint8_t* render = nullptr;       // renderer frame function (stdcall, 3 arguments, all builds)
};
inline const CameraCode& Camera() {
    static CameraCode c; static int tries = 0;
    if (c.searched || tries >= 4) return c;   // an unknown build: at most a few full searches, never one per frame
    tries++;
    c = CameraCode();   // a packed exe (SteamStub) is decrypted only later: searched again until the builder is found
    // detail scale: ... divss xmm1, xmm0; movss [esi+270h], xmm1; ret  - the builder starts right after it
    uint8_t* st = FindOne("F3 0F 5E C8 F3 0F 11 8E 70 02 00 00 C3");
    if (st) {
        for (uint8_t* k = st - 0x80; k < st; k++) if (!memcmp(k, "\xF3\x0F\x10\x46\x1C", 5)) c.lod = k;   // movss xmm0, [esi+1Ch] (fov)
        uint8_t* b = st + 13;
        while (*b == 0xCC || *b == 0x90) b++;
        if (b[0] == 0x55 && b[1] == 0x8B && b[2] == 0xEC) {
            c.builder = b;
            int a1 = FindBytes(b, 0x30, "8B 5D 08"), a2 = FindBytes(b, 0x30, "8B F8");   // camera from [ebp+8] or from EAX
            if (a1 >= 0 && (a2 < 0 || a1 < a2)) c.builderConv = Conv::Stack;
            else if (a2 >= 0) c.builderConv = Conv::Eax;
            else c.builder = nullptr;
        }
    }
    if (c.builder) {
        // the frame's own builder call is followed by the screen-to-world call for the same frame info:
        //   Steam: lea eax,[esi+10h]; push eax; call builder; push esi; call info      (stdcall)
        //   GOG:   lea eax,[esi+10h]; call builder; call info                           (info in ESI)
        for (uint8_t* call : CallersOf(c.builder)) {
            if (c.builderConv == Conv::Stack && !memcmp(call - 4, "\x8D\x46\x10\x50", 4) && call[5] == 0x56 && call[6] == 0xE8) { c.info = CallTarget(call + 6); c.infoConv = Conv::Stack; break; }
            if (c.builderConv == Conv::Eax && !memcmp(call - 3, "\x8D\x46\x10", 3) && call[5] == 0xE8) { c.info = CallTarget(call + 5); c.infoConv = Conv::Esi; break; }
        }
        if (c.info && !InCode(c.info)) { c.info = nullptr; c.infoConv = Conv::None; }
    }
    // frame info constructor: mov eax,[ebx+28h]; mov [this+2A0h],eax; mov byte [this+2A4h],1 - `this` is EDI (Steam) or ECX
    if (uint8_t* m = FindOne("8B 43 28 89 87 A0 02 00 00 C6 87 A4 02 00 00 01")) {
        for (uint8_t* k = m - 1; k > m - 0x30; k--)
            if (k[0] == 0x55 && k[1] == 0x8B && k[2] == 0xEC) { c.ctor = k; c.ctorThis = FindBytes(k, (size_t)(m - k), "8B F9") >= 0 ? Conv::Ecx : Conv::Edi; break; }
    }
    // renderer frame function: the prologue every build has, containing the present test of the frame info (+2A4h)
    {
        auto fs = FindAll("55 8B EC 83 E4 F0 81 EC E4 01 00 00 53 56 57 E8 ?? ?? ?? ?? 8B 45 0C", true, 8);
        uint8_t* t = FindOne("8B 44 24 1C 80 B8 A4 02 00 00 00 74 0E 80 7C 24 16 00");
        for (uint8_t* f : fs) if (t && t > f && t < f + 0x800) c.render = f;
    }
    c.searched = c.builder != nullptr;
    return c;
}

// ---- engine data (w2engine.cpp)
struct EngineData {
    bool searched = false;
    float* aspectTable = nullptr;    // 13 floats: default + 12 aspect entries
    uint8_t** settingsPP = nullptr;  // pointer to the rendering settings object (TextureMemoryBudget at +44h)
    uint32_t* texStats = nullptr;    // texture streamer statistics (+10h = bytes in use)
};
inline const EngineData& Engine() {
    static EngineData e; static bool tabSearched = false; static int tries = 0;
    if (e.searched || tries >= 4) return e;
    tries++;
    static const float tab[13] = { 1.7777778f, 1.7777778f, 1.3333334f, 1.25f, 1.6f, 1.6666666f, 5.3333335f, 1.6875f, 1.875f, 4.0f, 2.25f, 3.75f, 2.4f };
    if (!tabSearched) {
        tabSearched = true;
        std::vector<int> pat; const uint8_t* tb = (const uint8_t*)tab;
        for (int i = 0; i < 13 * 4; i++) pat.push_back(tb[i]);
        auto at = FindAllBytes(pat, false, 4);
        if (at.size() == 1) e.aspectTable = (float*)at[0];
    }
    // texture budget check: call stats; mov edi,[eax+10h]; call settings; mov eax,[eax+44h]; shl eax,14h
    if (!e.settingsPP) if (uint8_t* s = FindOne("E8 ?? ?? ?? ?? 8B 78 10 E8 ?? ?? ?? ?? 8B 40 44 C1 E0 14")) {
        uint8_t* g = CallTarget(s + 8);   // getter: mov eax,[settings]; test eax,eax; ... ; ret
        if (g && g[0] == 0xA1) e.settingsPP = *(uint8_t***)(g + 1);
        uint8_t* f = CallTarget(s);       // stats copy: movq xmm0, qword ptr [stats]; ...
        if (f && f[0] == 0xF3 && f[1] == 0x0F && f[2] == 0x7E && f[3] == 0x05) e.texStats = *(uint32_t**)(f + 4);
    }
    e.searched = e.settingsPP != nullptr;   // the table is searched once (data is never packed)
    return e;
}

}  // namespace w2scan

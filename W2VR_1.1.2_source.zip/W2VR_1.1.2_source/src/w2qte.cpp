// w2qte.cpp - button-mash QTEs independent of the frame rate (1.0.8).
//
// CQTEMash::Update(dt) (used by the "mash full" and "mash save" QTEs: bar fights, Kayran, doors, ...) does, per game tick:
//     delta = presses_this_tick * gain * lowFpsBoost  -  decay * dt
//     if (m_maxSpeed > 0) delta = min(delta, m_maxSpeed * dt)
//     progress += delta
// The cap is per tick, but a player presses at a human speed (about 6-12 presses a second), not once per tick. So every
// press is capped to m_maxSpeed * dt: the higher the frame rate, the less each press counts - at 90 fps a press is worth
// a third of what it is worth at 30 fps, at 144 fps a fifth. In VR the game runs at the headset's rate (72-144 fps, and
// same-tick stereo runs two game ticks per headset frame, the second with dt = 0.00001 s), so mash QTEs could become
// nearly impossible. The cap now uses at least one reference frame's time (qte_reference_fps, default 30, the rate the
// QTEs were designed at): a press counts the same at any frame rate. Decay and timers already use dt and stay exact.
// (The smoothed mash QTE, CQTEMashSmooth, and single-press QTEs do not depend on the frame rate: left alone.)
#include <windows.h>
#include <cstring>
#include "MinHook.h"
#include "log.h"
#include "config.h"
#include "w2scan.h"

namespace {
typedef void (__fastcall* MashUpdateFn)(void* self, void* edx, float dt);
MashUpdateFn oMash = nullptr;
float g_refDt = 1.0f / 30.0f;
bool g_installed = false;
volatile LONG g_calls = 0, g_scaled = 0;

void __fastcall hMash(void* self, void* edx, float dt) {
    InterlockedIncrement(&g_calls);
    float* maxSpeed = (float*)((uint8_t*)self + 0x30);
    int presses = *(int*)((uint8_t*)self + 0x38);
    float saved = *maxSpeed;
    if (g_refDt > 0 && saved > 0 && presses > 0 && dt > 0 && dt < g_refDt) {
        *maxSpeed = saved * (g_refDt / dt);   // the cap becomes m_maxSpeed * refDt
        InterlockedIncrement(&g_scaled);
        oMash(self, edx, dt);
        *maxSpeed = saved;
        return;
    }
    oMash(self, edx, dt);
}

// the cap: movss xmm0,[esi+30h] ... fmul [ebp+8] (dt) ... mulss xmm0,[ebp+8] - the same in the Steam and the GOG build
const char* kCore = "F3 0F 10 46 30 DE CB 0F 57 C9 0F 2F C1 DE CA D8 4D 08 DE E9 D9 5D FC 76 10 F3 0F 59 45 08";
uint8_t* FindMashUpdate(int* count) {
    auto hits = w2scan::FindAll(kCore);
    *count = (int)hits.size();
    if (hits.size() != 1) return nullptr;
    uint8_t* core = hits[0];
    // the function start: push ebp / mov ebp,esp / push ecx / push esi / mov esi,ecx, at most 0x90 bytes before
    for (int back = 8; back <= 0x90; back++) {
        uint8_t* p = core - back;
        if (p[0] == 0x55 && p[1] == 0x8B && p[2] == 0xEC && p[3] == 0x51 && p[4] == 0x56 && p[5] == 0x8B && p[6] == 0xF1) {
            // the dt subtraction from the timer must follow: subss xmm0,[ebp+8]
            if (w2scan::FindBytes(p, back, "F3 0F 5C 45 08") < 0) return nullptr;
            return p;
        }
    }
    return nullptr;
}
} // namespace

void W2QteInstall(const char* when) {
    if (g_installed) return;
    int fps = ConfigInt("qte_reference_fps", 30);
    if (fps <= 0) { g_installed = true; LOGI("qte: qte_reference_fps = 0 - mash QTEs left as the game has them"); return; }
    g_refDt = 1.0f / (float)(fps < 10 ? 10 : fps > 240 ? 240 : fps);
    int n = 0;
    uint8_t* f = FindMashUpdate(&n);
    if (!f) { if (!strcmp(when, "device")) LOGW("qte: mash QTE update not found (%d matches) - mash QTEs depend on the frame rate as in the plain game", n); return; }
    if (MH_CreateHook(f, (void*)hMash, (void**)&oMash) == MH_OK && MH_EnableHook(f) == MH_OK) {
        g_installed = true;
        LOGI("qte: mash QTEs frame-rate independent (each press counts as at %d fps) - exe+%lx (%s)", fps,
             (unsigned long)(f - w2scan::ImageBase()), when);
    } else LOGW("qte: hook failed");
}
void W2QteReport() {
    LONG c = InterlockedExchange(&g_calls, 0), s = InterlockedExchange(&g_scaled, 0);
    if (c) LOGI("qte: mash QTE active: %ld updates, %ld with presses kept from the per-frame cap", c, s);
}

// tests: the located function (exe-relative), 0 if not found
extern "C" uint32_t __stdcall W2VR_TestQte() {
    int n = 0; uint8_t* f = FindMashUpdate(&n);
    return f ? (uint32_t)(f - w2scan::ImageBase()) : 0;
}

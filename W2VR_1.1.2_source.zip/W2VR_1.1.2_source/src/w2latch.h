// w2latch.h - same-tick input latch (1.0.8), plain logic so tests/check_input.cpp can run it natively.
// In same-tick stereo every second game tick is "frozen" (the second eye: world clock stopped). The game must only see
// input change on real-time ticks: a frozen tick gets exactly what the previous tick got, and presses made during it
// are delivered with the next real tick - even a tap released before that tick (it then shows as down for one real
// tick, up on the next), so no press is lost and none lands on a frozen tick.
#pragma once
#include <cstdint>
#include <cstring>

namespace w2latch {
struct Pad { uint16_t b; uint8_t lt, rt; int16_t lx, ly, rx, ry; };   // the layout of XINPUT_GAMEPAD
static_assert(sizeof(Pad) == 12, "XINPUT_GAMEPAD layout");

struct PadLatch {
    Pad last = {}; bool have = false, lastOk = false;
    uint16_t latch = 0; uint8_t llt = 0, lrt = 0;
    uint32_t pkt = 1; long latched = 0, held = 0;
    // in / ok: the pad now. Returns whether the game gets a connected pad; out / outPkt: what it gets.
    bool Step(bool frozen, bool ok, const Pad& in, Pad& out, uint32_t& outPkt) {
        if (frozen && have) {
            if (ok && lastOk) {
                latch |= in.b & ~last.b;
                if (in.lt > llt) llt = in.lt;
                if (in.rt > lrt) lrt = in.rt;
            }
            held++;
            out = last; outPkt = pkt; return lastOk;
        }
        Pad f = in;
        if (ok) {
            uint16_t add = latch & ~f.b & ~last.b;      // tapped and released inside a frozen tick
            if (add) { f.b |= add; latched++; }
            if (llt > 30 && f.lt <= 30 && last.lt <= 30) f.lt = llt;
            if (lrt > 30 && f.rt <= 30 && last.rt <= 30) f.rt = lrt;
            if (!lastOk || memcmp(&f, &last, sizeof f)) pkt++;
        } else f = Pad();
        latch = 0; llt = lrt = 0;
        last = f; lastOk = ok; have = true;
        out = f; outPkt = pkt; return ok;
    }
};

// keyboard (DirectInput 256-byte state): same rule per key
struct KeyLatch {
    uint8_t last[256] = {}; uint8_t latch[256] = {}; bool have = false;
    // frozen: k is the live state; replaced by what the game gets
    void Step(bool frozen, uint8_t* k, unsigned n) {
        if (n > 256) n = 256;
        if (frozen && have) {
            for (unsigned i = 0; i < n; i++) if ((k[i] & 0x80) && !(last[i] & 0x80)) latch[i] = 1;
            memcpy(k, last, n); return;
        }
        for (unsigned i = 0; i < n; i++) if (latch[i]) { if (!(last[i] & 0x80) && !(k[i] & 0x80)) k[i] |= 0x80; latch[i] = 0; }
        memcpy(last, k, n); have = true;
    }
};
} // namespace w2latch

// w2mirror.h - keys a controller tool sends together with a pad button (1.1.0), plain logic for tests/check_mirror.cpp.
// A key's press "comes with" a button when the button is down or was pressed within 250 ms. A key is learned for a
// button once it came with it at least twice and in at least 80 % of its presses; from then on its presses that come
// with that button are hidden. Presses without the button (typed on the keyboard) always reach the game.
#pragma once
#include <cstdint>

namespace w2mirror {
struct Learner {
    uint16_t pair[256][16] = {}; uint16_t downs[256] = {};
    uint16_t learned[256] = {};     // button mask per key
    bool preset[256] = {};          // configured: hide when it comes with any button
    // a key's down edge; near = the pad buttons down now or pressed within 250 ms. Returns: hide it. *newBtn = a button
    // just learned for this key (-1 none)
    bool Press(int key, uint16_t near_, int* newBtn) {
        if (newBtn) *newBtn = -1;
        if (key <= 0 || key > 255) return false;
        if (downs[key] < 60000) downs[key]++;
        for (int b = 0; b < 16; b++) if (near_ & (1 << b)) {
            if (pair[key][b] < 60000) pair[key][b]++;
            if (!(learned[key] & (1 << b)) && pair[key][b] >= 2 && pair[key][b] * 10 >= downs[key] * 8) {
                learned[key] |= (uint16_t)(1 << b);
                if (newBtn) *newBtn = b;
            }
        }
        return (learned[key] & near_) || (preset[key] && near_);
    }
};
} // namespace w2mirror

// Pacing / headset-smoothing policy (src/w2pace.h), simulated against a model of a game and an OpenXR runtime whose
// smoothing drops in when the game misses the full rate and out when it keeps up again. Checks:
//  * the frame cap is never below the headset's full refresh (smoothing never halves the game) - also when the
//    runtime is already at half rate at the start (smoothing forced on);
//  * auto picks full stereo while the runtime smooths, same-tick at full refresh;
//  * no lock-in: after a heavy scene the game returns to same-tick and the runtime to its full rate;
//  * no flapping: switches are rare;
//  * "off": never full stereo, cap still the full rate.
#include "w2pace.h"
#include <cstdio>
#include <vector>
#include <string>
using namespace w2pace;
struct Load { double untilS, sim, render; };   // ms per tick of game simulation, ms per eye of rendering
struct Result { int switches = 0, trials = 0; double minCap = 1e9; double endHz = 0; int endState = -1; double fullStereoShare = 0; double pairsPerS = 0; };
static Result Run(double panelHz, std::vector<Load> loads, bool follow, bool forcedSmoothing, Limit lim = Limit::Headset, bool verbose = false) {
    Pacer p; Result r;
    double t = 0, curHz = forcedSmoothing ? panelHz / 2 : panelHz;
    bool smoothing = forcedSmoothing; double winStart = 0; int winFrames = 0; double goodSince = -1;
    int lastState = -1; size_t li = 0; bool sameTickSecond = false; double fsTime = 0, total = 0; double pairs = 0;
    while (t < loads.back().untilS * 1000) {
        while (t > loads[li].untilS * 1000) li++;
        const Load& L = loads[li];
        int method = p.state < 0 ? 0 : p.state;
        // the cost of this presented frame
        double cost;
        if (method == 1) cost = L.sim + 2 * L.render;                               // full stereo: one tick, both eyes
        else { cost = sameTickSecond ? L.render : L.sim + L.render; sameTickSecond = !sameTickSecond; }   // same-tick
        double cap = p.CapHz(lim, 0, curHz);
        if (cap > 0 && cap < r.minCap) r.minCap = cap;
        double frame = cap > 0 ? std::max(cost, 1000.0 / cap) : cost;
        t += frame; total += frame; if (method == 1) { fsTime += frame; pairs += 1; } else pairs += 0.5;
        // the runtime: counts new frames per second; smoothing on below 90 % of the panel rate, off again when the
        // game's frame rate (what it could deliver) holds 95 % for 2 s
        winFrames++;
        if (t - winStart >= 1000) {
            double fps = winFrames * 1000.0 / (t - winStart); winStart = t; winFrames = 0;
            if (!forcedSmoothing) {
                if (!smoothing && fps < panelHz * 0.9) { smoothing = true; goodSince = -1; }
                else if (smoothing) { if (fps >= panelHz * 0.95) { if (goodSince < 0) goodSince = t; if (t - goodSince >= 2000) smoothing = false; } else goodSince = -1; }
            }
            curHz = smoothing ? panelHz / 2 : panelHz;
        }
        double trialBefore = p.trialUntil;
        int w = p.Update(t, curHz, frame, follow);
        if (p.trialUntil > 0 && trialBefore == 0) r.trials++;
        if (w >= 0 && w != lastState && lastState >= 0) { r.switches++; if (verbose) printf("   %6.1f s: -> %s (runtime %.0f Hz, frame %.1f ms)\n", t / 1000, w ? "full stereo" : "same-tick", curHz, frame); }
        if (w >= 0) lastState = w;
    }
    r.endHz = curHz; r.endState = p.state; r.fullStereoShare = fsTime / total; r.pairsPerS = pairs / (total / 1000);
    return r;
}
int main() {
    int fails = 0;
    auto check = [&](bool ok, const char* what) { if (!ok) { printf("  FAIL: %s\n", what); fails++; } };
    const double rates[] = { 72, 80, 90, 120, 144 };
    for (double hz : rates) {
        printf("headset %.0f Hz\n", hz);
        double period = 1000 / hz;
        // 1. light scene: same-tick at full rate the whole time
        Result a = Run(hz, { { 120, period * 0.25, period * 0.3 } }, true, false);
        printf("  light scene:           cap >= %.0f, switches %d, end %s at %.0f Hz\n", a.minCap, a.switches, a.endState ? "full stereo" : "same-tick", a.endHz);
        check(a.minCap >= hz - 0.01, "cap below the full rate"); check(a.switches == 0 && a.endState == 0 && a.endHz == hz, "light scene not same-tick at full rate");
        // 2. heavy fight, then light again: full stereo during the fight, back to same-tick + full rate after
        Result b = Run(hz, { { 30, period * 0.25, period * 0.3 }, { 150, period * 0.6, period * 0.7 }, { 300, period * 0.25, period * 0.3 } }, true, false, Limit::Headset, true);
        printf("  fight then calm:       cap >= %.0f, switches %d, trials %d, end %s at %.0f Hz\n", b.minCap, b.switches, b.trials, b.endState ? "full stereo" : "same-tick", b.endHz);
        check(b.minCap >= hz - 0.01, "cap below the full rate during smoothing"); check(b.endState == 0 && b.endHz == hz, "locked in full stereo / smoothing after the fight");
        check(b.switches <= 6, "too many switches");
        // 3. runtime smoothing forced on from the start (reports half rate all the time)
        Result c = Run(hz, { { 600, period * 0.3, period * 0.4 } }, true, true);
        printf("  smoothing forced on:   cap >= %.0f (runtime reports %.0f), end %s, %.1f eye pairs/s, %d trials in 10 min\n", c.minCap, hz / 2, c.endState ? "full stereo" : "same-tick", c.pairsPerS, c.trials);
        check(c.minCap >= hz - 0.01 || hz / 2 > 60.5, "half-rate start capped the game at half rate");
        check(c.trials <= 4, "too many same-tick trials while the runtime keeps its smoothing on");
        if (hz / 2 > 60.5) printf("  (a %.0f Hz headset that starts at %.0f Hz cannot be told from a real %.0f Hz one; it is uncapped as soon as it reports %.0f Hz once)\n", hz, hz / 2, hz / 2, hz);
        // 4. headset smoothing setting off: never full stereo, cap still full
        Result d = Run(hz, { { 30, period * 0.25, period * 0.3 }, { 150, period * 0.6, period * 0.7 }, { 200, period * 0.25, period * 0.3 } }, false, false);
        printf("  smoothing setting off: cap >= %.0f, full stereo share %.0f %%\n", d.minCap, d.fullStereoShare * 100);
        check(d.minCap >= hz - 0.01 && d.fullStereoShare == 0, "off mode used full stereo or a lower cap");
        // 5. the switch does not lose eye pairs: same load, auto vs off, while the runtime smooths
        Result e1 = Run(hz, { { 120, period * 0.6, period * 0.7 } }, true, false), e2 = Run(hz, { { 120, period * 0.6, period * 0.7 } }, false, false);
        printf("  heavy scene eye pairs/s: auto %.1f, off %.1f\n", e1.pairsPerS, e2.pairsPerS);
        check(e1.pairsPerS >= e2.pairsPerS * 0.97, "auto delivers fewer eye pairs than same-tick");
    }
    // 6. runtime noise: a single spike or a stalled frame does not move the full rate
    {   Pacer p; for (int i = 0; i < 200; i++) p.FullHz(72.0 + (i % 3) * 0.05);
        p.FullHz(500); p.FullHz(180); p.FullHz(0.5); p.FullHz(0);
        for (int i = 0; i < 10; i++) p.FullHz(36);
        double f = p.FullHz(72);
        printf("noise: full rate after spikes / stalls %.1f Hz\n", f);
        check(f > 71.9 && f < 72.3, "spike or stall changed the full rate");
        for (int i = 0; i < 40; i++) p.FullHz(90);   // a real change of the refresh rate is followed
        check(p.FullHz(90) > 89.9, "a lasting higher rate was not taken");
    }
    // 6. other caps
    { Pacer p; check(p.CapHz(Limit::HeadsetX2, 0, 36) == 144, "x2 from a half-rate start"); check(p.CapHz(Limit::Fixed, 60, 36) == 60, "fixed cap"); check(p.CapHz(Limit::Off, 0, 36) == 0, "off"); }
    printf("RESULT: %s\n", fails ? "FAIL" : "PASS");
    return fails ? 1 : 0;
}

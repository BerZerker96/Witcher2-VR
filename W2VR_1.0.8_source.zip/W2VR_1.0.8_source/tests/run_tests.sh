#!/bin/bash
# Offline checks of the W2VR engine camera against the game's own code (no game run needed).
#   W2_UNPACKED=/path/to/witcher2_unpacked.exe [W2_GOG=/path/to/gog/witcher2.exe] tests/run_tests.sh
# needs: python3 with numpy, unicorn, capstone, pefile; g++; the DLL built by scripts/build.sh. The exe must be YOUR
# copy, decrypted locally (the Steam exe's code is encrypted by SteamStub 2.1; Steamless decrypts a copy).
set -e
cd "$(dirname "$0")"
mkdir -p build
g++ -O2 -shared -fPIC -std=c++17 -I../src -I../third_party/xrbridge/include compose_shim.cpp -o build/libw2compose.so
g++ -O2 -shared -fPIC -std=c++17 -I../src -I../third_party/xrbridge/include detect_shim.cpp ../src/stereo.cpp -o build/libw2detect.so
g++ -O2 -std=c++17 -I../src check_pacing.cpp -o build/check_pacing
./build/check_pacing
g++ -O2 -std=c++17 -I../src -include cstring check_input.cpp -o build/check_input
./build/check_input
python3 check_camera.py 400
python3 check_detect.py
python3 check_dll_hook.py
python3 check_sametick.py
python3 check_letterbox.py
python3 check_dof.py
python3 check_fullstereo.py
python3 check_compat.py
python3 check_dither.py
python3 check_locate.py "$W2_UNPACKED" steam
python3 check_qte.py "$W2_UNPACKED" steam
# a second build (GOG): W2_GOG=/path/to/gog/witcher2.exe (not packed - no decryption needed)
python3 check_ctor.py steam
if [ -n "$W2_GOG" ]; then
  python3 check_locate.py "$W2_GOG" gog
  python3 check_qte.py "$W2_GOG" gog
  for t in check_letterbox.py check_dof.py check_compat.py check_dither.py check_sametick.py; do W2_UNPACKED="$W2_GOG" python3 $t; done
  W2_UNPACKED="$W2_GOG" python3 check_ctor.py gog
  W2_UNPACKED="$W2_GOG" python3 check_fullstereo_gog.py
  python3 check_gog_builder.py "$W2_UNPACKED" "$W2_GOG"
  python3 check_gog_info.py "$W2_UNPACKED" "$W2_GOG" ../build/xinput1_3.dll
  W2_UNPACKED="$W2_GOG" python3 check_dll_hook_gog.py
fi

// w2pace.h - frame pacing and the headset-smoothing response, as one small state machine (no Windows / D3D), so it
// can be tested on its own (tests/check_pacing.cpp).
//
// Rule (1.0.8): headset smoothing never slows the game down.
//  * The frame cap is always the headset's FULL refresh rate (or twice it, or the user's number). Runtimes report half
//    the rate while their smoothing runs (Pimax Smart Smoothing, SteamVR Motion Smoothing, Oculus ASW: 72 -> 36 Hz);
//    the cap ignores that. A runtime that is already at a reduced rate when the game starts (smoothing forced on) is
//    recognised too: a rate of 60 Hz or less is taken as half of the real one.
//  * The game never waits for the headset (a busy slot is skipped, not waited for), so the runtime's own pacing never
//    reaches the game either.
//  * Smoothing only decides HOW the eyes are drawn (stereo method auto): while the headset synthesises frames it needs
//    both eyes from the same moment -> full stereo; at full refresh -> same-tick (one new eye per display frame). Both
//    give the same number of eye pairs per second for the same GPU work, so the switch costs nothing.
//  * Full stereo can lock itself in: the runtime only leaves smoothing when the app keeps up, and the app is in full
//    stereo because the runtime smooths. So when full-stereo frames are fast enough that same-tick would hold the full
//    rate (half a full-stereo frame + 10 % < 85 % of the full period), same-tick is tried for 10 s; if the headset is
//    back at its full rate it stays. At most one trial a minute; after a failed one the wait doubles (up to 10 min).
#pragma once
#include <cmath>
#include <algorithm>

namespace w2pace {

enum class Limit { Off, Headset, HeadsetX2, Fixed };

struct Pacer {
    // ---- inputs that persist
    double maxHz = 0;                 // highest rate the runtime reported
    // ---- stereo method state (auto)
    int state = -1;                   // -1 not decided, 0 same-tick, 1 full stereo
    double pendingSince = 0;          // a change wanted since (ms)
    int pendingWant = -1;
    double trialUntil = 0, lastTrial = -1e12; int trialFails = 0;   // a failed trial doubles the wait (1, 2, 4 ... 10 min)
    double methodSince = 0;           // current method since (ms)
    double emaFrameMs = 0;            // frame (present-to-present) time in the current method
    int emaN = 0;

    // the headset's full refresh rate, never the reduced smoothing rate
    double candHz = 0; int candN = 0;   // a higher rate counts once it was reported 30 times in a row (within 3 %)
    double FullHz(double curHz) {
        if (curHz < 30 || curHz > 250) curHz = 0;   // nonsense from a runtime (0, a stalled frame, a spike) is ignored
        if (curHz > maxHz) {
            if (maxHz <= 0) maxHz = curHz;                                   // the first rate is taken as it is
            else if (candHz > 0 && std::fabs(curHz / candHz - 1) < 0.03) { if (++candN >= 30) { maxHz = std::max(maxHz, candHz); candN = 0; } }
            else { candHz = curHz; candN = 1; }
        } else candN = 0;
        double hz = maxHz;
        // 36 / 40 / 45 / 50 / 60 = half of 72 / 80 / 90 / 100 / 120. A real 60 Hz headset then gets a 120 cap: the game may
        // draw more frames than it shows, never fewer.
        if (curHz > 0 && curHz <= 60.5) hz = std::max(hz, 2 * curHz);
        return hz > 0 ? hz : 90.0;
    }
    bool Reduced(double curHz) { double f = FullHz(curHz); return curHz > 0 && curHz < f * 0.75; }

    // the cap for the frame limiter: never below the full refresh rate
    double CapHz(Limit lim, double fixedHz, double curHz) {
        double full = FullHz(curHz);
        switch (lim) {
            case Limit::Off: return 0;
            case Limit::Headset: return full;
            case Limit::HeadsetX2: return full * 2;
            case Limit::Fixed: return fixedHz >= 10 ? fixedHz : 0;
        }
        return 0;
    }

    // per presented frame: the stereo method auto wants (0 same-tick, 1 full stereo), or -1 to keep the current one.
    // follow = false: smoothing is ignored (always same-tick).
    int Update(double nowMs, double curHz, double frameMs, bool follow) {
        if (frameMs > 0 && frameMs < 500 && nowMs - methodSince > 2000) {   // settle 2 s after a switch, then average
            emaFrameMs = emaN ? emaFrameMs * 0.95 + frameMs * 0.05 : frameMs; emaN++;
        }
        bool reduced = follow && Reduced(curHz);
        int want = reduced ? 1 : 0;
        const double full = FullHz(curHz), periodMs = 1000.0 / full;
        if (state < 0) { Switch(want, nowMs); return want; }
        // a same-tick trial runs out: keep it if the headset is at its full rate again, else back to full stereo
        if (trialUntil > 0) {
            if (nowMs < trialUntil) return -1;
            trialUntil = 0;
            if (!reduced) { trialFails = 0; pendingWant = -1; return -1; }   // back at full refresh: same-tick it is
            trialFails++; Switch(1, nowMs); return 1;
        }
        // full stereo while smoothing: could same-tick hold the full rate? then try it
        if (state == 1 && reduced && emaN > 60 && emaFrameMs * 0.55 < periodMs * 0.85 && nowMs - lastTrial > std::min(600000.0, 60000.0 * (1 << std::min(trialFails, 4)))) {
            lastTrial = nowMs; trialUntil = nowMs + 10000;
            Switch(0, nowMs); return 0;
        }
        if (want == state) { pendingWant = -1; return -1; }
        if (pendingWant != want) { pendingWant = want; pendingSince = nowMs; return -1; }
        if (nowMs - pendingSince < 1500) return -1;           // 1.5 s in the new state before switching
        Switch(want, nowMs); return want;
    }
    void Switch(int to, double nowMs) { state = to; methodSince = nowMs; pendingWant = -1; emaN = 0; emaFrameMs = 0; }
};

}  // namespace w2pace

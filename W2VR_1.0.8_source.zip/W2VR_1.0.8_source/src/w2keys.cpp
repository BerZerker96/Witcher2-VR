// w2keys.cpp - keyboard compatibility (1.0.8).
//
// The Witcher 2 reads the keyboard through DirectInput (DIK codes, bound in Documents\Witcher 2\Config\Input_*.ini /
// User.ini as IK_<key>=(GameKey=...)). The mod reads its own keys with GetAsyncKeyState. Without care:
//  * while the VR panel is open, its keys (arrows, Enter, Backspace, Page Up / Down, Delete) also moved Geralt or
//    pressed game buttons, and the mouse turned the camera;
//  * a key held when the panel closed (Enter) reached the game as a fresh press;
//  * a mod hotkey the player had also bound in the game did both things at once;
//  * the mod's hotkeys fired while typing in another window (GetAsyncKeyState sees every key in Windows).
// Now:
//  * panel open: the game sees no keyboard and no mouse input; after closing, keys still held stay hidden until released;
//  * the mod's hotkeys are the mod's: hidden from the game (keyboard_exclusive_hotkeys = true); a clash with the
//    player's own bindings is logged at start;
//  * the mod's keys only act while the game window (or the VR panel host) is in front.
#include <windows.h>
#include <string>
#include <vector>
#include <cstring>
#include "log.h"
#include "config.h"

bool MenuIsOpen();
HWND W2GameWindow();
std::wstring DocumentsDir();

namespace {
bool g_exclusive = true;
bool g_hotDik[256] = {};          // the mod's hotkeys (DIK codes)
bool g_heldAtClose[256] = {};     // held when the panel closed: hidden until released
bool g_wasOpen = false;
volatile LONG g_blockedReads = 0, g_hotHidden = 0;

int DikFromVk(int vk) {
    UINT sc = MapVirtualKeyW((UINT)vk, 4 /* MAPVK_VK_TO_VSC_EX */);
    if (!sc) return -1;
    int dik = (int)(sc & 0x7F) | ((sc & 0xFF00) ? 0x80 : 0);
    // keys MapVirtualKey reports without the E0 prefix but DirectInput codes as extended
    switch (vk) { case VK_HOME: case VK_END: case VK_INSERT: case VK_DELETE: case VK_PRIOR: case VK_NEXT:
                  case VK_UP: case VK_DOWN: case VK_LEFT: case VK_RIGHT: dik = (int)(sc & 0x7F) | 0x80; break; }
    return dik & 0xFF;
}
int VkFromDik(int dik) {
    UINT sc = (UINT)(dik & 0x7F) | ((dik & 0x80) ? 0xE000 : 0);
    return (int)MapVirtualKeyW(sc, 3 /* MAPVK_VSC_TO_VK_EX */);
}
void PanelClosedNow() {
    for (int d = 1; d < 256; d++) { int vk = VkFromDik(d); g_heldAtClose[d] = vk && (GetAsyncKeyState(vk) & 0x8000); }
}
// keys the game must not see right now
bool Hidden(int dik, bool down) {
    if (dik <= 0 || dik > 255) return false;
    if (g_heldAtClose[dik]) { if (!down) g_heldAtClose[dik] = false; return down; }
    return g_exclusive && g_hotDik[dik];
}
void Track() {
    bool open = MenuIsOpen();
    if (g_wasOpen && !open) PanelClosedNow();
    g_wasOpen = open;
}
const char* const kNames[] = { "Insert (VR panel)", "F8 (VR mode)", "F10 (diagnostic images)" };
}

// the game reading the keyboard / mouse state: called by the DirectInput hooks (w2engine.cpp)
void W2KeysFilterState(bool keyboard, bool mouse, void* data, DWORD cb) {
    if (!data || !cb) return;
    Track();
    if (MenuIsOpen()) { if (keyboard || mouse) { memset(data, 0, cb); InterlockedIncrement(&g_blockedReads); } return; }
    if (!keyboard || cb < 256) return;
    uint8_t* k = (uint8_t*)data;
    for (int d = 1; d < 256; d++) if (Hidden(d, (k[d] & 0x80) != 0)) { k[d] = 0; InterlockedIncrement(&g_hotHidden); }
}
// buffered input (DIDEVICEOBJECTDATA: dwOfs = DIK code for a keyboard, dwData & 0x80 = down)
void W2KeysFilterData(bool keyboard, bool mouse, DWORD cbObj, void* rg, DWORD* n) {
    if (!rg || !n || !*n || cbObj < 8) return;
    Track();
    if (MenuIsOpen()) { if (keyboard || mouse) { *n = 0; InterlockedIncrement(&g_blockedReads); } return; }
    if (!keyboard) return;
    uint8_t* p = (uint8_t*)rg; DWORD out = 0;
    for (DWORD i = 0; i < *n; i++) {
        DWORD ofs, val; memcpy(&ofs, p + i * cbObj, 4); memcpy(&val, p + i * cbObj + 4, 4);
        if (Hidden((int)ofs, (val & 0x80) != 0)) { InterlockedIncrement(&g_hotHidden); continue; }
        if (out != i) memmove(p + out * cbObj, p + i * cbObj, cbObj);
        out++;
    }
    *n = out;
}

// the mod's own keys act only while the game is the window in front (or one of the process' own windows)
bool W2KeysGameInFront() {
    HWND fg = GetForegroundWindow();
    if (!fg) return false;
    DWORD pid = 0; GetWindowThreadProcessId(fg, &pid);
    return pid == GetCurrentProcessId();
}

// called once at start with the mod's hotkeys (virtual-key codes): marks them, then checks the player's bindings
void W2KeysInstall(const std::vector<std::pair<int, std::string>>& hot) {
    g_exclusive = ConfigBool("keyboard_exclusive_hotkeys", true);
    for (auto& h : hot) { int d = h.first ? DikFromVk(h.first) : -1; if (d > 0) g_hotDik[d] = true; }
    // the player's bindings: IK_<Name>=(GameKey=...) in the game's input files
    std::wstring dir = DocumentsDir() + L"\\Witcher 2\\Config\\";
    const wchar_t* files[] = { L"Input_QWERTY.ini", L"Input_AZERTY.ini", L"Input_QWERTZ.ini", L"User.ini" };
    struct IkName { const char* ik; int vk; } ik[] = { { "IK_Insert", VK_INSERT }, { "IK_Home", VK_HOME }, { "IK_End", VK_END }, { "IK_Delete", VK_DELETE },
        { "IK_PageUp", VK_PRIOR }, { "IK_PageDown", VK_NEXT }, { "IK_F1", VK_F1 }, { "IK_F2", VK_F2 }, { "IK_F3", VK_F3 }, { "IK_F4", VK_F4 }, { "IK_F5", VK_F5 },
        { "IK_F6", VK_F6 }, { "IK_F7", VK_F7 }, { "IK_F8", VK_F8 }, { "IK_F9", VK_F9 }, { "IK_F10", VK_F10 }, { "IK_F11", VK_F11 }, { "IK_F12", VK_F12 },
        { "IK_Space", VK_SPACE }, { "IK_Pause", VK_PAUSE }, { "IK_ScrollLock", VK_SCROLL } };
    int clashes = 0;
    for (const wchar_t* f : files) {
        HANDLE h = CreateFileW((dir + f).c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
        if (h == INVALID_HANDLE_VALUE) continue;
        std::string t; char b[8192]; DWORD r;
        while (ReadFile(h, b, sizeof b, &r, nullptr) && r) t.append(b, r);
        CloseHandle(h);
        if (t.size() >= 2 && (uint8_t)t[0] == 0xFF && (uint8_t)t[1] == 0xFE) { std::string a; for (size_t i = 2; i + 1 < t.size(); i += 2) a += t[i]; t = a; }   // UTF-16
        size_t pos = 0;
        while ((pos = t.find("IK_", pos)) != std::string::npos) {
            size_t eq = t.find('=', pos), nl = t.find_first_of("\r\n", pos);
            if (eq == std::string::npos || (nl != std::string::npos && eq > nl)) { pos += 3; continue; }
            std::string name = t.substr(pos, eq - pos);
            std::string act = t.substr(eq + 1, (nl == std::string::npos ? t.size() : nl) - eq - 1);
            pos = eq;
            if (act.find("GameKey") == std::string::npos && act.find("Gamekey") == std::string::npos) continue;
            for (auto& k : ik) {
                if (_stricmp(name.c_str(), k.ik)) continue;
                for (auto& hk : hot) if (hk.first == k.vk) {
                    clashes++;
                    if (clashes <= 8) {
                        char fn[64]; WideCharToMultiByte(CP_UTF8, 0, f, -1, fn, sizeof fn, nullptr, nullptr);
                        LOGW("keys: %s is bound in the game too (%s: %s=%s)%s", hk.second.c_str(), fn, name.c_str(), act.substr(0, 60).c_str(),
                             g_exclusive ? " - the mod's key wins, the game does not see it; change the mod's key in w2vr_config.txt to keep the game's" : " - both act (keyboard_exclusive_hotkeys = false)");
                    }
                }
            }
        }
    }
    int n = 0; for (bool b : g_hotDik) n += b;
    LOGI("keys: %d mod hotkeys%s; %d clash(es) with the game's bindings; while the VR panel is open the game sees no keyboard / mouse input",
         n, g_exclusive ? " (hidden from the game)" : "", clashes);
    (void)kNames;
}
void W2KeysReport() {
    LONG b = InterlockedExchange(&g_blockedReads, 0), h = InterlockedExchange(&g_hotHidden, 0);
    if (b || h) LOGI("keys: %ld game input reads blanked while the VR panel was open, %ld mod-hotkey presses kept from the game", b, h);
}

// w2pads.cpp - controllers (1.0.8).
//
// The Witcher 2 reads one pad: XInputGetState(0), through this DLL (the xinput1_3 proxy). On its own that means:
//  * only the controller in slot 1 works. A pad that Windows put in slot 2-4 (a second receiver, DS4Windows / Steam
//    Input / reWASD virtual pads next to a real one, a pad reconnected after sleep) does nothing;
//  * controllers that are not XInput (PlayStation DualShock 4 / DualSense, Switch Pro, generic USB pads) do nothing
//    without Steam Input or DS4Windows.
// Now the game's pad 0 is "the controller you are using": any XInput slot (the one with the latest input wins), else
// a DirectInput controller mapped to the Xbox layout. Vibration goes to the same XInput pad.
//
// Same-tick stereo (QTE fix): in same-tick mode every second game tick runs with the world's clock stopped (the second
// eye). A button press or release that the game first saw in such a tick happened at "no time": button-mash QTEs
// (X / Square) and quick taps lost presses. Now pad, keyboard and mouse input only change on real-time ticks: a
// frozen tick sees exactly what the tick before it saw, and a press made during it is delivered with the next real
// tick (latched, so even a very short tap is never lost). The keyboard / mouse half lives in w2engine.cpp.
#include <windows.h>
#include <xinput.h>
#define DIRECTINPUT_VERSION 0x0800
#include <dinput.h>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include "log.h"
#include "config.h"
#include "w2vr.h"
#include "../third_party/vrkit/vrkit_input.h"
#include "w2latch.h"
#include "w2padmap.h"
#include "MinHook.h"

HWND W2GameWindow();
uint32_t W2HotkeysPadHide(uint32_t buttons);   // w2hotkeys.cpp
extern "C" { extern FARPROC g_px[12]; }

namespace {
typedef DWORD (WINAPI* GetFn)(DWORD, XINPUT_STATE*);
typedef DWORD (WINAPI* SetFn)(DWORD, XINPUT_VIBRATION*);
GetFn g_get = nullptr; SetFn g_set = nullptr;
CRITICAL_SECTION g_cs; bool g_csInit = false;
int g_forceSlot = -1;          // pad_slot = 1..4
bool g_latchOn = true, g_diOn = true;

// ---------------------------------------------------------------- XInput slots
unsigned g_known = 0;          // slots last seen connected
DWORD g_lastScan = 0, g_lastActive[4] = {};
int g_slot = 0;                // the pad the game gets
volatile LONG g_xiConnected = 0;   // any XInput pad connected (the DirectInput side stays idle while one is)
bool HasInput(const XINPUT_GAMEPAD& g) {
    return g.wButtons || g.bLeftTrigger > 30 || g.bRightTrigger > 30 || abs(g.sThumbLX) > 9000 || abs(g.sThumbLY) > 9000 || abs(g.sThumbRX) > 9000 || abs(g.sThumbRY) > 9000;
}
// reads the active pad; false if no XInput pad is connected. Empty slots are slow to query (XInput looks for the
// device each time), so they are only scanned once a second (every 3 s while a pad is connected).
bool ReadXI(XINPUT_STATE* out) {
    if (!g_get) return false;
    if (g_forceSlot >= 0) { bool ok = g_get(g_forceSlot, out) == ERROR_SUCCESS; g_slot = g_forceSlot; InterlockedExchange(&g_xiConnected, ok); return ok; }
    DWORD now = GetTickCount();
    XINPUT_STATE t[4] = {};
    bool ok[4] = {};
    for (int s = 0; s < 4; s++) if (g_known & (1u << s)) {
        ok[s] = g_get(s, &t[s]) == ERROR_SUCCESS;
        if (!ok[s]) g_known &= ~(1u << s);
        else if (HasInput(t[s].Gamepad)) g_lastActive[s] = now ? now : 1;
    }
    if (now - g_lastScan >= (g_known ? 3000u : 1000u)) {
        g_lastScan = now;
        for (int s = 0; s < 4; s++) if (!(g_known & (1u << s)) && g_get(s, &t[s]) == ERROR_SUCCESS) {
            g_known |= 1u << s; ok[s] = true;
            LOGI("pad: XInput controller in slot %d", s + 1);
        }
    }
    InterlockedExchange(&g_xiConnected, g_known != 0);
    if (!g_known) return false;
    // the pad with the latest input wins; otherwise stay on the current one
    int best = ok[g_slot] ? g_slot : -1;
    for (int s = 0; s < 4; s++) {
        if (!ok[s]) continue;
        if (best < 0) { best = s; continue; }
        if (g_lastActive[s] && (LONG)(g_lastActive[s] - g_lastActive[best]) > 0) best = s;
    }
    if (best < 0) return false;
    if (best != g_slot) { LOGI("pad: the game now reads the controller in slot %d", best + 1); g_slot = best; }
    *out = t[best];
    return ok[best];
}

// ---------------------------------------------------------------- DirectInput controllers (not XInput)
typedef HRESULT (WINAPI* DI8CreateFn)(HINSTANCE, DWORD, REFIID, void**, void*);
struct DiPad {
    IDirectInputDevice8W* dev = nullptr;
    GUID guid = {};
    int layout = 0;            // 0 generic, 1 PlayStation, 2 Nintendo
    w2padmap::Layout map = {};
    bool hasZ = false, hasRz = false, hasRx = false, hasRy = false;
    bool gamepad = false;      // DI8DEVTYPE_GAMEPAD (joysticks / wheels are used only while no gamepad is open)
    bool zCentred = false;     // Z rested near the middle when opened: may be a combined trigger axis
    w2padmap::Pad prev = {};
    char name[96] = {};
};
IDirectInput8W* g_di = nullptr;
DiPad g_pads[4];               // 1.1.4: up to four DirectInput controllers; the one with the latest input is used
int g_padCur = -1;
SRWLOCK g_diLock = SRWLOCK_INIT;
XINPUT_GAMEPAD g_diState = {}; bool g_diValid = false;
std::string g_cfgLayout = "auto", g_cfgRight = "auto", g_cfgTrig = "auto", g_cfgButtons;

const GUID kIID_DI8W = { 0xBF798031, 0x483A, 0x4DA2, { 0xAA, 0x99, 0x5D, 0x64, 0xED, 0x36, 0x97, 0x00 } };

void SetLayout(DiPad& p) {
    p.map = w2padmap::ForLayout(p.layout);
    if (!g_cfgButtons.empty()) {   // dinput_pad_buttons = A,B,X,Y,LB,RB,Back,Start,LS,RS[,LT,RT] (1-based button numbers)
        const char* c = g_cfgButtons.c_str();
        for (int i = 0; i < 12 && *c; i++) {
            int v = atoi(c);
            if (v > 0 && v <= 128) { if (i < 10) p.map.btn[i] = v - 1; else if (i == 10) p.map.lt = v - 1; else p.map.rt = v - 1; }
            while (*c && *c != ',') c++; if (*c == ',') c++;
        }
    }
}
BOOL CALLBACK EnumPad(const DIDEVICEINSTANCEW* inst, void* ctx) {
    auto* found = (std::vector<DIDEVICEINSTANCEW>*)ctx;
    found->push_back(*inst);
    return DIENUM_CONTINUE;
}
bool IsXInputDevice(IDirectInputDevice8W* d) {
    DIPROPGUIDANDPATH gp = {}; gp.diph.dwSize = sizeof gp; gp.diph.dwHeaderSize = sizeof(DIPROPHEADER); gp.diph.dwHow = DIPH_DEVICE;
    if (FAILED(d->GetProperty(DIPROP_GUIDANDPATH, &gp.diph))) return false;
    for (const wchar_t* p = gp.wszPath; *p; p++) if ((p[0] == L'I' || p[0] == L'i') && (p[1] == L'G' || p[1] == L'g') && p[2] == L'_') return true;   // "IG_" = an XInput interface
    return false;
}
bool HasAxis(IDirectInputDevice8W* d, DWORD ofs) {
    DIDEVICEOBJECTINSTANCEW oi = {}; oi.dwSize = sizeof oi;
    return SUCCEEDED(d->GetObjectInfo(&oi, ofs, DIPH_BYOFFSET));
}
void ClosePad(int i) {
    if (g_pads[i].dev) { g_pads[i].dev->Unacquire(); g_pads[i].dev->Release(); }
    g_pads[i] = DiPad();
}
void CloseAllPads() {
    AcquireSRWLockExclusive(&g_diLock); g_diValid = false; ReleaseSRWLockExclusive(&g_diLock);
    for (int i = 0; i < 4; i++) ClosePad(i);
    g_padCur = -1;
}
int OpenCount() { int n = 0; for (auto& p : g_pads) n += p.dev != nullptr; return n; }
// opens the attached controllers not yet open (gamepads first, then joysticks / wheels), up to four
void OpenPads() {
    std::vector<DIDEVICEINSTANCEW> found;
    if (FAILED(g_di->EnumDevices(DI8DEVCLASS_GAMECTRL, EnumPad, &found, DIEDFL_ATTACHEDONLY))) return;
    HWND w = W2GameWindow();
    if (!w) return;
    struct Cand { DIDEVICEINSTANCEW inst; int score; };
    std::vector<Cand> c;
    for (auto& inst : found) {
        bool open = false; for (auto& p : g_pads) if (p.dev && IsEqualGUID(p.guid, inst.guidInstance)) open = true;
        if (open) continue;
        BYTE type = GET_DIDEVICE_TYPE(inst.dwDevType);
        if (type != DI8DEVTYPE_GAMEPAD && type != DI8DEVTYPE_JOYSTICK && type != DI8DEVTYPE_1STPERSON && type != DI8DEVTYPE_SUPPLEMENTAL) continue;
        WORD vid = LOWORD(inst.guidProduct.Data1);   // DirectInput product GUIDs carry the VID / PID in Data1
        c.push_back({ inst, w2padmap::Score(type == DI8DEVTYPE_GAMEPAD, type == DI8DEVTYPE_JOYSTICK, vid) });
    }
    for (size_t i = 0; i < c.size(); i++) for (size_t j = i + 1; j < c.size(); j++) if (c[j].score > c[i].score) std::swap(c[i], c[j]);
    for (auto& cd : c) {
        int slot = -1; for (int i = 0; i < 4; i++) if (!g_pads[i].dev) { slot = i; break; }
        if (slot < 0) return;
        const DIDEVICEINSTANCEW& inst = cd.inst;
        IDirectInputDevice8W* d = nullptr;
        if (FAILED(g_di->CreateDevice(inst.guidInstance, &d, nullptr)) || !d) continue;
        if (IsXInputDevice(d)) { d->Release(); continue; }    // an Xbox-type pad: XInput already has it
        if (FAILED(d->SetDataFormat(&c_dfDIJoystick2)) || FAILED(d->SetCooperativeLevel(w, DISCL_BACKGROUND | DISCL_NONEXCLUSIVE))) { d->Release(); continue; }
        DIPROPRANGE r = {}; r.diph.dwSize = sizeof r; r.diph.dwHeaderSize = sizeof(DIPROPHEADER); r.diph.dwHow = DIPH_DEVICE; r.lMin = -32768; r.lMax = 32767;
        d->SetProperty(DIPROP_RANGE, &r.diph);
        DIPROPDWORD dz = {}; dz.diph.dwSize = sizeof dz; dz.diph.dwHeaderSize = sizeof(DIPROPHEADER); dz.diph.dwHow = DIPH_DEVICE; dz.dwData = 0;
        d->SetProperty(DIPROP_DEADZONE, &dz.diph);
        DIPROPDWORD vp = {}; vp.diph.dwSize = sizeof vp; vp.diph.dwHeaderSize = sizeof(DIPROPHEADER); vp.diph.dwHow = DIPH_DEVICE;
        WORD vid = SUCCEEDED(d->GetProperty(DIPROP_VIDPID, &vp.diph)) ? LOWORD(vp.dwData) : 0;
        DiPad p; p.dev = d; p.guid = inst.guidInstance;
        p.layout = g_cfgLayout == "playstation" || g_cfgLayout == "sony" ? 1 : g_cfgLayout == "nintendo" ? 2 : g_cfgLayout == "generic" ? 0
                 : vid == 0x054C ? 1 : vid == 0x057E ? 2 : 0;
        p.hasZ = HasAxis(d, DIJOFS_Z); p.hasRz = HasAxis(d, DIJOFS_RZ); p.hasRx = HasAxis(d, DIJOFS_RX); p.hasRy = HasAxis(d, DIJOFS_RY);
        WideCharToMultiByte(CP_UTF8, 0, inst.tszProductName, -1, p.name, sizeof p.name - 1, nullptr, nullptr);
        d->Acquire();
        SetLayout(p);
        BYTE type = GET_DIDEVICE_TYPE(inst.dwDevType);
        p.gamepad = type == DI8DEVTYPE_GAMEPAD;
        if (p.hasZ) {   // where Z rests now
            DIJOYSTATE2 j0 = {}; d->Poll();
            if (SUCCEEDED(d->GetDeviceState(sizeof j0, &j0))) p.zCentred = w2padmap::SharedZPlausible(j0.lZ);
        }
        g_pads[slot] = p;
        LOGI("pad: DirectInput controller \"%s\" (vendor %04X, %s, %s layout%s) - used while no XInput pad is connected; with several, the one you use",
             p.name, vid, type == DI8DEVTYPE_GAMEPAD ? "gamepad" : type == DI8DEVTYPE_JOYSTICK ? "joystick" : "other controller",
             p.layout == 1 ? "PlayStation" : p.layout == 2 ? "Nintendo" : "generic", g_cfgButtons.empty() ? "" : ", dinput_pad_buttons");
    }
}
SHORT Ax(LONG v) { return (SHORT)(v < -32768 ? -32768 : v > 32767 ? 32767 : v); }
SHORT AxInv(LONG v) { LONG n = -v - 1; return Ax(n); }                    // DirectInput Y is down-positive
bool Map(const DiPad& pd, const DIJOYSTATE2& j, XINPUT_GAMEPAD& g) {
    memset(&g, 0, sizeof g);
    auto B = [&](int i) { return i >= 0 && i < 128 && (j.rgbButtons[i] & 0x80); };
    static const WORD bits[10] = { XINPUT_GAMEPAD_A, XINPUT_GAMEPAD_B, XINPUT_GAMEPAD_X, XINPUT_GAMEPAD_Y, XINPUT_GAMEPAD_LEFT_SHOULDER, XINPUT_GAMEPAD_RIGHT_SHOULDER,
                                   XINPUT_GAMEPAD_BACK, XINPUT_GAMEPAD_START, XINPUT_GAMEPAD_LEFT_THUMB, XINPUT_GAMEPAD_RIGHT_THUMB };
    for (int i = 0; i < 10; i++) if (B(pd.map.btn[i])) g.wButtons |= bits[i];
    if (B(pd.map.back2)) g.wButtons |= XINPUT_GAMEPAD_BACK;
    g.wButtons |= w2padmap::Pov(j.rgdwPOV[0]);   // 1.1.4: diagonals give both directions (they gave none)
    g.sThumbLX = Ax(j.lX); g.sThumbLY = AxInv(j.lY);
    // right stick: PlayStation / most pads Z + Rz; Nintendo and some others Rx + Ry
    bool rxry = g_cfgRight == "rx_ry" || (g_cfgRight != "z_rz" && (pd.layout == 2 || !(pd.hasZ && pd.hasRz)) && pd.hasRx && pd.hasRy);
    if (rxry) { g.sThumbRX = Ax(j.lRx); g.sThumbRY = AxInv(j.lRy); }
    else if (pd.hasZ && pd.hasRz) { g.sThumbRX = Ax(j.lZ); g.sThumbRY = AxInv(j.lRz); }
    // triggers: PlayStation analog L2 / R2 on Rx / Ry; generic pads with both triggers on Z (right stick on Rx / Ry, no
    // Rz); otherwise the trigger buttons
    bool analog = g_cfgTrig == "rx_ry" || (g_cfgTrig == "auto" && pd.layout == 1 && !rxry && pd.hasRx && pd.hasRy);
    bool sharedZ = g_cfgTrig == "z" || (g_cfgTrig == "auto" && pd.layout == 0 && rxry && pd.hasZ && !pd.hasRz && pd.zCentred);
    if (analog) { g.bLeftTrigger = w2padmap::Trigger(j.lRx); g.bRightTrigger = w2padmap::Trigger(j.lRy); }
    else if (sharedZ) w2padmap::SharedZ(j.lZ, g.bLeftTrigger, g.bRightTrigger);
    if (B(pd.map.lt)) g.bLeftTrigger = 255;
    if (B(pd.map.rt)) g.bRightTrigger = 255;
    return true;
}
DWORD WINAPI DiThread(void*) {
    HMODULE m = LoadLibraryW(L"dinput8.dll");
    auto create = m ? (DI8CreateFn)GetProcAddress(m, "DirectInput8Create") : nullptr;
    if (!create || FAILED(create(GetModuleHandleW(nullptr), DIRECTINPUT_VERSION, kIID_DI8W, (void**)&g_di, nullptr)) || !g_di) {
        LOGW("pad: DirectInput not available - only XInput controllers work"); return 0;
    }
    DWORD lastEnum = 0, xiSince = 0;
    w2padmap::Picker picker;
    for (;;) {
        DWORD now = GetTickCount();
        bool xi = g_xiConnected != 0;
        if (xi) {   // an XInput pad is there: it is the game's pad. Close ours after 2 s (Steam Input / DS4Windows mirror the same controller)
            if (!xiSince) xiSince = now ? now : 1;
            if (OpenCount() && now - xiSince > 2000) { LOGI("pad: XInput controller connected - DirectInput controllers no longer used"); CloseAllPads(); }
            Sleep(250); continue;
        }
        xiSince = 0;
        if (OpenCount() < 4 && (now - lastEnum > 3000 || !lastEnum)) { lastEnum = now; OpenPads(); }   // enumeration is slow: every 3 s at most
        if (!OpenCount()) { AcquireSRWLockExclusive(&g_diLock); g_diValid = false; ReleaseSRWLockExclusive(&g_diLock); Sleep(250); continue; }
        XINPUT_GAMEPAD st[4] = {}; bool open[4] = {}, active[4] = {};
        bool anyGamepad = false; for (auto& q : g_pads) if (q.dev && q.gamepad) anyGamepad = true;
        for (int i = 0; i < 4; i++) {
            DiPad& pd = g_pads[i];
            if (!pd.dev) continue;
            DIJOYSTATE2 j;
            HRESULT hr = pd.dev->Poll();
            if (FAILED(hr)) { pd.dev->Acquire(); hr = pd.dev->Poll(); }
            hr = pd.dev->GetDeviceState(sizeof j, &j);
            if (hr == DIERR_INPUTLOST || hr == DIERR_NOTACQUIRED) { pd.dev->Acquire(); hr = pd.dev->GetDeviceState(sizeof j, &j); }
            if (FAILED(hr)) {
                if (hr != DIERR_INPUTLOST && hr != DIERR_NOTACQUIRED) { LOGI("pad: DirectInput controller \"%s\" gone (%08lx)", pd.name, (unsigned long)hr); ClosePad(i); }
                continue;
            }
            Map(pd, j, st[i]);
            const XINPUT_GAMEPAD& g = st[i];
            w2padmap::Pad now = { g.wButtons, g.bLeftTrigger, g.bRightTrigger, g.sThumbLX, g.sThumbLY, g.sThumbRX, g.sThumbRY };
            active[i] = w2padmap::Used(now, pd.prev); pd.prev = now;
            open[i] = pd.gamepad || !anyGamepad;   // a joystick / wheel next to a gamepad never takes over
        }
        int use = picker.Step(open, active, now);
        if (use != g_padCur && use >= 0) { if (OpenCount() > 1) LOGI("pad: the game now reads DirectInput controller \"%s\"", g_pads[use].name); g_padCur = use; }
        AcquireSRWLockExclusive(&g_diLock);
        g_diValid = use >= 0; if (use >= 0) g_diState = st[use];
        ReleaseSRWLockExclusive(&g_diLock);
        Sleep(2);   // ~500 Hz: faster than any game tick
    }
}
bool ReadDI(XINPUT_STATE* out) {
    if (!g_diOn) return false;
    AcquireSRWLockShared(&g_diLock);
    bool ok = g_diValid; if (ok) out->Gamepad = g_diState;
    ReleaseSRWLockShared(&g_diLock);
    return ok;
}
void StartDI() {
    static LONG started = 0;
    if (!g_diOn || InterlockedExchange(&started, 1)) return;
    HANDLE t = CreateThread(nullptr, 0, DiThread, nullptr, 0, nullptr);
    if (t) CloseHandle(t);
}

// ---------------------------------------------------------------- what the game sees
w2latch::PadLatch g_latch;
volatile LONG g_diReads = 0;
DWORD g_lastSrc = 0;   // 0 none, 1 XInput, 2 DirectInput

DWORD ReadAny(XINPUT_STATE* st, DWORD* src) {
    ZeroMemory(st, sizeof *st);
    if (ReadXI(st)) { *src = 1; return ERROR_SUCCESS; }
    if (ReadDI(st)) { *src = 2; return ERROR_SUCCESS; }
    *src = 0; return ERROR_DEVICE_NOT_CONNECTED;
}
} // namespace

// 1.0.9 diagnostics: which buttons the game got pressed (per 10 s report)
static const char* const kBtnName[16] = { "DpadUp", "DpadDown", "DpadLeft", "DpadRight", "Start", "Back", "LS", "RS",
                                          "LB", "RB", "?", "?", "A/Cross", "B/Circle", "X/Square", "Y/Triangle" };
static LONG g_edge[16] = {}; static WORD g_prevOut = 0; static volatile LONG g_gameReads = 0;
static ULONGLONG g_btnEdgeTick[16] = {};
static void CountEdges(WORD now) {
    WORD e = now & ~g_prevOut; g_prevOut = now;
    ULONGLONG t = GetTickCount64();
    for (int i = 0; i < 16; i++) if (e & (1 << i)) { g_edge[i]++; g_btnEdgeTick[i] = t; }
}
// the game's XInputGetState (proxy export, ordinal 2)
extern "C" DWORD WINAPI W2PadGetState(DWORD user, XINPUT_STATE* st) {
    if (!st) return ERROR_BAD_ARGUMENTS;
    if (user != 0) return g_get ? g_get(user, st) : ERROR_DEVICE_NOT_CONNECTED;
    StartDI();
    EnterCriticalSection(&g_cs);
    XINPUT_STATE f; DWORD src;
    DWORD r = ReadAny(&f, &src);
    if (src == 2) InterlockedIncrement(&g_diReads);
    g_lastSrc = src;
    if (r == ERROR_SUCCESS) {   // 1.1.4: buttons bound to mod hotkeys are the mod's (from the press that completes them until released)
        uint32_t bits = f.Gamepad.wButtons | (f.Gamepad.bLeftTrigger > 128 ? 0x10000u : 0) | (f.Gamepad.bRightTrigger > 128 ? 0x20000u : 0);
        uint32_t hide = W2HotkeysPadHide(bits);
        if (hide) {
            f.Gamepad.wButtons &= (WORD)~(hide & 0xFFFF);
            if (hide & 0x10000u) f.Gamepad.bLeftTrigger = 0;
            if (hide & 0x20000u) f.Gamepad.bRightTrigger = 0;
        }
    }
    r = vrkit::input::GameFilter(r, 0, &f);   // VR panel open / panel chord: a neutral pad
    w2latch::Pad in, out; memcpy(&in, &f.Gamepad, sizeof in);
    uint32_t pkt;
    bool ok = g_latch.Step(g_latchOn && SameTickHeld(), r == ERROR_SUCCESS, in, out, pkt);
    ZeroMemory(st, sizeof *st);
    memcpy(&st->Gamepad, &out, sizeof out); st->dwPacketNumber = pkt;
    r = ok ? ERROR_SUCCESS : ERROR_DEVICE_NOT_CONNECTED;
    InterlockedIncrement(&g_gameReads);
    if (ok) CountEdges(out.b);
    LeaveCriticalSection(&g_cs);
    return r;
}
// the game's XInputSetState (ordinal 3): vibration goes to the pad the game reads
extern "C" DWORD WINAPI W2PadSetState(DWORD user, XINPUT_VIBRATION* v) {
    if (!g_set) return ERROR_DEVICE_NOT_CONNECTED;
    if (user != 0) return g_set(user, v);
    if (g_lastSrc == 2) return ERROR_SUCCESS;      // DirectInput controller: no rumble
    return g_set((DWORD)g_slot, v);
}
// the VR panel's own read: the same pad, unfiltered and never held
static unsigned long __stdcall PanelRead(unsigned long user, void* p) {
    auto* st = (XINPUT_STATE*)p;
    if (user != 0 || !st) return ERROR_DEVICE_NOT_CONNECTED;
    StartDI();
    EnterCriticalSection(&g_cs);
    DWORD src; DWORD r = ReadAny(st, &src);
    LeaveCriticalSection(&g_cs);
    return r;
}

// w2keys.cpp: the pad buttons down now (raw) or pressed in the last `ms` (what the game got) - to spot keyboard keys
// that a controller tool sends together with a button (Steam Input layouts, DS4Windows / reWASD macros)
WORD W2PadButtonsNear(unsigned ms) {
    WORD b = 0;
    if (g_csInit) {
        XINPUT_STATE st; DWORD src;
        EnterCriticalSection(&g_cs);
        if (ReadAny(&st, &src) == ERROR_SUCCESS) b = st.Gamepad.wButtons;
        LeaveCriticalSection(&g_cs);
    }
    ULONGLONG t = GetTickCount64();
    for (int i = 0; i < 16; i++) if (g_btnEdgeTick[i] && t - g_btnEdgeTick[i] <= ms) b |= (WORD)(1 << i);
    return b;
}
// hotkeys (w2hotkeys.cpp): the controller in use, raw - Xbox button bits plus LT (bit 16) / RT (bit 17) past half way
bool W2PadRaw(uint32_t* buttons) {
    *buttons = 0;
    if (!g_csInit) return false;
    StartDI();
    XINPUT_STATE st; DWORD src;
    EnterCriticalSection(&g_cs);
    bool ok = ReadAny(&st, &src) == ERROR_SUCCESS;
    LeaveCriticalSection(&g_cs);
    if (ok) *buttons = st.Gamepad.wButtons | (st.Gamepad.bLeftTrigger > 128 ? 0x10000u : 0) | (st.Gamepad.bRightTrigger > 128 ? 0x20000u : 0);
    return ok;
}
const char* W2PadButtonName(int bit) { return bit >= 0 && bit < 16 ? kBtnName[bit] : "?"; }

// DllMain, after loading the system XInput: route the game's two imports through here
static GetFn g_realGet = nullptr; static SetFn g_realSet = nullptr;
void W2PadsInstall() {
    InitializeCriticalSection(&g_cs); g_csInit = true;
    g_realGet = g_get = (GetFn)g_px[0]; g_realSet = g_set = (SetFn)g_px[1];
    if (!g_get) return;
    g_px[0] = (FARPROC)W2PadGetState;
    if (g_set) g_px[1] = (FARPROC)W2PadSetState;
    vrkit::input::SetPadReader(PanelRead);
}
// 1.0.9, at device creation: the Steam overlay (Steam Input) patches this DLL's XInputGetState / SetState exports and
// answers the game itself, so in 1.0.8 the game's reads never reached the code above (the log showed "the game read
// XInput 0 times"; 1.0.7 and earlier were in front with vrkit's hook). Now the exports themselves are hooked, so the mod
// is first in line again; it reads the pad through whatever was there (Steam's controller, or the system XInput).
typedef DWORD (WINAPI* RawGet)(DWORD, XINPUT_STATE*);
static RawGet g_tGet = nullptr; static SetFn g_tSet = nullptr;
static DWORD WINAPI hExpGet(DWORD u, XINPUT_STATE* st) { return W2PadGetState(u, st); }
static DWORD WINAPI hExpSet(DWORD u, XINPUT_VIBRATION* v) { return W2PadSetState(u, v); }
void W2PadsHook(const char* when) {
    static bool done = false;
    if (done || !g_realGet) return;
    HMODULE self = nullptr;
    GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCWSTR)&W2PadsHook, &self);
    void* eg = self ? (void*)GetProcAddress(self, "XInputGetState") : nullptr;
    void* es = self ? (void*)GetProcAddress(self, "XInputSetState") : nullptr;
    if (!eg) return;
    bool patched = *(uint8_t*)eg == 0xE9 || *(uint8_t*)eg == 0xFF || *(uint8_t*)eg == 0x68;   // a jmp / push-ret in front: someone hooked it
    EnterCriticalSection(&g_cs);
    g_px[0] = (FARPROC)g_realGet;   // the export body goes to the system XInput again (the trampoline may lead there)
    if (g_realSet) g_px[1] = (FARPROC)g_realSet;
    bool ok = MH_CreateHook(eg, (void*)hExpGet, (void**)&g_tGet) == MH_OK && MH_EnableHook(eg) == MH_OK;
    if (ok) g_get = (GetFn)g_tGet;
    else { g_px[0] = (FARPROC)W2PadGetState; }
    if (ok && es && MH_CreateHook(es, (void*)hExpSet, (void**)&g_tSet) == MH_OK && MH_EnableHook(es) == MH_OK) g_set = g_tSet;
    else if (g_realSet) g_px[1] = (FARPROC)W2PadSetState;
    LeaveCriticalSection(&g_cs);
    done = true;
    LOGI("pad: the game's XInput reads hooked at this DLL's exports (%s)%s", when,
         !ok ? " - FAILED, the game's reads may bypass the mod" : patched ? " - another hook (Steam Input / overlay) was already there: the mod is in front of it and reads the pad through it" : "");
}
// config (after the config file is read)
void W2PadsConfigure() {
    std::string s = ConfigStr("pad_slot", "auto");
    g_forceSlot = (s.size() == 1 && s[0] >= '1' && s[0] <= '4') ? s[0] - '1' : -1;
    g_latchOn = ConfigBool("input_same_tick_latch", true);
    g_diOn = ConfigStr("dinput_pads", "auto") != "off";
    g_cfgLayout = ConfigStr("dinput_pad_layout", "auto");
    g_cfgRight = ConfigStr("dinput_pad_right_stick", "auto");
    g_cfgTrig = ConfigStr("dinput_pad_triggers", "auto");
    g_cfgButtons = ConfigStr("dinput_pad_buttons", "");
    LOGI("pad: the game's pad = %s%s; same-tick input latch %s", g_forceSlot >= 0 ? "slot " : "the controller in use (any XInput slot", g_forceSlot >= 0 ? std::to_string(g_forceSlot + 1).c_str() : g_diOn ? ", else a DirectInput controller)" : ")",
         g_latchOn ? "on" : "off");
}
void W2PadsReport() {
    EnterCriticalSection(&g_cs);
    LONG h = g_latch.held, l = g_latch.latched; g_latch.held = g_latch.latched = 0;
    LeaveCriticalSection(&g_cs);
    LONG d = InterlockedExchange(&g_diReads, 0);
    LONG gr = InterlockedExchange(&g_gameReads, 0);
    char eb[256]; int n = 0; eb[0] = 0;
    for (int i = 0; i < 16; i++) { LONG c = InterlockedExchange(&g_edge[i], 0); if (c && n < 230) n += _snprintf(eb + n, sizeof eb - n, "%s%s x%ld", n ? ", " : "", kBtnName[i], c); }
    LOGI("pad: the game read the pad %ld times (slot %d%s)%s%s", gr, g_slot + 1, g_lastSrc == 2 ? ", DirectInput controller" : "", n ? "; buttons pressed: " : "", eb);
    if (h || l || d) LOGI("pad: %ld reads held on frozen ticks, %ld short taps delivered late instead of lost, %ld reads from the DirectInput controller", h, l, d);
}

// w2fov.cpp - fixed foveated rendering for a D3D9 game (1.1.3).
//
// D3D12 / D3D11 mods use variable-rate shading for this (GOTGVR: VRS tier 2 shading-rate image). D3D9 has no shading
// rate, so W2VR does what VRS does with the depth test instead ("radial density masking"):
//  1. MASK - at the first draw into the G-buffer (colour + specular + normal targets bound, the eye-size depth buffer
//     cleared), a full-screen pass writes the NEAR depth into every pixel that is not the first pixel of its block, in
//     2x2 blocks between the inner and the outer ring and 4x4 blocks beyond (rings around the lens centre; 1.0 = half
//     the picture height). Colour writes are off. From then on the game's own depth test rejects those pixels for every
//     geometry pass: their pixel shaders never run. One pixel of each block is shaded at full detail.
//  2. FILL - when the eye picture is copied out (where the de-dither filter runs), every masked pixel takes the colour
//     of its block's shaded pixel: the edges look like 2x2 / 4x4 coarse shading, exactly what VRS gives.
// Mask and fill use the same zone function and the same centre (fixed per frame), so they always agree. The pass is
// skipped when the depth test is not the usual "less" / "greater" kind (unknown convention) or when no G-buffer is seen.
// What it saves: geometry pixel shading (textures, normal maps) and depth-tested forward passes in the masked pixels.
// Full-screen lighting passes still run per pixel. Off by default; foveated_debug tints the zones.
#include <windows.h>
#include <d3d9.h>
#include <cstring>
#include <cmath>
#include <d3dcommon.h>
#include "log.h"
#include "w2vr.h"

extern volatile LONG g_inOwn;
HRESULT CallCreateTexture(IDirect3DDevice9* d, UINT w, UINT h, UINT levels, DWORD usage, D3DFORMAT fmt, D3DPOOL pool,
                          IDirect3DTexture9** tex, HANDLE* shared);

namespace {
// zone function shared by both shaders: c0 = (centre x, centre y in pixels, 1 / ring unit in pixels, -), c1 = (inner, outer, debug, -)
const char kZone[] =
    "float4 kc : register(c0); float4 kz : register(c1);\n"
    "float Block(float2 p) { float d = length((p + 0.5 - kc.xy) * kc.z); return d < kz.x ? 1 : (d < kz.y ? 2 : 4); }\n";
const char kVs[] =
    "void main(float4 p : POSITION, float2 t : TEXCOORD0, out float4 op : POSITION, out float2 ot : TEXCOORD0) { op = p; ot = t; }\n";
// mask: the block's first pixel is kept (clip), every other pixel gets the near depth from the quad's z
const char kMaskPs[] =
    "float4 main(float2 vp : VPOS) : COLOR {\n"
    "  float2 p = floor(vp + 0.25); float b = Block(p);\n"
    "  float2 r = fmod(p, b); clip(dot(r, r) > 0.5 ? 1 : -1);\n"
    "  return float4(0, 0, 0, 0);\n"
    "}\n";
// fill: masked pixels read their block's first pixel; a block whose first pixel lies in a coarser zone uses that one
const char kFillPs[] =
    "sampler2D s : register(s0); float4 ks : register(c2);\n"   // ks = (1 / w, 1 / h, -, -)
    "float4 main(float2 vp : VPOS) : COLOR {\n"
    "  float2 p = floor(vp + 0.25); float b = Block(p);\n"
    "  float2 o = p - fmod(p, b);\n"
    "  float b2 = Block(o); if (b2 > b) { o = p - fmod(p, b2); b = b2; }\n"
    "  float b3 = Block(o); if (b3 > b) { o = p - fmod(p, b3); b = b3; }\n"
    "  float4 c = tex2Dlod(s, float4((o + 0.5) * ks.xy, 0, 0));\n"
    "  if (kz.z > 0.5) c.rgb = b > 3 ? lerp(c.rgb, float3(1, 0.1, 0.1), 0.35) : (b > 1 ? lerp(c.rgb, float3(0.1, 1, 0.2), 0.25) : c.rgb);\n"
    "  return float4(c.rgb, 1);\n"
    "}\n";

bool g_on = false, g_debug = false; float g_inner = 0.55f, g_outer = 0.90f;
IDirect3DVertexShader9* g_vs = nullptr; IDirect3DPixelShader9* g_maskPs = nullptr; IDirect3DPixelShader9* g_fillPs = nullptr;
IDirect3DVertexDeclaration9* g_decl = nullptr; IDirect3DStateBlock9* g_sb = nullptr;
IDirect3DTexture9* g_tmp = nullptr; UINT g_tw = 0, g_th = 0; D3DFORMAT g_tf = D3DFMT_UNKNOWN;
bool g_failed = false, g_maskedSinceFill = false;
float g_cx = 0.5f, g_cy = 0.5f;          // lens centre in the picture (0..1), fixed for the frame
volatile LONG g_masks = 0, g_fills = 0, g_skipZ = 0;

typedef HRESULT (WINAPI* D3DCompileFn)(const void*, SIZE_T, const char*, const void*, void*, const char*, const char*, UINT, UINT, ID3DBlob**, ID3DBlob**);
struct Blob { ID3DBlob* b = nullptr; ~Blob() { if (b) b->Release(); } };
bool Ensure(IDirect3DDevice9* d) {
    if (g_vs && g_maskPs && g_fillPs && g_decl) return true;
    if (g_failed) return false;
    g_failed = true;
    static const wchar_t* dlls[] = { L"d3dcompiler_47.dll", L"d3dcompiler_46.dll", L"d3dcompiler_43.dll" };
    D3DCompileFn fn = nullptr;
    for (auto n : dlls) { HMODULE m = LoadLibraryW(n); if (m && (fn = (D3DCompileFn)GetProcAddress(m, "D3DCompile"))) break; }
    if (!fn) { LOGW("foveated: no d3dcompiler DLL - off"); return false; }
    char mask[2048], fill[2048];
    _snprintf(mask, sizeof mask, "%s%s", kZone, kMaskPs); _snprintf(fill, sizeof fill, "%s%s", kZone, kFillPs);
    Blob vb, mb, fb, e;
    if (FAILED(fn(kVs, strlen(kVs), "fov_vs", nullptr, nullptr, "main", "vs_3_0", 0, 0, &vb.b, &e.b)) ||
        FAILED(fn(mask, strlen(mask), "fov_mask", nullptr, nullptr, "main", "ps_3_0", 0, 0, &mb.b, &e.b)) ||
        FAILED(fn(fill, strlen(fill), "fov_fill", nullptr, nullptr, "main", "ps_3_0", 0, 0, &fb.b, &e.b))) {
        LOGW("foveated: shaders did not compile: %s", e.b ? (const char*)e.b->GetBufferPointer() : "?"); return false;
    }
    static const D3DVERTEXELEMENT9 el[] = {
        { 0, 0, D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0 },
        { 0, 16, D3DDECLTYPE_FLOAT2, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0 }, D3DDECL_END() };
    if (FAILED(d->CreateVertexShader((const DWORD*)vb.b->GetBufferPointer(), &g_vs)) ||
        FAILED(d->CreatePixelShader((const DWORD*)mb.b->GetBufferPointer(), &g_maskPs)) ||
        FAILED(d->CreatePixelShader((const DWORD*)fb.b->GetBufferPointer(), &g_fillPs)) ||
        FAILED(d->CreateVertexDeclaration(el, &g_decl))) { LOGW("foveated: shaders rejected - off"); return false; }
    g_failed = false;
    LOGI("foveated: ready (inner %.2f, outer %.2f)", g_inner, g_outer);
    return true;
}
void Consts(IDirect3DDevice9* d, UINT w, UINT h) {
    // ring unit = half the 3D picture's height (content rect), centre = lens centre
    float ch = (g_vr.content[3] - g_vr.content[1]) * h; if (ch < 16) ch = (float)h;
    const float c0[4] = { g_cx * w, g_cy * h, 2.f / ch, 0 }, c1[4] = { g_inner, g_outer, g_debug ? 1.f : 0.f, 0 }, c2[4] = { 1.f / w, 1.f / h, 0, 0 };
    d->SetPixelShaderConstantF(0, c0, 1); d->SetPixelShaderConstantF(1, c1, 1); d->SetPixelShaderConstantF(2, c2, 1);
}
void Quad(IDirect3DDevice9* d, UINT w, UINT h, float z) {
    const float hx = 1.f / w, hy = 1.f / h;
    struct V { float x, y, z, w, u, v; } q[4] = {
        { -1.f - hx,  1.f + hy, z, 1.f, 0.f, 0.f }, { 1.f - hx,  1.f + hy, z, 1.f, 1.f, 0.f },
        { -1.f - hx, -1.f + hy, z, 1.f, 0.f, 1.f }, { 1.f - hx, -1.f + hy, z, 1.f, 1.f, 1.f } };
    d->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, q, sizeof(V));
}
} // namespace

void FovSet(bool on, float inner, float outer, bool debug) {
    if (on != g_on) LOGI("foveated rendering %s (full detail inside %.2f, 4x4 blocks beyond %.2f)", on ? "ON" : "off", inner, outer);
    g_on = on; g_debug = debug;
    g_inner = inner < 0.05f ? 0.05f : inner; g_outer = outer < g_inner + 0.05f ? g_inner + 0.05f : outer;
}
bool FovOn() { return g_on; }
// lens centre for this frame (0..1 in the picture): both eyes' centres averaged, so the mask and the fill agree whatever eye
void FovSetCentre(float cx, float cy) { g_cx = cx; g_cy = cy; }

// at the first draw into the G-buffer (d3d9hooks.cpp PreDraw): mark the coarse pixels with the near depth
void FovMask(IDirect3DDevice9* d) {
    // only while the eye pictures go to the headset (the fill runs at their copy), and once per eye picture: the game
    // binds its targets again inside the G-buffer pass, and a second mask would change nothing but cost a full-screen pass
    if (!g_on || !d || !g_vr.active || g_maskedSinceFill) return;
    struct Own { Own() { InterlockedIncrement(&g_inOwn); } ~Own() { InterlockedDecrement(&g_inOwn); } } own;
    DWORD zen = 0, zfunc = 0, zwrite = 0;
    d->GetRenderState(D3DRS_ZENABLE, &zen); d->GetRenderState(D3DRS_ZFUNC, &zfunc); d->GetRenderState(D3DRS_ZWRITEENABLE, &zwrite);
    float nearZ;
    if (zfunc == D3DCMP_LESS || zfunc == D3DCMP_LESSEQUAL) nearZ = 0.f;
    else if (zfunc == D3DCMP_GREATER || zfunc == D3DCMP_GREATEREQUAL) nearZ = 1.f;
    else { InterlockedIncrement(&g_skipZ); return; }   // unknown depth convention: leave this frame alone
    if (!zen) { InterlockedIncrement(&g_skipZ); return; }
    IDirect3DSurface9* ds = nullptr; d->GetDepthStencilSurface(&ds);
    IDirect3DSurface9* rt0 = nullptr; d->GetRenderTarget(0, &rt0);
    D3DSURFACE_DESC dd = {}, rd = {};
    bool ok = ds && rt0 && SUCCEEDED(ds->GetDesc(&dd)) && SUCCEEDED(rt0->GetDesc(&rd)) && dd.Width >= rd.Width && dd.Height >= rd.Height;
    if (ds) ds->Release(); if (rt0) rt0->Release();
    if (!ok || !Ensure(d)) return;
    if (!g_sb && FAILED(d->CreateStateBlock(D3DSBT_ALL, &g_sb))) g_sb = nullptr;
    if (!g_sb) return;
    g_sb->Capture();
    const DWORD rs[][2] = {
        { D3DRS_ZENABLE, TRUE }, { D3DRS_ZWRITEENABLE, TRUE }, { D3DRS_ZFUNC, D3DCMP_ALWAYS }, { D3DRS_STENCILENABLE, FALSE },
        { D3DRS_ALPHATESTENABLE, FALSE }, { D3DRS_ALPHABLENDENABLE, FALSE }, { D3DRS_CULLMODE, D3DCULL_NONE }, { D3DRS_SCISSORTESTENABLE, FALSE },
        { D3DRS_CLIPPLANEENABLE, 0 }, { D3DRS_FILLMODE, D3DFILL_SOLID }, { D3DRS_FOGENABLE, FALSE }, { D3DRS_SLOPESCALEDEPTHBIAS, 0 }, { D3DRS_DEPTHBIAS, 0 },
        { D3DRS_COLORWRITEENABLE, 0 }, { D3DRS_COLORWRITEENABLE1, 0 }, { D3DRS_COLORWRITEENABLE2, 0 }, { D3DRS_COLORWRITEENABLE3, 0 } };
    for (auto& r : rs) d->SetRenderState((D3DRENDERSTATETYPE)r[0], r[1]);
    D3DVIEWPORT9 vp = { 0, 0, rd.Width, rd.Height, 0.f, 1.f }; d->SetViewport(&vp);
    d->SetVertexDeclaration(g_decl); d->SetVertexShader(g_vs); d->SetPixelShader(g_maskPs);
    Consts(d, rd.Width, rd.Height);
    Quad(d, rd.Width, rd.Height, nearZ);
    g_sb->Apply();
    g_maskedSinceFill = true;
    InterlockedIncrement(&g_masks);
}

// the eye picture after it is copied out (xr.cpp, before the de-dither filter): masked pixels take their block's colour
void FovFill(IDirect3DDevice9* d, IDirect3DTexture9* eye) {
    if (!d || !eye || !g_maskedSinceFill) return;
    g_maskedSinceFill = false;
    if (!g_on) return;
    struct Own { Own() { InterlockedIncrement(&g_inOwn); } ~Own() { InterlockedDecrement(&g_inOwn); } } own;
    if (!Ensure(d)) return;
    D3DSURFACE_DESC ed; if (FAILED(eye->GetLevelDesc(0, &ed))) return;
    if (!g_tmp || g_tw != ed.Width || g_th != ed.Height || g_tf != ed.Format) {
        if (g_tmp) { g_tmp->Release(); g_tmp = nullptr; }
        if (FAILED(CallCreateTexture(d, ed.Width, ed.Height, 1, D3DUSAGE_RENDERTARGET, ed.Format, D3DPOOL_DEFAULT, &g_tmp, nullptr)) || !g_tmp) { g_tmp = nullptr; return; }
        g_tw = ed.Width; g_th = ed.Height; g_tf = ed.Format;
    }
    if (!g_sb && FAILED(d->CreateStateBlock(D3DSBT_ALL, &g_sb))) g_sb = nullptr;
    IDirect3DSurface9 *es = nullptr, *ts = nullptr;
    eye->GetSurfaceLevel(0, &es); g_tmp->GetSurfaceLevel(0, &ts);
    if (!es || !ts || FAILED(d->StretchRect(es, nullptr, ts, nullptr, D3DTEXF_NONE))) { if (es) es->Release(); if (ts) ts->Release(); return; }
    if (g_sb) g_sb->Capture();
    IDirect3DSurface9* rt[4] = {}; IDirect3DSurface9* ds = nullptr; D3DVIEWPORT9 vpSave = {}; d->GetViewport(&vpSave);
    for (int i = 0; i < 4; i++) d->GetRenderTarget(i, &rt[i]);
    d->GetDepthStencilSurface(&ds);
    d->SetRenderTarget(0, es); for (int i = 1; i < 4; i++) if (rt[i]) d->SetRenderTarget(i, nullptr);
    d->SetDepthStencilSurface(nullptr);
    D3DVIEWPORT9 vp = { 0, 0, ed.Width, ed.Height, 0.f, 1.f }; d->SetViewport(&vp);
    const DWORD rs[][2] = {
        { D3DRS_ZENABLE, FALSE }, { D3DRS_ZWRITEENABLE, FALSE }, { D3DRS_ALPHATESTENABLE, FALSE }, { D3DRS_ALPHABLENDENABLE, FALSE },
        { D3DRS_CULLMODE, D3DCULL_NONE }, { D3DRS_STENCILENABLE, FALSE }, { D3DRS_SCISSORTESTENABLE, FALSE }, { D3DRS_CLIPPLANEENABLE, 0 },
        { D3DRS_COLORWRITEENABLE, 0xF }, { D3DRS_SRGBWRITEENABLE, FALSE }, { D3DRS_FILLMODE, D3DFILL_SOLID }, { D3DRS_FOGENABLE, FALSE } };
    for (auto& r : rs) d->SetRenderState((D3DRENDERSTATETYPE)r[0], r[1]);
    d->SetTexture(0, g_tmp);
    d->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_POINT); d->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_POINT); d->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);
    d->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP); d->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP); d->SetSamplerState(0, D3DSAMP_SRGBTEXTURE, FALSE);
    d->SetVertexDeclaration(g_decl); d->SetVertexShader(g_vs); d->SetPixelShader(g_fillPs);
    Consts(d, ed.Width, ed.Height);
    const bool began = SUCCEEDED(d->BeginScene());
    Quad(d, ed.Width, ed.Height, 0.5f);
    if (began) d->EndScene();
    if (g_sb) g_sb->Apply();
    for (int i = 0; i < 4; i++) { if (i == 0 || rt[i]) d->SetRenderTarget(i, rt[i]); if (rt[i]) rt[i]->Release(); }
    d->SetDepthStencilSurface(ds); if (ds) ds->Release();
    d->SetViewport(&vpSave);
    es->Release(); ts->Release();
    InterlockedIncrement(&g_fills);
}
void FovRelease() { if (g_tmp) { g_tmp->Release(); g_tmp = nullptr; } if (g_sb) { g_sb->Release(); g_sb = nullptr; } g_tw = g_th = 0; }
void FovReport() {
    LONG m = InterlockedExchange(&g_masks, 0), f = InterlockedExchange(&g_fills, 0), z = InterlockedExchange(&g_skipZ, 0);
    if (g_on || m || f) LOGI("foveated: %ld frames masked, %ld eye pictures filled%s (centre %.2f, %.2f; inner %.2f, outer %.2f)", m, f,
                             z ? " - some frames skipped: the game's depth test was not a less / greater kind" : "", g_cx, g_cy, g_inner, g_outer);
}

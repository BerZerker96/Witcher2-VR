// w2hotkeys.cpp - remappable hotkeys (1.1.4): VR panel > Hotkeys.
//
// Every function has a keyboard binding and a controller binding (w2bind.h has the formats). Both are set in the panel
// (A / Enter / click, then press the key or the button combination), saved to w2vr_config.txt the moment they are set
// (keyboard: the same *_key names as before, so old configs keep working; controller: *_pad), and act while the panel
// is closed. Only the keys that already had one (panel, recenter, first person, HUD, VR mode, screenshot) have a
// default; the rest start empty.
//  * keyboard: any key, with Ctrl / Shift / Alt; acts only while the game window is in front; hidden from the game
//    (with modifiers: only while those are held), as before (keyboard_exclusive_hotkeys);
//  * controller: any connected controller (any XInput slot, PlayStation / Switch / generic pads through DirectInput -
//    all in the Xbox layout); one button or a combination of up to four, triggers included; fires on the press that
//    completes it and is hidden from the game from then until released (pad_exclusive_hotkeys = true);
//  * the panel's own binding goes to vrkit (hold the controller combination 0.3 s; the keyboard key has no modifiers);
//    it can never end up with neither binding - an empty pair falls back to Insert.
#include <windows.h>
#include <string>
#include <vector>
#include "log.h"
#include "config.h"
#include "w2bind.h"
#include "vrkit_options.h"
#include "vrkit_input.h"
#include "vrkit_menu_core.h"

bool MenuIsOpen();
bool W2KeysGameInFront();
void W2KeysSetHot(const std::vector<std::pair<int, unsigned>>& keys);
void W2KeysInstall(const std::vector<std::pair<int, std::string>>& hot);
bool W2PadRaw(uint32_t* buttons);
bool W2MouseButtonDown(int i); unsigned W2MouseTakePressedHk();
void MenuToggleFirstPerson();
void XrRequestRecenter(); void XrCycleHudMode(); void XrCycleVrMode(); void XrRequestScreenshot();

namespace {
struct Hot {
    const char* id; const char* group; const char* label;
    const char* kbKey; const char* padKey; const char* defKb; const char* defPad;
    const char* opt; int dir;   // a panel option this steps (bool: toggles, choice: next value, number: one step dir)
    const char* help;
    std::string kb, pad; w2bind::Key k; uint32_t p = 0;
};
Hot g_hot[] = {
    { "menu", "Panel and view", "Open / close this panel", "menu_key", "menu_pad", "insert", "ls+rs", nullptr, 0,
      "Opens and closes the VR panel. The controller combination is held for a moment (default L3 + R3: both sticks pressed). "
      "It can be changed but never cleared, and no other function can take its key or buttons - the panel can always be opened." },
    { "recenter", "Panel and view", "Recenter view", "recenter_key", "recenter_pad", "home", "", nullptr, 0, "Puts the view straight in front of you." },
    { "vr_mode", "Panel and view", "Cycle VR mode", "vr_mode_key", "vr_mode_pad", "f8", "", nullptr, 0, "Stereo 3D -> head-tracked mono -> flat screen -> Stereo 3D." },
    { "stereo", "Panel and view", "Cycle stereo method", "stereo_method_key", "stereo_method_pad", "", "", "stereo_method", 1, "Automatic -> full stereo -> same-tick -> alternate eye." },
    { "shot", "Panel and view", "Screenshot", "screenshot_key", "screenshot_pad", "delete", "", nullptr, 0, "Saves the eye picture(s) as set in Screen > Screenshots." },
    { "fp", "Camera", "First person on / off", "first_person_key", "first_person_pad", "end", "", "first_person", 1, "The view at Geralt's head or the game's camera." },
    { "pitch", "Camera", "Decoupled pitch on / off", "decoupled_pitch_key", "decoupled_pitch_pad", "", "", "decoupled_pitch", 1, "Level camera (look up and down with your head) or the game camera's pitch." },
    { "pos", "Camera", "Positional tracking on / off", "positional_tracking_key", "positional_tracking_pad", "", "", "positional_tracking", 1, "Head movement moves the view, or only head rotation does." },
    { "scale_up", "Camera", "World scale up", "world_scale_up_key", "world_scale_up_pad", "", "", "world_scale", 1, "One step up: the world looks smaller." },
    { "scale_dn", "Camera", "World scale down", "world_scale_down_key", "world_scale_down_pad", "", "", "world_scale", -1, "One step down: the world looks larger." },
    { "hud", "HUD", "Cycle HUD mode", "hud_toggle_key", "hud_toggle_pad", "f7", "", nullptr, 0, "Floating panel -> fitted -> full size." },
    { "hud_follow", "HUD", "HUD follows the head on / off", "hud_follow_key", "hud_follow_pad", "", "", "hud_panel_follow_head", 1, "The floating HUD panel stays in front of you, or stays where it is." },
    { "flat_menus", "HUD", "Menus on the flat screen on / off", "flat_menus_key", "flat_menus_pad", "", "", "flat_when_paused", 1, "Pause menu, inventory, map and journal on the flat virtual screen, or in VR." },
    { "edge", "Picture and performance", "Edge fill on / off", "edge_fill_key", "edge_fill_pad", "", "", "edge_fill", 1, "Stretched edge or black around the picture." },
    { "fov", "Picture and performance", "Cycle foveated rendering", "foveated_key", "foveated_pad", "", "", "foveated", 1, "Off -> Quality -> Balanced -> Performance -> Custom." },
    { "limit", "Picture and performance", "Cycle frame limit", "frame_limit_key", "frame_limit_pad", "", "", "frame_limit", 1, "Steps through the frame limit choices." },
    { "smooth", "Picture and performance", "Headset smoothing: follow / off", "headset_smoothing_key", "headset_smoothing_pad", "", "", "headset_smoothing", 1, "Follow the headset's smoothing, or always same-tick." },
    { "ssao", "Picture and performance", "Remove SSAO on / off", "disable_ssao_key", "disable_ssao_pad", "", "", "disable_ssao", 1, "Ambient shadows on or off (they cost GPU time)." },
};
const int kN = (int)(sizeof g_hot / sizeof g_hot[0]);
int g_diagVk = 0;
bool g_padExclusive = true;
SRWLOCK g_lock = SRWLOCK_INIT;
std::vector<uint32_t> g_padBinds;   // index = g_hot index (game-thread filter reads it under the lock)
w2bind::PadHider g_hider;

unsigned ModsNow() {
    return ((GetAsyncKeyState(VK_CONTROL) & 0x8000) ? w2bind::Ctrl : 0) | ((GetAsyncKeyState(VK_SHIFT) & 0x8000) ? w2bind::Shift : 0) |
           ((GetAsyncKeyState(VK_MENU) & 0x8000) ? w2bind::Alt : 0);
}
void Reparse() {
    std::vector<std::pair<int, unsigned>> keys;
    std::vector<uint32_t> pads(kN, 0);
    for (int i = 0; i < kN; i++) {
        Hot& h = g_hot[i];
        h.k = w2bind::KeyParse(h.kb); h.p = w2bind::PadParse(h.pad);
        if (i == 0) {   // the panel's own binding: no modifiers, nothing the open panel navigates with, never empty
            h.k.mods = 0;
            if (!h.k.Empty() && !w2bind::MenuKeyOk(h.k.vk)) { LOGW("hotkeys: %s cannot open the panel (the panel uses it) - not used", h.kb.c_str()); h.k = w2bind::Key(); }
            if (h.p && !w2bind::MenuPadOk(h.p)) { LOGW("hotkeys: %s alone cannot open the panel (the panel uses it) - not used", h.pad.c_str()); h.p = 0; }
            if (h.k.Empty() && !h.p) {
                h.k = w2bind::KeyParse("insert");
                LOGW("hotkeys: the panel had no binding left - Insert opens it");
                for (int j = 1; j < kN; j++) if (w2bind::KeyParse(g_hot[j].kb) == h.k) { LOGW("hotkeys: Insert taken off \"%s\"", g_hot[j].label); g_hot[j].kb.clear(); }
            }
        }
        std::string kc = w2bind::KeyWrite(h.k), pc = w2bind::PadWrite(h.p);
        if (kc != h.kb) h.kb = kc;   // the panel shows (and saves) the canonical form
        if (pc != h.pad) h.pad = pc;
        if (!h.k.Empty()) keys.push_back({ h.k.vk, h.k.mods });
        pads[i] = h.p;
    }
    if (g_diagVk) keys.push_back({ g_diagVk, 0 });
    W2KeysSetHot(keys);
    AcquireSRWLockExclusive(&g_lock); g_padBinds = pads; ReleaseSRWLockExclusive(&g_lock);
    const Hot& m = g_hot[0];
    int trig = ((m.p & w2bind::PadLT) ? 1 : 0) | ((m.p & w2bind::PadRT) ? 2 : 0);
    vrkit::input::SetToggle(m.k.vk, (unsigned short)(m.p & 0xFFFF), trig);
}
vrkit::Option* FindOpt(const char* key) {
    for (auto& o : vrkit::Options::Get().All()) if (o.key == key) return &o;
    return nullptr;
}
void Fire(Hot& h) {
    LOGI("hotkey: %s", h.label);
    if (!strcmp(h.id, "recenter")) XrRequestRecenter();
    else if (!strcmp(h.id, "vr_mode")) XrCycleVrMode();
    else if (!strcmp(h.id, "shot")) XrRequestScreenshot();
    else if (!strcmp(h.id, "hud")) XrCycleHudMode();
    else if (h.opt) {
        if (vrkit::Option* o = FindOpt(h.opt)) {
            // for this session, as the fixed keys always were (End did not change the saved first_person setting)
            auto& opts = vrkit::Options::Get();
            const bool wasDirty = opts.Dirty();
            opts.Step(*o, h.dir);
            if (!wasDirty) opts.SetDirty(false);
            LOGI("hotkey: %s -> %s (this session)", o->label.c_str(), opts.DisplayText(*o).c_str());
        }
        else if (!strcmp(h.id, "fp")) MenuToggleFirstPerson();   // before the panel was ever built
    }
}

// capture (the panel calls Poll every frame while a binding is being set)
w2bind::PadCapture g_cap; bool g_capHeld[256] = {}; bool g_capNoMods = false; bool g_capMouse[5] = {};
bool CapSkip(int vk) {
    return vk < 8 || vk == VK_SHIFT || vk == VK_CONTROL || vk == VK_MENU || (vk >= 0xA0 && vk <= 0xA5) || vk == VK_LWIN || vk == VK_RWIN ||
           vk == VK_APPS || vk == 0x15 || vk == 0x19 || vk == 0xE5 || vk == 0xFF;
}
void CapBegin(const vrkit::Option& o) {
    g_capNoMods = o.key == "menu_key";
    for (int vk = 1; vk < 256; vk++) g_capHeld[vk] = (GetAsyncKeyState(vk) & 0x8000) != 0;
    uint32_t b = 0; W2PadRaw(&b); g_cap.Begin(b);
    W2MouseTakePressedHk();   // clicks before this do not count
    for (int mb = 2; mb <= 4; mb++) g_capMouse[mb] = W2MouseButtonDown(mb);
}
int CapPoll(std::string& kb, std::string& pad) {
    bool front = W2KeysGameInFront();
    for (int vk = 8; vk < 255; vk++) {
        bool d = front && (GetAsyncKeyState(vk) & 0x8000) != 0;
        bool edge = d && !g_capHeld[vk]; g_capHeld[vk] = d;
        if (!edge || CapSkip(vk)) continue;
        if (vk == VK_ESCAPE) return -1;
        if (vk == VK_BACK) return 3;
        if (g_capNoMods && !w2bind::MenuKeyOk(vk)) continue;   // the panel navigates with it
        w2bind::Key k; k.vk = vk; k.mods = g_capNoMods ? 0 : ModsNow();
        kb = w2bind::KeyWrite(k);
        return 1;
    }
    if (front && !g_capNoMods) {   // mouse 3 / 4 / 5 (left / right click are the panel's - and the game's attacks)
        unsigned mp = W2MouseTakePressedHk();
        for (int mb = 2; mb <= 4; mb++) {
            bool d = W2MouseButtonDown(mb), edge = (mp & (1u << mb)) || (d && !g_capMouse[mb]);
            g_capMouse[mb] = d;
            if (!edge) continue;
            w2bind::Key k; k.vk = mb == 2 ? 0x04 : mb == 3 ? 0x05 : 0x06; k.mods = ModsNow();
            kb = w2bind::KeyWrite(k);
            return 1;
        }
    }
    uint32_t b = 0; W2PadRaw(&b);
    if (uint32_t r = g_cap.Step(b)) {
        if (g_capNoMods && !w2bind::MenuPadOk(r)) return 0;   // a single navigation button cannot open / close the panel
        pad = w2bind::PadWrite(r); return 2;
    }
    return 0;
}
} // namespace

// at start (InitXr): read the bindings, hide the keys from the game, tell vrkit the panel binding
void W2HotkeysLoad(int diagVk) {
    g_diagVk = diagVk;
    g_padExclusive = ConfigBool("pad_exclusive_hotkeys", true);
    for (auto& h : g_hot) { h.kb = ConfigStr(h.kbKey, h.defKb); h.pad = ConfigStr(h.padKey, h.defPad); }
    Reparse();
    std::vector<std::pair<int, std::string>> clash;   // the start-up check against the game's own bindings
    for (auto& h : g_hot) if (!h.k.Empty() && !h.k.mods) clash.push_back({ h.k.vk, h.kbKey });
    if (g_diagVk) clash.push_back({ g_diagVk, "diag_key" });
    W2KeysInstall(clash);
    int nk = 0, np = 0; for (auto& h : g_hot) { nk += !h.k.Empty(); np += h.p != 0; }
    LOGI("hotkeys: %d functions, %d keyboard and %d controller bindings", kN, nk, np);
    vrkit::HotkeyHost hh;
    hh.begin = CapBegin; hh.poll = CapPoll;
    hh.show = [](const std::string& v, bool pad) { return pad ? w2bind::PadWrite(w2bind::PadParse(v), true) : w2bind::KeyWrite(w2bind::KeyParse(v), true); };
    hh.changed = [] { Reparse(); };
    vrkit::SetHotkeyHost(hh);
}
// the VR panel's Hotkeys page (menu.cpp registers and places these)
void W2HotkeysRegister(std::vector<vrkit::Options::Place>& layout) {
    auto& o = vrkit::Options::Get();
    for (auto& h : g_hot) {
        auto& op = o.AddHotkey("Hotkeys", h.kbKey, h.padKey, h.label, &h.kb, &h.pad, h.help);
        op.defaultText = h.defKb; op.defaultText2 = h.defPad;
        op.keepBound = !strcmp(h.id, "menu");   // the panel can always be opened: rebindable, never cleared or taken
        op.help = std::string(h.help) + "  A key or button bound here belongs to the mod: the game no longer sees it (a combination: once it is complete, until released).";
        layout.push_back({ h.kbKey, "Hotkeys", h.group });
    }
}
// every frame (xr.cpp): fire the bindings that were just pressed (not while the panel is open or a binding is set)
void W2HotkeysPoll() {
    static bool prevVk[256] = {};
    static w2bind::PadMatcher pm;
    const bool capturing = vrkit::menu::core::Capturing();
    const bool quiet = MenuIsOpen() || capturing;
    const bool front = W2KeysGameInFront();
    const unsigned mods = ModsNow();
    // keys and mouse buttons: on the press of the key, the binding with exactly the modifiers held, else the plain one
    const unsigned mPressed = capturing ? 0 : W2MouseTakePressedHk();   // (while binding, the capture takes the clicks)
    std::vector<w2bind::Key> keys(kN);
    for (int i = 1; i < kN; i++) keys[i] = g_hot[i].k;   // [0] = the panel's binding: vrkit handles it
    bool seen[256] = {};
    for (int i = 1; i < kN; i++) {
        int vk = keys[i].vk;
        if (!vk || seen[vk]) continue;
        seen[vk] = true;
        int mb = w2bind::MouseButtonOfVk(vk);
        bool d = front && (mb >= 0 ? W2MouseButtonDown(mb) : (GetAsyncKeyState(vk) & 0x8000) != 0);
        bool edge = (d && !prevVk[vk]) || (front && mb >= 0 && (mPressed & (1u << mb)) && !prevVk[vk]);
        prevVk[vk] = d;
        if (!edge || quiet) continue;
        int k = w2bind::PickKey(keys, vk, mods);
        if (k > 0) Fire(g_hot[k]);
    }
    uint32_t b = 0; W2PadRaw(&b);
    std::vector<uint32_t> binds;
    AcquireSRWLockShared(&g_lock); binds = g_padBinds; ReleaseSRWLockShared(&g_lock);
    for (int i : pm.Step(b, binds)) if (!quiet && i > 0) Fire(g_hot[i]);
}
// the game's pad read (w2pads.cpp): the buttons it must not see (bound ones, from completion until released)
uint32_t W2HotkeysPadHide(uint32_t buttons) {
    if (!g_padExclusive) return 0;
    AcquireSRWLockShared(&g_lock);
    uint32_t h = g_hider.Step(buttons, g_padBinds);
    ReleaseSRWLockShared(&g_lock);
    return h;
}

// w2bind.h - hotkey bindings (1.1.4): parse / write / show keyboard keys and controller buttons, and decide when a
// controller binding fires and which buttons the game must not see. Plain logic, tested in tests/check_bind.cpp.
//
// Keyboard binding:   [ctrl+][shift+][alt+]<key>        e.g. "end", "ctrl+f7", "num5", "pageup"     ("" = none)
// Controller binding: <button>[+<button>...] (up to 4)  e.g. "back+a", "lb+rb", "lt+rt+y", "dpadleft"  ("" = none)
// Controller buttons use the Xbox names; every controller the mod reads (any XInput slot, PlayStation / Switch / generic
// pads through DirectInput) arrives in the Xbox layout: Cross = A, Circle = B, Square = X, Triangle = Y, L1 = LB, ...
#pragma once
#include <string>
#include <vector>
#include <cstdint>
#include <cctype>
#include <cstdlib>
#include <cstdio>

namespace w2bind {

enum : unsigned { Ctrl = 1, Shift = 2, Alt = 4 };
// controller bits: the 16 XInput button bits (XINPUT_GAMEPAD_*) plus the triggers
enum : uint32_t { PadLT = 1u << 16, PadRT = 1u << 17 };

struct KeyName { const char* cfg; const char* show; int vk; };
inline const KeyName* KeyNames(int* n) {
    static const KeyName k[] = {
        { "insert", "Insert", 0x2D }, { "delete", "Delete", 0x2E }, { "home", "Home", 0x24 }, { "end", "End", 0x23 },
        { "pageup", "Page Up", 0x21 }, { "pagedown", "Page Down", 0x22 }, { "up", "Up", 0x26 }, { "down", "Down", 0x28 },
        { "left", "Left", 0x25 }, { "right", "Right", 0x27 }, { "space", "Space", 0x20 }, { "tab", "Tab", 0x09 },
        { "enter", "Enter", 0x0D }, { "pause", "Pause", 0x13 }, { "scrolllock", "Scroll Lock", 0x91 }, { "printscreen", "Print Screen", 0x2C },
        { "capslock", "Caps Lock", 0x14 },
        { "f1", "F1", 0x70 }, { "f2", "F2", 0x71 }, { "f3", "F3", 0x72 }, { "f4", "F4", 0x73 }, { "f5", "F5", 0x74 }, { "f6", "F6", 0x75 },
        { "f7", "F7", 0x76 }, { "f8", "F8", 0x77 }, { "f9", "F9", 0x78 }, { "f10", "F10", 0x79 }, { "f11", "F11", 0x7A }, { "f12", "F12", 0x7B },
        { "f13", "F13", 0x7C }, { "f14", "F14", 0x7D }, { "f15", "F15", 0x7E }, { "f16", "F16", 0x7F }, { "f17", "F17", 0x80 }, { "f18", "F18", 0x81 },
        { "f19", "F19", 0x82 }, { "f20", "F20", 0x83 }, { "f21", "F21", 0x84 }, { "f22", "F22", 0x85 }, { "f23", "F23", 0x86 }, { "f24", "F24", 0x87 },
        { "num0", "Num 0", 0x60 }, { "num1", "Num 1", 0x61 }, { "num2", "Num 2", 0x62 }, { "num3", "Num 3", 0x63 }, { "num4", "Num 4", 0x64 },
        { "num5", "Num 5", 0x65 }, { "num6", "Num 6", 0x66 }, { "num7", "Num 7", 0x67 }, { "num8", "Num 8", 0x68 }, { "num9", "Num 9", 0x69 },
        { "nummultiply", "Num *", 0x6A }, { "numplus", "Num +", 0x6B }, { "numminus", "Num -", 0x6D }, { "numdecimal", "Num .", 0x6E }, { "numdivide", "Num /", 0x6F },
        { "semicolon", ";", 0xBA }, { "equals", "=", 0xBB }, { "comma", ",", 0xBC }, { "minus", "-", 0xBD }, { "period", ".", 0xBE },
        { "slash", "/", 0xBF }, { "grave", "`", 0xC0 }, { "lbracket", "[", 0xDB }, { "backslash", "\\", 0xDC }, { "rbracket", "]", 0xDD },
        { "apostrophe", "'", 0xDE }, { "oem102", "< >", 0xE2 },
        // mouse buttons (the keyboard column; left / right stay the game's attacks and are never bound)
        { "mouse3", "Mouse 3", 0x04 }, { "mouse4", "Mouse 4", 0x05 }, { "mouse5", "Mouse 5", 0x06 },
    };
    *n = (int)(sizeof k / sizeof k[0]);
    return k;
}

struct Key {
    int vk = 0; unsigned mods = 0;
    bool Empty() const { return vk == 0; }
    bool operator==(const Key& o) const { return vk == o.vk && mods == o.mods; }
};

inline std::string Lower(const std::string& s) { std::string r; for (char c : s) if (c != ' ') r += (char)tolower((unsigned char)c); return r; }
inline std::vector<std::string> Split(const std::string& s) {
    std::vector<std::string> v; std::string cur;
    for (size_t i = 0; i < s.size(); i++) {
        char c = s[i];
        // '+' separates, except "numplus" style names never contain it and a trailing "+" alone means the plus key (rare)
        if (c == '+' && !cur.empty()) { v.push_back(cur); cur.clear(); } else if (c != '+') cur += c;
    }
    if (!cur.empty()) v.push_back(cur);
    return v;
}
inline int VkFromToken(const std::string& t) {
    if (t.empty()) return 0;
    if (t.size() == 1 && isalnum((unsigned char)t[0])) return toupper((unsigned char)t[0]);
    int n; const KeyName* k = KeyNames(&n);
    for (int i = 0; i < n; i++) if (t == k[i].cfg) return k[i].vk;
    if (t.size() > 2 && t[0] == '0' && t[1] == 'x') { long v = strtol(t.c_str(), nullptr, 16); return v > 0 && v < 256 ? (int)v : 0; }
    return 0;
}
inline Key KeyParse(const std::string& s) {
    Key r;
    for (auto& t : Split(Lower(s))) {
        if (t == "ctrl" || t == "control") r.mods |= Ctrl;
        else if (t == "shift") r.mods |= Shift;
        else if (t == "alt") r.mods |= Alt;
        else if (t == "none") return Key();
        else { int vk = VkFromToken(t); if (!vk) return Key(); r.vk = vk; }
    }
    if (!r.vk) r.mods = 0;
    return r;
}
inline std::string VkToken(int vk, bool show) {
    if ((vk >= 'A' && vk <= 'Z') || (vk >= '0' && vk <= '9')) { char b[2] = { (char)(show ? vk : tolower(vk)), 0 }; return b; }
    int n; const KeyName* k = KeyNames(&n);
    for (int i = 0; i < n; i++) if (k[i].vk == vk) return show ? k[i].show : k[i].cfg;
    char b[8]; snprintf(b, sizeof b, "0x%02x", vk & 0xFF); return b;
}
inline std::string KeyWrite(const Key& k, bool show = false) {
    if (k.Empty()) return "";
    std::string r, sep = show ? " + " : "+";
    if (k.mods & Ctrl) r += (show ? "Ctrl" : "ctrl") + sep;
    if (k.mods & Shift) r += (show ? "Shift" : "shift") + sep;
    if (k.mods & Alt) r += (show ? "Alt" : "alt") + sep;
    return r + VkToken(k.vk, show);
}
inline bool KeyKnown(int vk) { return !VkToken(vk, false).empty() && VkToken(vk, false).compare(0, 2, "0x") != 0; }

inline bool IsMouseVk(int vk) { return vk == 0x04 || vk == 0x05 || vk == 0x06; }
inline int MouseButtonOfVk(int vk) { return vk == 0x04 ? 2 : vk == 0x05 ? 3 : vk == 0x06 ? 4 : -1; }   // DirectInput button index
// Which keyboard binding a key press fires: the one with exactly the modifiers held, otherwise the one without modifiers
// (so a plain "End" still works while Shift is held for walking); -1 = none.
inline int PickKey(const std::vector<Key>& binds, int vk, unsigned mods) {
    int plain = -1;
    for (size_t i = 0; i < binds.size(); i++) {
        if (binds[i].vk != vk) continue;
        if (binds[i].mods == mods) return (int)i;
        if (binds[i].mods == 0 && plain < 0) plain = (int)i;
    }
    return plain;
}
// A bound key is hidden from the game when it would fire: a binding with the modifiers held now, or one without any.
// modsMask: bit (1 << modifier set) for each binding of the key.
inline bool KeyHidden(unsigned modsMask, unsigned mods) { return modsMask && ((modsMask & (1u << (mods & 7))) || (modsMask & 1u)); }
// The panel's own binding must not be a key / button the open panel uses to navigate, or the panel could not be used.
inline bool MenuKeyOk(int vk) {
    switch (vk) { case 0x0D: case 0x08: case 0x1B: case 0x21: case 0x22: case 0x25: case 0x26: case 0x27: case 0x28: case 0x2E: return false; }
    return !IsMouseVk(vk);
}

// ---------------------------------------------------------------- controller
struct PadName { const char* cfg; const char* show; uint32_t bit; };
inline const PadName* PadNames(int* n) {
    static const PadName p[] = {
        { "a", "A", 0x1000 }, { "b", "B", 0x2000 }, { "x", "X", 0x4000 }, { "y", "Y", 0x8000 },
        { "lb", "LB", 0x0100 }, { "rb", "RB", 0x0200 }, { "lt", "LT", PadLT }, { "rt", "RT", PadRT },
        { "ls", "L3", 0x0040 }, { "rs", "R3", 0x0080 }, { "back", "Back", 0x0020 }, { "start", "Start", 0x0010 },
        { "dpadup", "D-pad Up", 0x0001 }, { "dpaddown", "D-pad Down", 0x0002 }, { "dpadleft", "D-pad Left", 0x0004 }, { "dpadright", "D-pad Right", 0x0008 },
    };
    *n = (int)(sizeof p / sizeof p[0]);
    return p;
}
inline int PadCount(uint32_t m) { int c = 0; for (; m; m &= m - 1) c++; return c; }
// a single panel-navigation button (A B X Y LB RB D-pad) is not usable to open / close the panel (held, it would close it)
inline bool MenuPadOk(uint32_t m) { return m && !(PadCount(m) == 1 && (m & 0xF30Fu)); }
inline uint32_t PadParse(const std::string& s) {
    uint32_t m = 0; int n; const PadName* p = PadNames(&n);
    for (auto& t0 : Split(Lower(s))) {
        std::string t = t0;
        if (t == "none") return 0;
        static const char* const alias[][2] = { { "l3", "ls" }, { "r3", "rs" }, { "select", "back" }, { "view", "back" }, { "menu", "start" },
                                                { "up", "dpadup" }, { "down", "dpaddown" }, { "left", "dpadleft" }, { "right", "dpadright" } };
        for (auto& al : alias) if (t == al[0]) { t = al[1]; break; }
        bool ok = false;
        for (int i = 0; i < n; i++) if (t == p[i].cfg) { m |= p[i].bit; ok = true; }
        if (!ok) return 0;
    }
    return PadCount(m) <= 4 ? m : 0;
}
inline std::string PadWrite(uint32_t m, bool show = false) {
    std::string r; int n; const PadName* p = PadNames(&n);
    for (int i = 0; i < n; i++) if (m & p[i].bit) { if (!r.empty()) r += show ? " + " : "+"; r += show ? p[i].show : p[i].cfg; }
    return r;
}
// canonical forms (what the config gets after any edit)
inline std::string KeyCanon(const std::string& s) { return KeyWrite(KeyParse(s)); }
inline std::string PadCanon(const std::string& s) { return PadWrite(PadParse(s)); }

// When controller bindings fire: on the press that completes the combination. If a larger combination that contains it
// is complete in the same moment, only the larger one fires (LB+A does not also fire A).
struct PadMatcher {
    uint32_t prev = 0;
    std::vector<int> Step(uint32_t now, const std::vector<uint32_t>& binds) {
        std::vector<int> fired;
        for (size_t i = 0; i < binds.size(); i++) {
            uint32_t b = binds[i];
            if (!b || (now & b) != b || (prev & b) == b) continue;
            bool bigger = false;
            for (size_t j = 0; j < binds.size() && !bigger; j++)
                if (j != i && binds[j] != b && (binds[j] & b) == b && (now & binds[j]) == binds[j]) bigger = true;
            if (!bigger) fired.push_back((int)i);
        }
        prev = now;
        return fired;
    }
};
// Which buttons the game must not see: a bound button / combination from the moment it is complete until each of its
// buttons is released (a combination's first buttons reach the game until the last one completes it).
struct PadHider {
    uint32_t hidden = 0;
    uint32_t Step(uint32_t now, const std::vector<uint32_t>& binds) {
        for (uint32_t b : binds) if (b && (now & b) == b) hidden |= b;
        hidden &= now;
        return hidden;
    }
};
// Capturing a controller binding: buttons held when capture starts are ignored until released; then every button pressed
// is collected, and the binding is the set that was held together once everything is released again.
struct PadCapture {
    uint32_t ignore = 0, got = 0;
    void Begin(uint32_t now) { ignore = now; got = 0; }
    // returns the binding when complete, 0 while waiting
    uint32_t Step(uint32_t now) {
        ignore &= now;
        uint32_t live = now & ~ignore;
        if (live) { if (PadCount(got | live) <= 4) got |= live; return 0; }
        if (got && !(now & ~ignore)) { uint32_t r = got; got = 0; return r; }
        return 0;
    }
};

} // namespace w2bind

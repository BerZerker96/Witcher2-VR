// w2fp.h - first person: when to use it and how strongly (1.1.3). Plain logic, tested in tests/check_fp.cpp.
//
// W2VR's first person moves the game's orbit camera forward to Geralt (first_person_distance ahead along its view axis,
// plus small right / up offsets) and pushes the near plane out so the inside of his head is not drawn. Two things made
// it rough:
//  * dialogues and cutscenes use their own cameras - moving those 3 m forward put the view through walls and faces;
//  * switching it on / off (End, the panel) snapped the view by metres in one frame.
// Cinematic cameras are told apart by their field of view: gameplay keeps one (the game's FOV setting), dialogue and
// cutscene shots use their own. The gameplay FOV is learned while playing; a different FOV that holds for 0.25 s is a
// cinematic shot, back within tolerance for 0.5 s is gameplay again. After the game's menu closes (the FOV option may
// have changed) the value is learned again, and an
// off-value FOV that holds unchanged for 15 s is taken as the gameplay one (the first value learned was a cutscene's). The weight then glides to its target over first_person_blend seconds
// (smoothstep), so every change is a short, smooth move.
#pragma once
#include <cmath>

namespace w2fp {
struct State {
    float gameplayFov = 0;       // learned (degrees, the game camera's own)
    float offFor = 0, onFor = 0; // seconds the FOV has been away from / back at the gameplay value
    bool cinematic = false;
    float w = 0;                 // 0 = game camera, 1 = first person (linear; Weight() eases it)
    bool lastMenu = false;
    float tolerance = 2.5f;      // degrees
    float steadyFov = 0, steadyFor = 0;   // an off-value FOV held unchanged: 15 s of it = learned wrong (loaded into a cutscene)
    // fov = the game camera's field of view this tick; menu = the game's own menu open; dt = seconds since last tick
    void Update(float fov, bool menu, bool want, bool cutsceneOff, float blend, float dt) {
        if (dt < 0) dt = 0; if (dt > 0.25f) dt = 0.25f;
        if (lastMenu && !menu) { gameplayFov = 0; cinematic = false; offFor = onFor = 0; }   // the FOV option may have changed
        lastMenu = menu;
        if (fov > 1.f && fov < 170.f && !menu) {
            if (gameplayFov <= 0) gameplayFov = fov;
            bool near_ = fabsf(fov - gameplayFov) <= tolerance;
            if (near_) { onFor += dt; offFor = 0; if (!cinematic) gameplayFov += (fov - gameplayFov) * 0.05f; }
            else {
                offFor += dt; onFor = 0;
                if (fabsf(fov - steadyFov) <= 0.2f) steadyFor += dt; else { steadyFov = fov; steadyFor = 0; }
                if (steadyFor >= 15.f) { gameplayFov = fov; cinematic = false; offFor = 0; steadyFor = 0; }
            }
            if (!cinematic && offFor >= 0.25f) cinematic = true;
            if (cinematic && onFor >= 0.5f) cinematic = false;
        }
        float target = (want && !(cutsceneOff && cinematic)) ? 1.f : 0.f;
        if (blend <= 0.001f) w = target;
        else { float st = dt / blend; w = w < target ? fminf(target, w + st) : fmaxf(target, w - st); }
    }
    float Weight() const { return w * w * (3.f - 2.f * w); }   // smoothstep: starts and ends gently
};
} // namespace w2fp

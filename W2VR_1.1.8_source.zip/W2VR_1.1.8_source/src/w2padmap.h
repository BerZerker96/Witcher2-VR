// w2padmap.h - DirectInput controllers in the Xbox layout (1.1.4): button tables, the hat, the triggers, and which of
// several controllers is the one in use. Plain logic, tested in tests/check_padmap.cpp.
#pragma once
#include <cstdint>
#include <cstdlib>

namespace w2padmap {

enum : uint16_t { Up = 0x0001, Down = 0x0002, Left = 0x0004, Right = 0x0008 };   // XINPUT_GAMEPAD_DPAD_*

// DirectInput button numbers (0-based) for A, B, X, Y, LB, RB, Back, Start, LS, RS, and the LT / RT buttons
struct Layout { int btn[10]; int lt, rt, back2; };
// 0 generic "DirectInput mode" (Logitech / 8BitDo / most USB pads: 1 2 3 4 = X A B Y), 1 PlayStation (DualShock 4 /
// DualSense: Square Cross Circle Triangle L1 R1 L2 R2 Share Options L3 R3 PS Touchpad), 2 Nintendo (Switch Pro: B A Y X
// L R ZL ZR - + LS RS Home Capture; mapped by position, so the bottom button is A as on an Xbox pad)
inline Layout ForLayout(int layout) {
    static const Layout gen  = { { 1, 2, 0, 3, 4, 5, 8, 9, 10, 11 }, 6, 7, -1 };
    static const Layout sony = { { 1, 2, 0, 3, 4, 5, 8, 9, 10, 11 }, 6, 7, 13 };   // touchpad click = Back too
    static const Layout nin  = { { 0, 1, 2, 3, 4, 5, 8, 9, 10, 11 }, 6, 7, -1 };
    return layout == 1 ? sony : layout == 2 ? nin : gen;
}

// the hat (POV, hundredths of a degree clockwise from up; 0xFFFF in the low word = centred). A diagonal gives both
// directions (45 deg = up + right), with a 22.5 deg band each side of every diagonal counting as the diagonal.
inline uint16_t Pov(uint32_t pov) {
    if ((pov & 0xFFFF) == 0xFFFF || pov >= 36000) return 0;
    uint16_t b = 0;
    if (pov >= 29250 || pov <= 6750) b |= Up;
    if (pov >= 2250 && pov <= 15750) b |= Right;
    if (pov >= 11250 && pov <= 24750) b |= Down;
    if (pov >= 20250 && pov <= 33750) b |= Left;
    return b;
}

// an axis (-32768..32767, rest -32768) as a trigger 0..255
inline uint8_t Trigger(long v) { long t = (v + 32768) >> 8; return (uint8_t)(t < 0 ? 0 : t > 255 ? 255 : t); }
// both triggers on one centred axis (Z: left pulls positive, right negative - the Xbox 360 convention most generic pads
// with this layout copy): each side as its trigger
inline void SharedZ(long z, uint8_t& lt, uint8_t& rt) {
    long a = z > 0 ? z : 0, b = z < 0 ? -z : 0;
    a = a > 8000 ? (a - 8000) * 255 / (32767 - 8000) : 0; b = b > 8000 ? (b - 8000) * 255 / (32768 - 8000) : 0;   // small dead zone at rest
    lt = (uint8_t)(a > 255 ? 255 : a); rt = (uint8_t)(b > 255 ? 255 : b);
}

// which controller to open first when several are attached: gamepads before joysticks / wheels, PlayStation / Nintendo
// pads (known layouts) first among gamepads
inline int Score(bool gamepad, bool joystick, uint16_t vendor) {
    int s = gamepad ? 4 : joystick ? 2 : 0;
    if (vendor == 0x054C || vendor == 0x057E) s += 1;
    return s;
}

// input that shows a controller is being used: a button pressed (edge) or a stick / trigger moved clearly since the
// last sample - not a level, so an axis resting at an end (a throttle, a pedal, a drifting stick) never counts
struct Pad { uint16_t b; uint8_t lt, rt; int16_t lx, ly, rx, ry; };
inline bool Used(const Pad& now, const Pad& prev) {
    if (now.b & ~prev.b) return true;
    auto mv = [](int a, int b) { return std::abs(a - b) > 6000; };
    return mv(now.lx, prev.lx) || mv(now.ly, prev.ly) || mv(now.rx, prev.rx) || mv(now.ry, prev.ry) ||
           std::abs((int)now.lt - (int)prev.lt) > 60 || std::abs((int)now.rt - (int)prev.rt) > 60;
}
// a combined trigger axis (Z) rests in the middle; anything else on Z (a throttle, a slider) is not taken as triggers
inline bool SharedZPlausible(long zAtRest) { return std::labs(zAtRest) < 6000; }

// several DirectInput controllers: the one used last is the one the game reads (as with the XInput slots)
struct Picker {
    int cur = -1; uint32_t last[4] = {};
    // active[i]: controller i has input now; tick: a millisecond clock. Returns the controller to use (-1 none)
    // eligible[i]: open and allowed (joysticks / wheels only while no gamepad is open)
    int Step(const bool open[4], const bool active[4], uint32_t tick) {
        for (int i = 0; i < 4; i++) if (open[i] && active[i]) last[i] = tick ? tick : 1;
        if (cur >= 0 && !open[cur]) cur = -1;
        int best = cur;
        for (int i = 0; i < 4; i++) {
            if (!open[i]) continue;
            if (best < 0) { best = i; continue; }
            if (last[i] && (int32_t)(last[i] - last[best]) > 0) best = i;
        }
        cur = best;
        return cur;
    }
};

} // namespace w2padmap

// w2keys.cpp - keyboard compatibility (1.0.8).
//
// The Witcher 2 reads the keyboard through DirectInput (DIK codes, bound in Documents\Witcher 2\Config\Input_*.ini /
// User.ini as IK_<key>=(GameKey=...)). The mod reads its own keys with GetAsyncKeyState. Without care:
//  * while the VR panel is open, its keys (arrows, Enter, Backspace, Page Up / Down, Delete) also moved Geralt or
//    pressed game buttons, and the mouse turned the camera;
//  * a key held when the panel closed (Enter) reached the game as a fresh press;
//  * a mod hotkey the player had also bound in the game did both things at once;
//  * the mod's hotkeys fired while typing in another window (GetAsyncKeyState sees every key in Windows).
// Now:
//  * panel open: the game sees no keyboard and no mouse input; after closing, keys still held stay hidden until released;
//  * the mod's hotkeys are the mod's: hidden from the game (keyboard_exclusive_hotkeys = true); a clash with the
//    player's own bindings is logged at start;
//  * the mod's keys only act while the game window (or the VR panel host) is in front.
#include <windows.h>
#include <string>
#include <vector>
#include <cstring>
#include "log.h"
#include "config.h"
#include "w2mirror.h"
#include "w2bind.h"

bool MenuIsOpen();
HWND W2GameWindow();
std::wstring DocumentsDir();

WORD W2PadButtonsNear(unsigned ms); const char* W2PadButtonName(int bit);
namespace {
bool g_exclusive = true;
uint8_t g_hotMods[256] = {};      // the mod's hotkeys (DIK codes): bit (1 << modifier set) for each binding of the key
unsigned ModsNow() { return ((GetAsyncKeyState(VK_CONTROL) & 0x8000) ? 1 : 0) | ((GetAsyncKeyState(VK_SHIFT) & 0x8000) ? 2 : 0) | ((GetAsyncKeyState(VK_MENU) & 0x8000) ? 4 : 0); }
bool g_heldAtClose[256] = {};     // held when the panel closed: hidden until released
bool g_wasOpen = false;
volatile LONG g_mdx = 0, g_mdy = 0, g_mdz = 0, g_mBtn = 0, g_mPressed = 0, g_mPressedHk = 0; volatile DWORD g_mFeedTick = 0;   // mouse (1.1.4)
LONG g_mHeldClose = 0;          // mouse buttons held when the panel closed
uint8_t g_hotMouse[5] = {};     // bound mouse buttons (modifier-set bits, as g_hotMods)
volatile LONG g_blockedReads = 0, g_hotHidden = 0;

int DikFromVk(int vk) {
    UINT sc = MapVirtualKeyW((UINT)vk, 4 /* MAPVK_VK_TO_VSC_EX */);
    if (!sc) return -1;
    int dik = (int)(sc & 0x7F) | ((sc & 0xFF00) ? 0x80 : 0);
    // keys MapVirtualKey reports without the E0 prefix but DirectInput codes as extended
    switch (vk) { case VK_HOME: case VK_END: case VK_INSERT: case VK_DELETE: case VK_PRIOR: case VK_NEXT:
                  case VK_UP: case VK_DOWN: case VK_LEFT: case VK_RIGHT: dik = (int)(sc & 0x7F) | 0x80; break; }
    return dik & 0xFF;
}
int VkFromDik(int dik) {
    UINT sc = (UINT)(dik & 0x7F) | ((dik & 0x80) ? 0xE000 : 0);
    return (int)MapVirtualKeyW(sc, 3 /* MAPVK_VSC_TO_VK_EX */);
}
void PanelClosedNow() {
    for (int d = 1; d < 256; d++) { int vk = VkFromDik(d); g_heldAtClose[d] = vk && (GetAsyncKeyState(vk) & 0x8000); }
}
// keys the game must not see right now
bool Hidden(int dik, bool down) {
    if (dik <= 0 || dik > 255) return false;
    if (g_heldAtClose[dik]) { if (!down) g_heldAtClose[dik] = false; return down; }
    return g_exclusive && w2bind::KeyHidden(g_hotMods[dik], ModsNow());
}
LONG g_keyEdges[256] = {}; uint8_t g_keyPrev[256] = {};
// 1.0.9: keys that arrive with a pad button. A controller layout (Steam Input, DS4Windows, reWASD...) can send a
// keyboard key along with a button - one user's Square also sent "0", which the game binds to "put the sword away":
// every fast attack sheathed the sword and broke QTEs. Such a key is learned (it came with the same button at least
// twice and in 80 % of its presses) and from then on hidden from the game whenever it comes with that button; typed on
// the keyboard alone it still works. keyboard_pad_mirror_keys = 0B,... (DIK codes, hex) hides them from the start.
bool g_mirrorOn = true;
w2mirror::Learner g_mirror;
bool g_mHidS[256] = {}, g_mHidD[256] = {}; bool g_rawPrev[256] = {};
ULONGLONG g_mDecTick[256] = {}; bool g_mDec[256] = {};
volatile LONG g_mirrorHidden = 0;
bool MirrorHide(int d) {   // called on a key's down edge (state or buffered path; one decision per press)
    ULONGLONG t = GetTickCount64();
    if (g_mDecTick[d] && t - g_mDecTick[d] < 60) return g_mDec[d];
    bool hide = false;
    if (g_mirrorOn) {
        int nb;
        hide = g_mirror.Press(d, W2PadButtonsNear(250), &nb);
        if (nb >= 0) {
            char nm[32] = {}; LONG lp = ((d & 0x7F) << 16) | ((d & 0x80) ? (1 << 24) : 0);
            if (!GetKeyNameTextA(lp, nm, sizeof nm)) _snprintf(nm, sizeof nm, "DIK %02X", d);
            LOGW("keys: the key \"%s\" comes with every pad %s press - sent by a controller tool (Steam Input layout, DS4Windows, reWASD...). "
                 "Hidden from the game when it comes with the button (the game binds keys like 0 to sheathing the sword). "
                 "Better: remove it from the controller layout. To hide it from the start: keyboard_pad_mirror_keys = %02X", nm, W2PadButtonName(nb), d);
        }
        if (hide) InterlockedIncrement(&g_mirrorHidden);
    }
    g_mDecTick[d] = t; g_mDec[d] = hide;
    return hide;
}
void Track() {
    bool open = MenuIsOpen();
    if (g_wasOpen && !open) { PanelClosedNow(); g_mHeldClose = g_mBtn; }
    g_wasOpen = open;
}
const char* const kNames[] = { "Insert (VR panel)", "F8 (VR mode)", "F10 (diagnostic images)" };
}

// 1.1.4: the mouse. The game's own DirectInput mouse reads are watched on every read: the buttons (all five) are tracked
// with their press edges - for the VR panel (left / right / middle) and for hotkeys bound to Mouse 3 / 4 / 5. While the
// panel is open the movement and wheel feed the panel's cursor and the game gets nothing; while it is closed, buttons
// bound to hotkeys are hidden from the game, and buttons still held when the panel closed stay hidden until released
// (the click on the panel's close button is not an attack).
static void MouseButton(int i, bool down) {
    if (i < 0 || i > 4) return;
    LONG bit = 1L << i;
    if (down) {
        if (!(g_mBtn & bit)) { InterlockedOr(&g_mPressed, bit); InterlockedOr(&g_mPressedHk, bit); }   // press edge only
        InterlockedOr(&g_mBtn, bit);
    } else InterlockedAnd(&g_mBtn, ~bit);
}
// what the game must not see of button i now
static bool MouseHidden(int i, bool down) {
    LONG bit = 1L << i;
    if (g_mHeldClose & bit) { if (!down) g_mHeldClose &= ~bit; return true; }
    return g_exclusive && i < 5 && w2bind::KeyHidden(g_hotMouse[i], ModsNow());
}
static void MouseFeedState(uint8_t* d, DWORD cb, bool open) {
    if (cb < 16) return;
    int nb = (int)(cb - 12); if (nb > 5) nb = 5;
    for (int i = 0; i < nb; i++) MouseButton(i, (d[12 + i] & 0x80) != 0);
    g_mFeedTick = GetTickCount();
    if (open) {
        LONG x, y, z; memcpy(&x, d, 4); memcpy(&y, d + 4, 4); memcpy(&z, d + 8, 4);
        InterlockedExchangeAdd(&g_mdx, x); InterlockedExchangeAdd(&g_mdy, y); InterlockedExchangeAdd(&g_mdz, z);
        return;   // (the caller blanks it all)
    }
    for (int i = 0; i < nb; i++) if (MouseHidden(i, (d[12 + i] & 0x80) != 0)) d[12 + i] = 0;
}
// buffered reads: returns the new event count (events of hidden buttons removed while the panel is closed)
static DWORD MouseFeedData(DWORD cbObj, uint8_t* p, DWORD n, bool open) {
    DWORD out = 0;
    for (DWORD i = 0; i < n; i++) {
        DWORD ofs, val; memcpy(&ofs, p + i * cbObj, 4); memcpy(&val, p + i * cbObj + 4, 4);
        bool keep = true;
        if (ofs >= 12 && ofs <= 16) {
            int b = (int)ofs - 12; bool down = (val & 0x80) != 0;
            MouseButton(b, down);
            if (!open && MouseHidden(b, down)) keep = false;
        } else if (open) {
            if (ofs == 0) InterlockedExchangeAdd(&g_mdx, (LONG)val);
            else if (ofs == 4) InterlockedExchangeAdd(&g_mdy, (LONG)val);
            else if (ofs == 8) InterlockedExchangeAdd(&g_mdz, (LONG)val);
        }
        if (keep) { if (out != i) memmove(p + out * cbObj, p + i * cbObj, cbObj); out++; }
    }
    g_mFeedTick = GetTickCount();
    return out;
}
// hotkeys: a mouse button (0..4) down now (game reads, or Windows when the game does not read the mouse), and the
// buttons pressed since the last call
bool W2MouseButtonDown(int i) {
    if (i < 0 || i > 4) return false;
    if (g_mBtn & (1L << i)) return true;
    static const int vk[5] = { VK_LBUTTON, VK_RBUTTON, VK_MBUTTON, VK_XBUTTON1, VK_XBUTTON2 };
    return GetTickCount() - g_mFeedTick > 300 && (GetAsyncKeyState(vk[i]) & 0x8000) != 0;
}
unsigned W2MouseTakePressedHk() { return (unsigned)InterlockedExchange(&g_mPressedHk, 0); }
bool W2KeysGameInFront();
// the panel takes what came since the last call; when the game does not read the mouse (window not in front, or a
// game build that uses window messages), the Windows cursor's movement and buttons are used instead
void W2MouseTake(float* dx, float* dy, float* wheel, unsigned* buttons, unsigned* pressed) {
    *dx = (float)InterlockedExchange(&g_mdx, 0); *dy = (float)InterlockedExchange(&g_mdy, 0);
    *wheel = (float)InterlockedExchange(&g_mdz, 0) / 120.f;
    *pressed = (unsigned)InterlockedExchange(&g_mPressed, 0) & 7u; *buttons = (unsigned)g_mBtn & 7u;
    static POINT last; static bool have = false; static unsigned prevB = 0;
    if (GetTickCount() - g_mFeedTick > 300 && W2KeysGameInFront()) {
        POINT p; if (GetCursorPos(&p)) { if (have) { *dx += (float)(p.x - last.x); *dy += (float)(p.y - last.y); } last = p; have = true; }
        unsigned b = ((GetAsyncKeyState(VK_LBUTTON) & 0x8000) ? 1u : 0u) | ((GetAsyncKeyState(VK_RBUTTON) & 0x8000) ? 2u : 0u) | ((GetAsyncKeyState(VK_MBUTTON) & 0x8000) ? 4u : 0u);
        *pressed |= b & ~prevB; *buttons |= b; prevB = b;
    } else { have = false; prevB = 0; }
}
// the mod's hotkeys (virtual-key code + modifiers), set at start and whenever a binding changes in the panel
void W2KeysSetHot(const std::vector<std::pair<int, unsigned>>& keys) {
    uint8_t t[256] = {};
    uint8_t m[5] = {};
    for (auto& k : keys) {
        int mb = w2bind::MouseButtonOfVk(k.first);
        if (mb >= 0) { m[mb] |= (uint8_t)(1u << (k.second & 7)); continue; }
        int d = k.first ? DikFromVk(k.first) : -1; if (d > 0) t[d] |= (uint8_t)(1u << (k.second & 7));
    }
    memcpy(g_hotMods, t, sizeof t); memcpy(g_hotMouse, m, sizeof m);
}

// the game reading the keyboard / mouse state: called by the DirectInput hooks (w2engine.cpp)
void W2KeysFilterState(bool keyboard, bool mouse, void* data, DWORD cb) {
    if (!data || !cb) return;
    Track();
    const bool open = MenuIsOpen();
    if (mouse) MouseFeedState((uint8_t*)data, cb, open);
    if (open) {
        if (keyboard || mouse) { memset(data, 0, cb); InterlockedIncrement(&g_blockedReads); }
        return;
    }
    if (!keyboard || cb < 256) return;
    uint8_t* k = (uint8_t*)data;
    for (int d = 1; d < 256; d++) {
        bool down = (k[d] & 0x80) != 0;
        bool edge = down && !g_rawPrev[d]; g_rawPrev[d] = down;
        if (edge && MirrorHide(d)) g_mHidS[d] = true;
        if (!down) g_mHidS[d] = false;
        if (g_mHidS[d]) { k[d] = 0; down = false; }
        if (Hidden(d, down)) { if (down) InterlockedIncrement(&g_hotHidden); k[d] = 0; down = false; }
        if (down && !(g_keyPrev[d] & 0x80)) g_keyEdges[d]++;   // keys the game got pressed (report)
        g_keyPrev[d] = k[d];
    }
}
// buffered input (DIDEVICEOBJECTDATA: dwOfs = DIK code for a keyboard, dwData & 0x80 = down)
void W2KeysFilterData(bool keyboard, bool mouse, DWORD cbObj, void* rg, DWORD* n) {
    if (!rg || !n || !*n || cbObj < 8) return;
    Track();
    const bool open = MenuIsOpen();
    if (mouse) *n = MouseFeedData(cbObj, (uint8_t*)rg, *n, open);
    if (open) {
        // 1.1.5: presses and movement are kept from the game, releases are not - a key / button held when the panel
        // opened would otherwise stay down in the game after it closes (Geralt walking on by himself)
        if (keyboard || mouse) {
            uint8_t* p = (uint8_t*)rg; DWORD out = 0;
            for (DWORD i = 0; i < *n; i++) {
                DWORD ofs, val; memcpy(&ofs, p + i * cbObj, 4); memcpy(&val, p + i * cbObj + 4, 4);
                bool release = !(val & 0x80) && (keyboard ? (ofs > 0 && ofs < 256) : (ofs >= 12 && ofs <= 19));
                if (!release) continue;
                if (out != i) memmove(p + out * cbObj, p + i * cbObj, cbObj);
                out++;
            }
            *n = out; InterlockedIncrement(&g_blockedReads);
        }
        return;
    }
    if (!keyboard) return;
    uint8_t* p = (uint8_t*)rg; DWORD out = 0;
    for (DWORD i = 0; i < *n; i++) {
        DWORD ofs, val; memcpy(&ofs, p + i * cbObj, 4); memcpy(&val, p + i * cbObj + 4, 4);
        if (ofs > 0 && ofs < 256) {   // keys sent with a pad button (see MirrorHide)
            if (val & 0x80) { if (MirrorHide((int)ofs)) { g_mHidD[ofs] = true; continue; } }
            else if (g_mHidD[ofs]) { g_mHidD[ofs] = false; continue; }
        }
        if (Hidden((int)ofs, (val & 0x80) != 0)) { if (val & 0x80) InterlockedIncrement(&g_hotHidden); continue; }
        if ((val & 0x80) && ofs < 256) g_keyEdges[ofs]++;
        if (out != i) memmove(p + out * cbObj, p + i * cbObj, cbObj);
        out++;
    }
    *n = out;
}

// the mod's own keys act only while the game is the window in front (or one of the process' own windows)
bool W2KeysGameInFront() {
    HWND fg = GetForegroundWindow();
    if (!fg) return false;
    DWORD pid = 0; GetWindowThreadProcessId(fg, &pid);
    return pid == GetCurrentProcessId();
}

// called once at start with the mod's hotkeys (virtual-key codes): marks them, then checks the player's bindings
void W2KeysInstall(const std::vector<std::pair<int, std::string>>& hot) {
    g_exclusive = ConfigBool("keyboard_exclusive_hotkeys", true);
    g_mirrorOn = ConfigBool("keyboard_pad_mirror_filter", true);
    {   std::string m = ConfigStr("keyboard_pad_mirror_keys", "");
        for (const char* p = m.c_str(); *p; ) { char* e; long v = strtol(p, &e, 16); if (e == p) { p++; continue; } if (v > 0 && v < 256) g_mirror.preset[v] = true; p = e; } }
    // (the keys hidden from the game come from W2KeysSetHot - live, with modifiers)
    // the player's bindings: IK_<Name>=(GameKey=...) in the game's input files
    std::wstring dir = DocumentsDir() + L"\\Witcher 2\\Config\\";
    const wchar_t* files[] = { L"Input_QWERTY.ini", L"Input_AZERTY.ini", L"Input_QWERTZ.ini", L"User.ini" };
    struct IkName { const char* ik; int vk; } ik[] = { { "IK_Insert", VK_INSERT }, { "IK_Home", VK_HOME }, { "IK_End", VK_END }, { "IK_Delete", VK_DELETE },
        { "IK_PageUp", VK_PRIOR }, { "IK_PageDown", VK_NEXT }, { "IK_F1", VK_F1 }, { "IK_F2", VK_F2 }, { "IK_F3", VK_F3 }, { "IK_F4", VK_F4 }, { "IK_F5", VK_F5 },
        { "IK_F6", VK_F6 }, { "IK_F7", VK_F7 }, { "IK_F8", VK_F8 }, { "IK_F9", VK_F9 }, { "IK_F10", VK_F10 }, { "IK_F11", VK_F11 }, { "IK_F12", VK_F12 },
        { "IK_Space", VK_SPACE }, { "IK_Pause", VK_PAUSE }, { "IK_ScrollLock", VK_SCROLL } };
    int clashes = 0, padLogged = 0;
    for (const wchar_t* f : files) {
        HANDLE h = CreateFileW((dir + f).c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
        if (h == INVALID_HANDLE_VALUE) continue;
        std::string t; char b[8192]; DWORD r;
        while (ReadFile(h, b, sizeof b, &r, nullptr) && r) t.append(b, r);
        CloseHandle(h);
        if (t.size() >= 2 && (uint8_t)t[0] == 0xFF && (uint8_t)t[1] == 0xFE) { std::string a; for (size_t i = 2; i + 1 < t.size(); i += 2) a += t[i]; t = a; }   // UTF-16
        size_t pos = 0;
        while ((pos = t.find("IK_", pos)) != std::string::npos) {
            size_t eq = t.find('=', pos), nl = t.find_first_of("\r\n", pos);
            if (eq == std::string::npos || (nl != std::string::npos && eq > nl)) { pos += 3; continue; }
            std::string name = t.substr(pos, eq - pos);
            std::string act = t.substr(eq + 1, (nl == std::string::npos ? t.size() : nl) - eq - 1);
            pos = eq;
            if (act.find("GameKey") == std::string::npos && act.find("Gamekey") == std::string::npos) continue;
            if (!_strnicmp(name.c_str(), "IK_Pad_", 7) && padLogged < 40) {   // the pad bindings the game will use (diagnosis)
                char fn[64]; WideCharToMultiByte(CP_UTF8, 0, f, -1, fn, sizeof fn, nullptr, nullptr);
                LOGI("keys: %s: %s=%s", fn, name.c_str(), act.substr(0, 70).c_str()); padLogged++;
            }
            for (auto& k : ik) {
                if (_stricmp(name.c_str(), k.ik)) continue;
                for (auto& hk : hot) if (hk.first == k.vk) {
                    clashes++;
                    if (clashes <= 8) {
                        char fn[64]; WideCharToMultiByte(CP_UTF8, 0, f, -1, fn, sizeof fn, nullptr, nullptr);
                        LOGW("keys: %s is bound in the game too (%s: %s=%s)%s", hk.second.c_str(), fn, name.c_str(), act.substr(0, 60).c_str(),
                             g_exclusive ? " - the mod's key wins, the game does not see it; change the mod's key in w2vr_config.txt to keep the game's" : " - both act (keyboard_exclusive_hotkeys = false)");
                    }
                }
            }
        }
    }
    int n = 0; for (uint8_t b : g_hotMods) n += b != 0;
    LOGI("keys: %d mod hotkeys%s; %d clash(es) with the game's bindings; while the VR panel is open the game sees no keyboard / mouse input",
         n, g_exclusive ? " (hidden from the game)" : "", clashes);
    (void)kNames;
}
void W2KeysReport() {
    LONG b = InterlockedExchange(&g_blockedReads, 0), h = InterlockedExchange(&g_hotHidden, 0);
    LONG mh = InterlockedExchange(&g_mirrorHidden, 0);
    if (mh) LOGI("keys: %ld key presses sent along with a pad button kept from the game", mh);
    if (b || h) LOGI("keys: %ld game input reads blanked while the VR panel was open, %ld mod-hotkey presses kept from the game", b, h);
    char eb[400]; int n = 0; eb[0] = 0;
    for (int d = 1; d < 256 && n < 360; d++) {
        LONG c = g_keyEdges[d]; if (!c) continue; g_keyEdges[d] = 0;
        char nm[32] = {}; LONG lp = ((d & 0x7F) << 16) | ((d & 0x80) ? (1 << 24) : 0);
        if (!GetKeyNameTextA(lp, nm, sizeof nm)) _snprintf(nm, sizeof nm, "DIK %02X", d);
        n += _snprintf(eb + n, sizeof eb - n, "%s%s x%ld", n ? ", " : "", nm, c);
    }
    if (n) LOGI("keys: keys the game got pressed: %s", eb);
}

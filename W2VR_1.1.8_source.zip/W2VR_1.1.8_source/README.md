<div align="center">

# 🐺 The Witcher 2 VR (W2VR)

**VR for The Witcher 2: Assassins of Kings – Enhanced Edition on PC**

Stereo 3D · head and position tracking · first person · in-headset settings panel · any OpenXR headset

Works with the **Steam, GOG and retail** versions of the game.

![version](https://img.shields.io/badge/version-1.1.8-c0392b) ![game](https://img.shields.io/badge/game-The%20Witcher%202%20EE-222) ![xr](https://img.shields.io/badge/OpenXR-SteamVR%20%7C%20Pimax%20%7C%20Quest%20%7C%20VDXR%20%7C%20WMR-555)

</div>

---

## 📦 Install

1. Copy everything inside the `mod` folder into `The Witcher 2\bin` (next to `witcher2.exe`).
2. **Skip the launcher:** double-click `W2VR_SkipLauncher_Install.bat` there once. From now on, **Play** in Steam or GOG goes straight into the game and VR, with no launcher window. Hold **SHIFT** while pressing Play to get the original launcher (Configurator, DLC). `W2VR_SkipLauncher_Uninstall.bat` puts it back.
3. **Game settings (once):** hold **SHIFT** while pressing Play to open the original launcher, then open the **Configurator** and set:
   - **AllowDecals:** the mod sets **Medium** for you each start; on **High**, decals (blood and hit splatter) slow fights down in VR. To keep High, set `decals_max = high` in `w2vr_config.txt`.
   - **TextureMemoryBudget:** **VeryHighBudget**. The mod sets this for you too.
4. Start your VR software (Pimax Play, SteamVR, Virtual Desktop, Oculus …), then start the game. VR starts by itself.

**Game hangs on the medallion screen?** (only on CPUs with 32+ threads) Start the game with `W2VR_Launch.bat` instead. It launches straight into the game and VR, limited to 16 threads.

To uninstall, delete the copied files and the `W2VR` folder. Your original settings are kept in `Documents\Witcher 2\Config\User.ini.w2vr_backup`.

> Remove other head-tracking mods (`TheWitcher2-HeadTracking.asi`) while playing in VR. They move the same camera.

---

## 🎮 Controls

| Keyboard | Gamepad | Action |
|---|---|---|
| `Insert` | hold `L3 + R3` | Open / close the VR panel |
| `Home` | – | Recentre the view |
| `End` | – | First person on / off |
| `F7` | – | HUD: floating panel / fitted in view / full size |
| `F8` | – | Switch stereo / head-tracked mono / flat screen |
| `Delete` | – | Screenshot |

These are the defaults. **VR panel > Hotkeys** lets you change any of them and bind more functions (stereo method, decoupled pitch, position tracking, world scale up / down, HUD follow, menus on the flat screen, edge fill, foveated rendering, frame limit, headset smoothing, SSAO) to a keyboard key or mouse button 3 / 4 / 5 (with `Ctrl` / `Shift` / `Alt` if you like) and/or a controller button or combination (e.g. `Back + A`, `LT + RT + Y`). Select a function and press `A` / `Enter` or click it, then press the key or buttons. The ✕ in front of each function clears both its keyboard and controller binding: click it, or press Left to move onto it and then `A`. Pad `X` does the same, right-click clears a single cell, and `Y` or middle-click restores the default. "Open / close this panel" has no ✕: it can be changed but never cleared, and no other function can take its key or buttons, so the panel can always be opened. Bindings are saved to `w2vr_config.txt` immediately. A key or button you bind belongs to the mod, so the game stops seeing it. A key bound without modifiers still works while you hold Shift (walking) or Ctrl.

- **Mouse in the VR panel:** while the panel is open, a cursor in the panel's style follows your mouse. Point at a setting, click to change it, click a tab to open it, right-click to step back, scroll with the wheel, and close with the ✕ at the top right. The speed is set in Screen > This panel.

- **Any controller:** Xbox pads in any slot (the one you use is the one the game reads), and PlayStation (DualShock 4 / DualSense), Switch Pro and other pads without Steam Input or DS4Windows. Those use the Xbox layout (Cross = A, Square = X). Steam Input and DS4Windows still work as before.
- **Keyboard and mouse:** while the VR panel is open the game doesn't see your keys or mouse. The mod's keys only work while the game window is in front, and the game never sees them, so one key never does two things. If one of them is also bound in the game, `w2vr.log` tells you which; change the mod's key in `w2vr_config.txt`.
- **QTEs:** button-mash QTEs count every press the same at any frame rate. In the plain game they got much harder at high fps (at 144 fps a press was worth a fifth of a 30 fps press). No press is lost in Same-tick mode.

---

## 🥽 Your headset is set up automatically

Each time the game starts, the mod asks your headset for its field of view and recommended resolution, and sets the game's picture to match. The picture fills your view at the sharpness your VR software asks for, with no black bars and nothing cut off at the edges.

- Want it sharper? Raise **Display > Render resolution** in the VR panel (for example 1.2). Want more fps? Lower it.
- Changed your VR software's resolution? The mod follows it on the next start.

---

## 👀 Stereo methods

Pick one in **View > Stereo method**. You can switch while playing.

| Method | What it does |
|---|---|
| **Auto** | The default. Same-tick while your headset runs at full rate, Full stereo while headset smoothing is on. |
| **Full stereo** | Both eyes are drawn from every game tick. Perfect depth in motion, but the scene is drawn twice per tick, so it is heavier (most of all in combat). |
| **Same-tick AER** | One eye per frame (left, right, left …). Game time pauses for the second eye, so both eyes show the same moment. |

**Headset smoothing** (Pimax Smart Smoothing, SteamVR Motion Smoothing, ASW) is in **Engine > Headset smoothing**:

- **Follow the headset** (default): the frame cap always stays at your headset's full refresh rate, so smoothing never halves the game's fps. While your VR software fills in frames, Auto uses Full stereo; when there is time to spare, it tries Same-tick again.
- **Off**: the game ignores the headset's smoothing.

---

## ✨ What you get

- **Real 3D with head tracking.** Your head moves the game's own camera, so lighting, shadows and culling are right for each eye.
- **Sharp picture.** Full-resolution textures, 16× anisotropic filtering and the game's sharpen. Depth of field, motion blur, vignette and the game's soft anti-aliasing are off.
- **Correct textures and materials.** Metal, eyes and blood look as they should.
- **First person** (`End`), with adjustable position. It steps aside on its own for dialogues and cutscenes (they use their own cameras) and glides in and out instead of snapping.
- **No black edges:** edge fill stretches the picture's edge outward, smooth, a few degrees beyond your view. When fps dips and the headset re-projects an older frame, you see that instead of black.
- **Decoupled pitch:** the camera stays level and you look up and down with your head (less motion sickness).
- **HUD and menus on a floating panel** that follows your head, with adjustable size, distance and transparency.
- **Gamepad works** in VR, even when the game window isn't focused, with any controller (see Controls).
- **No combat slow-downs from the mod:** buffers the game rewrites every frame (blood, hit effects, damage numbers) never make the frame wait for the graphics card.
- **Smooth frame pacing:** a frame cap at your headset's refresh rate.
- **Menus, loading screens and videos** on a flat virtual screen.
- **Foveated rendering (experimental, off by default):** the outer part of each eye is shaded in 2×2 / 4×4 pixel blocks where the lens blurs anyway, so the GPU does less work there. Advanced page.

---

## 🧰 VR panel (`Insert` / `L3 + R3`)

Seven pages, each split into labelled sections. Use the controller, the keyboard or the mouse. `LB` / `RB` switch pages, `A` changes a setting, `Y` puts it back to its default, `B` closes. The setting's name in `w2vr_config.txt` is shown under its help text.

| Page | Sections |
|---|---|
| **View** | VR mode (VR mode, stereo method, recenter) · Comfort (world scale, position tracking, decoupled pitch) · Edge of the view (edge fill, smooth) · Performance (frame limit, headset smoothing, texture memory budget) |
| **Camera** | First person (on/off, off in cutscenes, transition time, distance, right, up, near clip) · Third-person camera (offsets, reset) |
| **HUD** | HUD and menus (mode, cycle, transparency) · Floating panel (distance, height, width, follow head) · Size and position |
| **Graphics** | Resolution · Effects (remove depth of field, motion blur, vignette, blur, SSAO, sharpen) · Textures (filtering, anisotropy) · Image clean-up |
| **Screen** | Flat screen (menus on the flat screen, distance, width) · This panel (size, opacity) · Screenshots |
| **Advanced** | Foveated rendering (preset, zone sizes, debug view) · Picture (resolution source, aspect, symmetric view, margins) · Head tracking · HUD · Game settings (User.ini tweaks, LOD bias, shadow bias) · Diagnostics (test tools, not saved) |
| **Hotkeys** | Keyboard and controller binding for each function: Panel and view · Camera · HUD · Picture and performance |

![VR panel - View page](docs/panel_view.png)

Settings are saved in `w2vr_config.txt` next to the game exe. Delete that file to get the defaults back.

---

## ❓ Problems?

- **No picture in the headset:** start your VR software before the game, and make sure it is the active OpenXR runtime.
- **Slow-downs or short freezes in fights:** decals are capped at Medium automatically (`decals_max`). Use **Stereo method > Auto**: Full stereo draws every frame twice.
- **Low fps or stutter:** use **View > Stereo method > Auto**, since Full stereo draws every frame twice. Or lower **Display > Render resolution** (0.9 helps a lot). In VR the frame limit always follows your headset's refresh rate; only Full stereo uses a lower limit.
- **Square sheathes the sword / QTEs fail:** a controller layout (Steam Input, DS4Windows, reWASD) was also sending the keyboard key **0**, which the game uses to put the sword away. The mod now spots keys that always come with a pad button and keeps them from the game. To fix it at the source, remove the key from the layout, or pick Steam's **Gamepad** layout. `w2vr.log` lists the buttons and keys the game received.
- **Virtual Desktop / Quest:** the mod takes the headset's refresh as reported (60 Hz is 60 Hz) and always renders at your headset's native resolution. Keep **Stereo method** on **Auto**; Full stereo draws every frame twice. If the reported refresh is wrong, set `headset_refresh` in `w2vr_config.txt`.
- **OpenXR layers** (OpenXR Toolkit and others) work as with any OpenXR game. The log lists the ones that are enabled.
- **Anything else:** the mod writes `w2vr.log` in `The Witcher 2\bin\W2VR`. Send it with your report. Every 10 seconds it records fps, frame times and what limits the frame rate.

---

## 🏗️ Building

The full source is in the separate **W2VR_source** download. Build with MinGW-w64: `scripts/build.sh`. Technical details and the full history are in `NOTES.md`.

---

## 🙏 Credits

| Who | What |
|---|---|
| **mark-mon** | Dragon Age II VR framework these mods are built on: XrBridge OpenXR host, vrkit VR panel, proxy loader |
| **Assassin's Creed Ezio Trilogy VR (AC2VR)** | The VR framework, stereo methods and same-tick AER this mod is ported from |
| **TefMeister** | witcher-2-vr research: SteamStub, camera axes, User.ini keys, render thread |
| **Heebo** and the free-camera table authors | Witcher 2 Cheat Engine camera tables |
| **The Witcher 2 6DOF head-tracking mod** | The camera hook site |
| **praydog / UEVR** | The synchronized-sequential AER idea behind same-tick |
| **crosire / ReShade** | The 2016 fix that showed why metal and eyes rendered in the wrong colours |
| **atom0s** | Steamless (the method used locally to study the game's code; not included) |
| **Tsuda Kageyu** | MinHook (BSD 2-Clause) |
| **Omar Cornut** | Dear ImGui (MIT) |
| **Sean Barrett** | stb_image_write (MIT / public domain) |
| **Khronos Group** | OpenXR (Apache 2.0) |

<sub>The Witcher is a trademark of CD PROJEKT S.A. This is an unofficial fan mod with no game files included. You need your own copy of the game.</sub>

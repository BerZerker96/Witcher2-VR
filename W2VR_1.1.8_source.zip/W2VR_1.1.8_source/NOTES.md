# W2VR technical notes and history

A VR mod for **The Witcher 2: Assassins of Kings – Enhanced Edition** (Steam, `witcher2.exe` linked 2013-05-09),
built on the AC2VR / Dragon Age II VR framework: XrBridge 64-bit OpenXR host, vrkit in-headset panel, D3D9Ex shared
textures, xinput1_3 proxy loader.

**Status: built and verified offline against the game's own code, not yet run in a headset.** See "What is verified"
below before you judge the first launch.



## 1.1.8: clear button on hotkeys; the panel binding can never be lost
- Hotkeys page: a ✕ in front of every function clears both its bindings (keyboard and controller) - click it, or Left
  to move onto it and A (Right goes back); gold when something is bound, dim when nothing is, crimson with a gold edge
  under the cursor / with the focus. Saved at once. Hints and help follow the focus.
- "Open / close this panel" has no ✕ and cannot be cleared (✕, pad X, Backspace while binding, right-click: nothing),
  and binding its key / buttons to another function is refused ("it opens this panel - pick another"). It can still be
  changed and reset. (vrkit Option::keepBound; check_hotsave 18.)
- Screenshot default key: Delete (as since 1.1.4 - unchanged).

## 1.1.7: regression audit - speculative 1.1.6 changes undone
The mod never showed pop-in, a frozen-tick movement problem or a stuck frame cap, so changes made in 1.1.6 only
because GOTGVR had those problems are taken back (GOTGVR's own first rule: never change a working thing on an
unproven guess). Everything is back to the shipped, tested behaviour except where a real failure was fixed.
- Undone: full stereo's frame camera is the union of both eyes again (identical to 1.1.5); the second eye's tick runs
  1e-5 s again (same_tick_held_step stays as an off-by-default option); the frame cap does not follow a lower refresh
  (w2pace.h and its test identical to 1.1.5).
- Hotkeys: a setting changed by a hotkey lasts for the session again, as End / F7 / F8 always did (1.1.4 - 1.1.6 saved
  it, so e.g. the game started in first person after pressing End once). Bindings are still saved at once.
- DirectInput controllers (1.1.5): "the one used last" now means a button pressed or a stick / trigger clearly moved,
  not an input level - a joystick axis or pedal resting at its end would have counted as constant use and taken the
  game's pad away from the gamepad. Joysticks / wheels are only used while no gamepad is open. Both triggers on one
  Z axis are only assumed when Z rests in the middle when the pad is opened (a throttle on Z would have held a trigger).
- HUD on the eye's axis (1.1.6, kept - nothing changes with centred eye views, the default): uses only the eye
  projection of the current frame (the shader fallback path left the previous frame's there).
- Kept from 1.1.6 (they fix real failures and change nothing otherwise): releases reach the game while the panel is
  open (a held key stayed down after closing); the %LOCALAPPDATA%\W2VR fallback only when the game folder is not
  writable; the symmetric eye view help text.
- Checks: check_padmap 25 (use = change, shared Z rest); all pass on Steam and GOG.

## 1.1.6: checked against GOTGVR's reported issues (0.6.17 - 0.6.29) - partly undone in 1.1.7
- Culling (GOTGVR Q.1, side pop-in with off-centre eye frustums): REDengine's camera builder writes the off-centre terms
  into the projection, but where the scene is culled could not be pinned down from the exe (no frustum planes in the
  builder or the frame info; the renderer reads no full view-projection element by element). So the safe rule from
  the GOTGVR guide is followed: whatever is culled with covers the eye. Default (symmetric_projection = true): each
  eye view is centred and covers the eye - nothing can pop in, whatever the culler does. Full stereo: the frame
  camera (culled with; each eye is redrawn with its exact projection) is now a symmetric frustum covering both eyes
  (it was their union, which can be off-centre vertically) - free, the picture and render size do not change. With
  symmetric_projection = false in same-tick / AER the eye's own off-centre view is used: the option's help says so.
- Render size after switching the symmetric view (Q.2): decided at launch from the setting - grown only while it is on,
  the headset's own size when off. No stale size.
- Held tick (Q.3, momentum lost with a zero time step): the second eye's tick had 1e-5 s - not zero, but 5 m/s x 1e-5 s
  = 0.05 mm rounds away in a float position 1 km from the origin (0.12 mm steps), the same "speed = distance / time
  = 0". Now 1/32 of its real time (~0.35 ms, not visible between the eyes), the rest banked as before; game time stays
  exact (check_sametick, Steam and GOG). same_tick_held_step.
- Frame cap stuck at an old higher refresh (Q.5): the full rate only ever went up. A lower rate that holds 20 s (within
  3 %) is taken now (90 -> 72 Hz during a session); half / a third (smoothing) never is; headset_refresh still wins.
- Config not created (Q.5): the game folder is tested for real writability (Windows' VirtualStore redirection counts as
  not writable - the 64-bit host and the player would not see the files); otherwise config, log, W2VR folder and
  screenshots go to %LOCALAPPDATA%\W2VR, said in the log, an existing config copied once. A failed config creation
  is logged.
- HUD doubled in AER (Q.5): the in-eye HUD (fitted / full) is placed on each eye's optical axis (p02, p12) instead of
  the picture's centre - the same for centred eye views (default), correct for off-centre ones.
- A key / button held when the panel opened stayed down in the game after it closed (Q.6): buffered reads dropped the
  release with every other event while the panel was open. Releases pass now.
- Not applicable / already right: panel and flat screen placement (the host recentres on the head; the Pimax logs show
  y offsets near 0), quad layers on Virtual Desktop (the VD logs show the flat screen and panel frames submitted, no
  report of them missing), launcher (the DLL only runs in witcher2.exe), alt-tab patch bytes (focus is handled by
  import patches; the two code patches are checked byte-exact in emulation), Delete in the panel / LB+Y both firing /
  generic DirectInput pads / pads blocked after closing / no XInput (handled in 1.1.4 - 1.1.5), foveated off by default.
- Checks: check_pacing (lowered refresh), check_sametick (held step) extended; all pass on Steam and GOG.

## 1.1.5: hotkeys, mouse and controllers audited
- Mouse: a held button counted as a new click on every game read (the state read reports "down" each time) - holding a
  click toggled a setting over and over. Press edges only now. The click that closed the panel reached the game (left
  click = attack): buttons held when the panel closes stay hidden from the game until released, as keys already did.
  A click / scroll while the cursor is hidden only shows it (it acted at the invisible position). Middle-click no longer
  resets a row while a binding is being set. A click anywhere on a value row steps it (left arrow: back).
- Mouse 3 / 4 / 5 can be bound (keyboard column; left / right click stay the game's attacks), read from the game's
  DirectInput mouse with Windows' state as the fallback, hidden from the game like bound keys.
- Keyboard: a binding without modifiers did not fire while Shift / Ctrl / Alt was held (Shift = walk) and the key then
  reached the game. Now the binding with exactly the held modifiers fires, else the plain one, on the key's press only
  (not when a modifier is pressed after it); hiding from the game follows the same rule.
- Panel binding: keys / single buttons the open panel navigates with (Enter, Backspace, Esc, arrows, Page Up / Down,
  Delete; A B X Y LB RB D-pad alone) are refused for it - held, they would close the panel at once. A one-trigger
  combination (LT + A) was handed to vrkit as plain A: vrkit's chord takes each trigger on its own now. An empty
  panel binding falls back to Insert and takes Insert off any other function.
- Settings changed by a hotkey are saved at once (they waited for the panel to close).
- Controllers (w2padmap.h): the D-pad of DirectInput pads gave no direction on the hat's diagonals (45, 135, 225, 315
  deg) - both directions now. Up to four DirectInput controllers are opened, gamepads before joysticks / wheels, and
  the one with the latest input is used (only the first one found was, even a flight stick). Generic pads with both
  triggers on one axis (Z, right stick on Rx / Ry) had no triggers (dinput_pad_triggers = z forces it).
  dinput_pad_buttons takes LT, RT too. The DirectInput thread starts for hotkeys as well. Button tables checked:
  DualShock 4 / DualSense, Switch Pro (by position), generic D-input mode - correct.
- Checks: check_bind 43, check_padmap 21 (new), 35 in all, Steam and GOG. Not yet run in the game.

## 1.1.4: Hotkeys page, mouse in the VR panel
- New last page, Hotkeys (w2hotkeys.cpp, w2bind.h): 18 functions, each with a keyboard binding (any key, Ctrl / Shift /
  Alt allowed; the old *_key names, so existing configs keep their keys) and a controller binding (*_pad: one button
  or a combination of up to four, triggers included, from any controller the mod reads - all XInput slots and
  DirectInput pads, in the Xbox layout). Only the functions that had a key keep it as the default (panel Insert /
  L3+R3, recenter Home, first person End, HUD F7, VR mode F8, screenshot Delete); the rest start empty.
  Binding: A / Enter / click, then the key or the buttons (a combination is taken when everything is let go; buttons
  held when binding starts are ignored); Esc cancels, Backspace clears, 8 s timeout. X / right-click clears, Y /
  middle-click restores the default. A binding already used by another function moves (the panel says from where).
  Saved the moment it is set. Controller bindings fire on the press that completes them (a larger combination wins);
  bound buttons are hidden from the game from completion until released (pad_exclusive_hotkeys); bound keys are hidden
  as before, with modifiers only while those are held. Hotkeys stay quiet while the panel is open or a binding is set.
  The panel binding goes to vrkit (held 0.3 s on the controller) and can never be left empty (falls back to Insert).
- Mouse in the panel: the game's own DirectInput mouse reads (already blanked for the game while the panel is open)
  drive a cursor - state and buffered reads, presses kept when press and release arrive in one read; the Windows cursor
  is the fallback when the game does not read the mouse. Hover selects, click changes (left arrow back, value / right
  arrow next, switches toggle, Run runs, hotkey cells bind), right-click steps back / clears a hotkey cell, wheel scrolls
  the list, middle-click resets, tabs and a close button are clickable. Cursor: a forged steel pointer with a gold rim
  and a crimson stud that glows over clickable things, sized to a line and a half of text. menu_mouse_speed.
- Checks: check_bind.cpp (35: names, parse / write, firing, hiding, capture), check_hotsave.cpp (13: both bindings
  written, moved bindings, reset / clear, in-place update). Panel previewed off-screen; not yet run in the game.

## 1.1.3: VR panel reorganised, first person in cutscenes, foveated rendering (experimental)
- Panel: six pages (View, Camera, HUD, Graphics, Screen, Advanced), each split into sections with headers; the rarely
  changed settings (picture geometry, head-tracking method, User.ini / shadow tweaks, diagnostics) moved to Advanced,
  which replaced Tests and sits last. One layout table in menu.cpp (vrkit `Options::Arrange`: config key or "@label" ->
  page + section); an entry that matches no option is logged. Checked offline: 75 entries, every option placed once.
- Witcher theme redrawn: Bahnschrift body text (close to the game's Bell Gothic), serif small caps for the title, tabs
  and section headers, cut-corner tab plates, On/Off labels next to the switches, "Run" plates for actions, a restart
  badge, help text in a smaller face that rolls when it is longer than three lines, the config key shown above it.
  An original emblem (crossed swords in a ring) sits next to the title - not the game's wolf medallion, which is CD
  Projekt's artwork. Previewed off-screen with stand-in fonts (docs/panel_*.png), not yet seen in a headset.
- Effect switches read "Remove depth of field: On" instead of "Depth of field off: On".
- First person (w2fp.h, tests/check_fp.cpp): dialogue and cutscene cameras are told apart by the game camera's field of
  view (learned in gameplay, 2.5 deg tolerance, 0.25 s to leave / 0.5 s to come back, learned again after the game's menu
  closes, and an off-value FOV held for 15 s is taken as the gameplay one). First person steps aside for them
  (first_person_cutscene_off) and every switch glides over first_person_blend seconds (smoothstep) - offsets and the
  near plane scale together, so there is no one-frame jump. Still the orbit camera moved to the pivot, not the head
  bone: looking down does not show Geralt's body.
- Foveated rendering (w2fov.cpp, tests/check_fov.cpp): D3D9 has no variable-rate shading, so the mask is a depth pass at
  the first G-buffer draw (near depth in every pixel but the first of each 2x2 / 4x4 block; colour writes off; skipped
  for an unknown depth convention, when VR is inactive, and after the first mask of an eye picture) and the fill runs
  at the eye copy. Mask and fill share one zone function and one centre per frame; the check runs 80 layouts (493 M
  pixels) and finds no fill from an unshaded pixel. Balanced skips shading in about 64 % of a 2448x2448 eye's pixels.
  Full-screen lighting still runs per pixel, and screen-space effects next to masked pixels (SSAO, bloom, eye
  adaptation) can shift - hence experimental and off by default. Not run in a headset.
- 29 offline checks pass on Steam and GOG.

## 1.1.2: freezes in fights and when areas load (GOG / Virtual Desktop / Quest 2 log)
- "one-time reads" took 412, 378, 299, 176, 146 ms in single 10 s windows: the copy of a mesh buffer the game reads
  (decals are cut out of the meshes they land on) was made at the first read-only lock by reading video memory back,
  waiting for the GPU when the mesh was in flight - a freeze each time decals hit new meshes. Now the system-memory
  copy is kept from the buffer's first write (as the real managed pool does); reads never touch video memory. Copy
  budget 256 -> 512 MB (the exe is large-address aware). Overlapping write locks upload the union of their ranges.
- A one-time 0.5.2 step ("restore your original quality from User.ini.w2vr_backup") put AllowDecals 1.0 back over the
  user's Medium on that GOG install. Decals left that list; decals_max = medium (default) caps AllowDecals at 0.5 each
  start, high keeps it, off = 0. The 'reduced quality' warning no longer asks for High decals.
- The 400 - 620 ms GPU spikes lined up with 700 - 1100 managed-texture uploads per 10 s (streaming): every level write
  re-uploaded the whole texture. After a texture's first whole upload only the written levels go up (UpdateSurface per
  level); managed_texture_level_uploads = false restores the old way.
- The same user ran Full stereo by hand at 3264x3264 (GPU 12-14 ms of a 13.9 ms frame): Auto (same-tick) halves that.
- Not tested in a game run; the 27 offline checks pass on Steam and GOG.

## 1.1.0 / 1.1.1: keys sent with pad buttons, Virtual Desktop pacing
- The 1.0.9 log: each X/Square press reached the game with one press of the keyboard key 0 (43 Square -> 86 "0"
  edges, state + buffered paths). The mod never sends keys (its only SendInput is one F24 at VR start), so a controller
  tool layout sent it. 0 = sheathe the sword: fast attacks sheathed it, and the mash QTEs (MashFull / MashSave) ended
  after 2 updates every time ("qte: 2 updates"). The mash input handler itself ignores other keys. Now keys that come
  with the same pad button (>= 2 times, >= 80 % of their presses) are learned and hidden from the game when they come
  with it (src/w2keys.cpp MirrorHide); typed alone they still work. keyboard_pad_mirror_keys presets them.
- Pacing: a reported rate <= 60 Hz was always taken as half of the real one (Pimax forced smoothing). A Virtual
  Desktop / Quest headset really set to 60 Hz then got a 120 cap and permanent full stereo. Now only for Pimax runtimes;
  others take the rate as reported (smoothing is still seen as a drop from a higher rate). headset_refresh overrides.
  tests/check_pacing.cpp cases 7-8.
- (1.1.1) render_scale_auto removed again: the render size always follows the headset's native size (x render_scale).
- (1.1.1) the key-learning rule moved to src/w2mirror.h, tested in tests/check_mirror.cpp.
- The GOG / VDXR / Quest 2 log: full stereo at 2688x2688, 72 Hz, GPU 10.4-15.3 ms per frame (8000+ draws), 62-71 fps:
  full stereo set by hand in that config; Auto (same-tick) halves the drawing.

## 1.0.9: Steam Input bypass, frame limit in VR, input diagnostics
- The 1.0.8 log showed "the game read XInput 0 times" for a whole session (every earlier log: hundreds per 10 s). The
  Steam overlay / Steam Input patches this DLL's XInputGetState export and answers the game itself, so the 1.0.8
  route (the export's jump target) was never reached: no latch, slot choice or panel blocking for the pad. 1.0.7 and
  earlier worked because vrkit hooked the export at device creation, in front of Steam's patch. Now the mod hooks its
  own XInputGetState / SetState exports at device creation (MinHook over whatever is there) and reads the pad through
  the trampoline, so Steam's controller is still the source. Not run with Steam Input here.
- Frame limit in VR stereo: same-tick always runs at the headset refresh (45 or off gave uneven eyes: the log showed
  "ring busy" 120-220 per 10 s with the limit off at 88-90 fps on a 72 Hz headset); full stereo keeps a lower cap, never
  a higher one / off.
- The 1.0.8 "mod-hotkey presses kept from the game" counter counted the 7 hotkeys on every read (thousands per 10 s);
  now only real presses.
- Diagnostics: the buttons the game got pressed (per 10 s), the keys the game got pressed, and the IK_Pad_* bindings
  from Input_*.ini / User.ini at start - to find what a button really sends (Steam Input layouts can map Square to
  anything).
- The two slow periods in the user's log were settings, not the mod: full stereo at 4352x2668 (GPU 18.9 ms per frame
  for a 13.9 ms period: 49 fps) and the frame limit off (above).

## 1.0.8: pacing, controllers, keyboard, QTEs
- Frame pacing (src/w2pace.h): the frame cap is never below the headset's full refresh. A reported rate of 60 Hz or
  less is treated as half rate (smoothing); a higher rate needs 30 consistent reports. Auto uses full stereo while the
  runtime is reduced and same tick at full rate, with a 10 s trial when full stereo has time to spare (at most once a
  minute, the wait doubling up to 10 min after a failed trial). The game never waits for the host: a busy slot is
  skipped. headset_smoothing: auto / off. Model test: tests/check_pacing.cpp.
- Texture budget on the View page (restart to apply), written to User.ini exactly.
- Mash QTEs (src/w2qte.cpp): CQTEMash::Update caps each tick's gain at m_maxSpeed * dt, so a press counts less the
  higher the frame rate (the game's own code, emulated: 1 s of mashing = 0.80 at 30-60 fps, 0.49 at 90, 0.23 at 144,
  0.06 in same tick at 144). The cap now uses at least 1 / qte_reference_fps (30): 0.80 at every rate. Decay and
  timers unchanged. CQTEMashSmooth and single-press QTEs do not depend on the frame rate. tests/check_qte.py.
- Same-tick input latch (src/w2latch.h): the input poll runs inside the tick (after the loop's dt hook), so on the
  frozen second-eye tick (dt = 1e-5 s, clock held) presses earned nothing. Pad, keyboard and mouse now only change on
  real ticks; presses during a frozen tick are delivered with the next real one (short taps included); buffered
  DirectInput events stay queued; mouse movement adds up. tests/check_input.cpp.
- Controllers (src/w2pads.cpp): the game reads XInput pad 0 only. Now the pad with the latest input in any slot (empty
  slots scanned once a second, they are slow to query); vibration goes to it. Non-XInput controllers (DualShock 4,
  DualSense, Switch Pro, generic DirectInput pads) are read in a background thread and mapped to the Xbox layout while
  no XInput pad is connected, so Steam Input / DS4Windows mirrors are never doubled. The VR panel reads the same pad
  (vrkit no longer hooks XInput by module name, which was ambiguous with the proxy also called xinput1_3.dll).
- Keyboard (src/w2keys.cpp): with the VR panel open the game gets no keyboard / mouse input; keys still held when it
  closes stay hidden until released; the mod's hotkeys only act while the game is in front and are hidden from the
  game (keyboard_exclusive_hotkeys); clashes with Input_*.ini / User.ini bindings are logged. vr_mode_key / diag_key
  configurable.
- Not tested in a headset or with real controllers: the DirectInput layouts (PlayStation is the standard HID layout;
  Nintendo and generic pads vary - dinput_pad_buttons / _right_stick / _triggers override them).

## 1.0.7: Steam / GOG audit
- Every hook, patch and engine address was checked on both builds (Steam exe decrypted locally, GOG exe as shipped):
  all 23 byte patterns the mod searches for occur exactly once in each; no fixed address is left in the code.
- The GOG exe is built with ASLR (it can load at another base); everything is taken from the running image, so that
  is handled.
- The camera hooks now go in at device creation for every build, as they always did on Steam (before, an unpacked
  exe got them at DLL load - a path no game run had tested).
- Emulator tests on both builds (`tests/run_tests.sh` with `W2_UNPACKED` and `W2_GOG`): the compiled search finds
  every target with the right convention; the GOG builder / screen-to-world give bit-identical results to Steam's;
  the compiled camera hook, LOD stub, full stereo, constructor thunks (EDI and ECX), letterbox, post-process mask
  (DOF, motion blur, vignette, blur, SSAO, sharpen), dither callbacks, many-core fix and same-tick stubs all pass.

## 1.0.6: any build of witcher2.exe (Steam, GOG, retail)
- The GOG exe is a 2023 rebuild: same game code, but other addresses, other register use and, for three functions,
  other calling conventions. Seven Steam byte patterns did not match it, and VR fell back to no head tracking.
- Every target is now found from a part all builds share, and its calling convention is read from its own first
  instructions (`src/w2scan.h`):
  - render camera builder: right after the detail-scale fragment (`movss [esi+270h], xmm1; ret`). Steam takes the
    camera on the stack (`ret 4`); GOG takes it in EAX (plain `ret`). Two hook stubs; every call to the original goes
    through `CallBuild`.
  - screen-to-world: the call that follows the frame's own builder call. Steam stdcall; GOG takes the frame info in
    ESI. `CallInfo`.
  - frame info constructor: from `mov [this+2A0h], eax; mov byte [this+2A4h], 1`. `this` is EDI (Steam) or ECX
    (GOG, which also has two extra arguments). Two thunks.
  - renderer frame function: the shared prologue plus its present test (stdcall, 3 arguments in both).
  - engine clock: the target of the main loop's own time read (no separate pattern).
  - pause state: the game-object global next to the flag `IsPaused` tests.
  - HUD aspect table: found by its 13 values (Steam exe+A46DB0, GOG exe+AE9B4C).
  - settings object and texture statistics: from the texture-budget check's own calls.
- An unknown build is searched at most four times, never once per frame; anything not found is logged and its feature
  stays off.
- Tests: `check_locate.py` runs the compiled search on each exe; `check_gog_builder.py` / `check_gog_info.py` show the
  GOG functions give the same results as Steam's for the same input (same structure layout);
  `check_dll_hook_gog.py` runs the compiled hook against the GOG builder.

## What it does

- **True engine stereo.** Each eye is rendered by REDengine's own render camera. The mod hooks the camera matrix
  builder (`CRenderCamera`, `witcher2.exe+0x7067F5`) and gives it, every frame, the eye position, the head rotation
  and **that eye's exact asymmetric headset projection** (REDengine has off-centre projection terms at `+0x280/+0x284`).
  Culling, shadow cascades, deferred lighting, fog and 3D markers are all computed by the engine for the eye actually
  drawn. No shader re-projection, so nothing at the edges gets culled and no edge fill is needed.
- **Full stereo (new default, `stereo_method = full`).** Both eyes are rendered from **every single game tick**: the
  game simulates once, the renderer draws the frame twice (left eye, then right eye). No doubling in motion, no held
  clock, and the game's own update cost is paid once per eye pair. Built the way the engine's own tiled "uber
  screenshot" re-renders a frame. See "Full stereo" below. If it can't engage, it falls back to same-tick by itself.
- **Depth of field forced off in gameplay and cutscenes**, plus motion blur and vignette (renderer patches, live
  toggles). See "Depth of field" below.
- **Same-tick AER, native** (`stereo_method = same_tick`). One eye per game frame, and for the second eye of each pair REDengine's time stands
  still, so both eyes show the same moment (no doubled edges in motion). Done in the engine's own main loop and
  clock, with game time conserved exactly. See "Same tick" below.
- **First person** (End, or Camera tab): the view moves to Geralt's head, the pivot of the game's orbit camera, in
  the same place Enhanced Camera's first-person template puts it. The engine's near plane clips the inside of his head.
- Per-eye tagging, so captures stay correct with Witcher 2's render thread one frame behind the game thread.
- **Detail kept**: the engine's screen-size/LOD scale (`+0x270`) stays at the game's own FOV, so the wide VR view
  doesn't lower distant detail.
- **Decoupled pitch** (on by default): the game camera stays level and you look up/down with your head.
- **HUD and menus on a floating panel** (new default): the game's Scaleform HUD and menus are redirected into their
  own render target and shown as a head-locked panel at full resolution, so text stays sharp instead of being shrunk
  inside the eye image. The panel is exactly as wide as the flat game's view at its distance, so 3D-anchored markers
  line up. F7 cycles panel → fitted into the view → full size.
- **No letterbox**: the game forces a 16:9 picture with black bars at other aspects. On the near-square VR frame
  that would have rendered only the middle 55% (2064×1162 of 2064×2096); patched off, so the picture fills the frame.
- **Always windowed, at the real VR resolution, with no screen-size limit** (`window_scale = 1`, default): the
  window's client area is exactly the headset's per-eye size and shape (e.g. 2064×2096 on a 1080p monitor), not
  the monitor's. Windows normally caps a window at the screen size (`WM_GETMINMAXINFO`) from inside
  `CreateWindowExW`, and the game then shrinks its viewport to the clamped client rect (witcher2.exe 0x9D22F8:
  `GetClientRect` → viewport resize). The mod subclasses the game's window at creation time (a `WH_CBT` hook, before
  the first `WM_GETMINMAXINFO`), lifts the cap, creates the window at the full size (centred if it fits, else at the
  monitor's top-left with the rest past the screen edge), and reports the full resolution to the game through
  `GetClientRect` / `WM_SIZE` from the first moment. The process is DPI-aware so Windows scaling can't stretch it.
  `window_scale = auto` shrinks the window to fit the monitor instead (the headset still gets the full frame).
  **Mouse:** a window larger than the monitor can't be fully reached by the cursor, so the part of the window that is
  on screen is mapped to the whole game picture (`mouse_fit_screen`); every menu button stays clickable.
- **User.ini set up automatically** (backup kept): `Fullscreen=false`, VSync off, `[Viewport] Width/Height` and
  `WindowedWidth/WindowedHeight` = the headset resolution (multiple of 4, up to `render_max_side = 8192`), and depth
  of field, cutscene DOF, motion blur and vignette off. D3D is also forced windowed in case the game ignores it.
- **Native NVIDIA 3D Vision kept off** (the game has it built in; on a 3D Vision driver it would stack on the VR eyes).
- Witcher-themed in-headset panel: dark leather-black, bronze/gold frame, crimson title, gold page names, red
  switches (`docs/panel_camera.png`).
- Flat virtual screen for menus, loading screens and videos; screenshots; frame limiter.

## 0.9.9: rainbow metal / eyes / blood - the game no longer sees D3D9Ex
- The wrong colours on swords, eyes, the medallion, helmets and blood are the exact values of the game's axis-lookup
  cube (built at exe 0x53F470: 0 / 0.5 / 1 per cube face = teal, purple, green, blue, pink), written into the colour buffer.
- ReShade caused the same bug in 2016: 3.0.4 told the game its device was a D3D9Ex device, users saw green / red / pink
  tint on swords, helmets, armour metal and puddles; 3.0.6 stopped saying so and it was gone. The mod's device really is
  9Ex (needed for the headset), so the game always heard "yes". Now the game's request for IDirect3DDevice9Ex /
  IDirect3DSwapChain9Ex is answered "not supported"; only the mod uses 9Ex. hide_d3d9ex = false turns this off.
- The log says who asked: "d3d9: IDirect3DDevice9Ex asked for by ...".

## 0.9.8: render scale 1.00, texture budget test, shader check
- render_scale is 1.00 again (default, and existing configs changed once).
- Tests > Texture memory budget (live): Game's value / 1536 / 2048 / 3072 MB. The game's texture streamer only loads a
  texture's sharp mips while used texture memory + the new texture fits TextureMemoryBudget; otherwise the texture stays
  on its low mip or a tiny placeholder - flat colour faces. The log now prints the budget and the streamer's in-use figure.
- The log counts pixel shaders the device rejected (a rejected material shader would also draw flat wrong colours).
- Normal repair is off by default: with the exact texture emulation the normals arrive whole, so it no longer does anything.
- The vanilla comparison run (diag_vanilla) falls back to a plain D3D9 device if the Ex device is refused.

## 0.9.7: Tests page in the VR panel (texture diagnosis in game)

VR panel (Insert / L3+R3) > **Tests** - live, back to normal at every start:
- **Show layer**: Normal picture / G-buffer colour / G-buffer specular / G-buffer normals, shown in the headset in
  place of the picture. Green / blue patches already in "colour" = textures or decals; colour right but the picture
  wrong = lighting.
- **Hide decals (blended layers)**: skips every draw that blends into the G-buffer (blood, dirt, terrain layers).
- **Normal repair**: the 0.9.0 fill-in of empty normals, on / off.
- **Re-upload all textures now**: copies every game texture to the graphics card again (one shot).
Every change is written to w2vr.log (`tests:` lines).

## 0.9.6: no more pure device

- 0.9.4 log: every texture the G-buffer reads (DXT1 / DXT5 normal, colour and height maps, the 16 x 16 dither, the
  64 px cube) now goes through the exact managed-pool emulation, and the normals are whole. Still wrong: green blood
  decals and a lavender sword pommel (normal-map colours) in the G-buffer COLOUR target. With the texture data correct,
  the suspect is draw state: the game creates a PURE device (flags 0x56 include D3DCREATE_PUREDEVICE), on which Get*
  calls and state-block capture are not supported - and every pass the mod adds inside the frame saves and restores
  the game's state through those. The flag is now removed (`strip_pure_device`), so the device reports and restores
  its state properly. Costs a little CPU time per draw call.

## 0.9.5: autogen / volume textures emulated too; HUD / UI transparency

- 0.9.4 result (stages): the G-buffer normals are whole again (0 % empty, was 40 - 70 %) - the height-map and grain
  problem was the managed-pool emulation. Still wrong: a few materials show their NORMAL map as colour (Geralt's sword
  pommel lavender with green / blue rims, blood decals green). Those textures did not go through the exact path:
  textures with automatically generated mip levels were excluded, and volume textures were still dynamic. Both now get
  the exact managed-pool emulation too. If anything still shows normal-map colours, the `gbuffer:` lines in w2vr.log
  (written with the stage dump) list the formats of every texture those draws read.
- VR panel > HUD > **HUD / UI transparency** (`hud_transparency`, default 0.60 = 60 % see-through, live). Applies to
  the game's HUD and menus in the headset; the VR panel itself stays solid.

## 0.9.4: exact managed-pool emulation for textures; G-buffer census; vanilla comparison run

From the 0.9.3 stages: the cube-texture fix did not change the normals (39 % / 68 % empty), and there is only one
managed cube (64 px). The surface normals come from the game's normal / height maps; those are 2D textures the game
creates in the managed pool, which D3D9Ex does not have.
- `managed_mode = exact` (new default): every managed 2D texture is a static video-memory texture plus a system-memory
  copy. All write paths go to the copy - texture LockRect, the level surfaces D3DX writes through (GetSurfaceLevel ->
  surface unlock), AddDirtyRect - and the whole copy is uploaded (UpdateTexture) before the texture is next drawn with
  or preloaded, exactly what the managed pool does. Log: `d3d9: managed textures (exact managed-pool emulation)`.
- `vr_texture_budget` 1024 (2048 set by earlier versions is lowered): with the copies the 32-bit game holds every
  texture twice, like the real managed pool.
- Stage dump: a census of the textures the G-buffer draws read (`gbuffer:` lines: sampler, format, size, levels,
  how the mod holds them) - names the normal / height map formats.
- `diag_vanilla = true`: a run of the untouched game (no VR, no mod changes) whose stages F10 saves - the reference
  that shows whether the normals are already empty without the mod.

## 0.9.3: cube textures (the likely cause of the empty normals), de-dither off, sharpen on

- The second stage recording ruled the mod's texture filtering out (normals empty with and without it).
- New suspect, fixed: managed CUBE textures. Direct3D 9Ex has no managed pool, and since the first version the mod
  turned them into dynamic textures that are locked face by face - a dynamic texture may lose what was written before
  on each lock. The game fills a lookup cube with D3DXFillCubeTexture at start-up (exe 0x53E99E / 0x53EEF3); with holes
  in it, vectors looked up through it come back as zero. Cubes are now ordinary video-memory textures with a
  system-memory copy that takes all writes and is uploaded whole (`managed_cube_copy`). Log: `d3d9: managed cube
  texture ...` and `managed cube textures N: locks, uploads`.
- `normal_repair` stays on behind it as a safety net; the stage dump shows the normals before the repair.
- De-dither filter off (`dedither = 0`), the game's sharpen on (`disable_sharpen = false`, AllowSharpen on). Existing
  config files are changed once.
- Includes 0.9.2: VR panel > Engine > Headset smoothing (Always / Only when fps drops / Off).

## 0.9.2: Headset smoothing - Always / Only when fps drops / Off (live)

VR panel > Engine > Headset smoothing (`headset_smoothing`):
- **Always** (default): the game is paced at half the headset's rate and draws both eyes from each tick, so Pimax
  Smart Smoothing runs all the time and never drops in or out.
- **Only when fps drops**: one eye per frame at the full rate while the game holds it; half rate + both eyes only
  while the headset has dropped.
- **Off**: the game never follows the headset.
Smart Smoothing must be on in Pimax Play. If the headset stays at its full rate for 15 s in Always, the mod switches to
"Only when fps drops" for that session.

## 0.9.1: render scale 0.90, the game never follows the headset to half rate

- `render_scale = 0.90` (19 % fewer pixels: about 3916 x 2400 per eye). An existing config with 1.00 is changed once.
- `smoothing_follow = false`: the mod no longer paces the game at half rate or switches to both-eyes-per-frame when the
  headset drops to half rate - the game keeps rendering one eye per frame at its own full rate.
- The mod cannot stop Pimax Smart Smoothing itself: it is a setting of the Pimax runtime, which decides on its own to
  halve the display rate when frames are late. To guarantee it never halves, turn Smart Smoothing off in Pimax Play.

## 0.9.0: the specks found (broken G-buffer normals) and repaired; HUD aspect; steady smoothing

From the stage dump of 0.8.0 (`W2VR\stages`):
- The colour target of the G-buffer is clean - textures are fine. The NORMAL target (MRT 2, view-space normal) holds a
  zero vector in 61 % of all pixels and shortened vectors in most others, on every material. The first lighting pass
  is black exactly there (98 % overlap) and the specks stay to the final picture. The pattern follows texture detail
  (mortar lines, bumps), so it crawls as the view moves. Why the game's shaders write those normals under the mod is
  not known yet (the shaders are not in the exe); `run2_*` of the stage dump now records a frame with the game's own
  texture filtering to rule the mod's filtering in or out.
- **normal_repair** (new): when the game leaves the G-buffer, the normals are renormalised and empty pixels take the
  direction of their neighbours of the same material (three rounds, 4 pixels each). Simulated on the dumped frame:
  61 % empty before, under 1 % after. Fine bump detail inside the filled patches is lost.
- **HUD cut off**: the 0.7.0 aspect patch never ran ("aspect table has another layout" - a wrong end-of-table check).
  The HUD picture you sent is cut at the top exactly as a 4:3 layout (1280 x 960 stage) scaled to the frame's width
  would be. Fixed: the table gets the frame's aspect.
- **Smoothing**: the game reached 57 - 65 fps where the headset needs 72, so Pimax Smart Smoothing dropped it to 36 Hz;
  the mod then tried the full rate again whenever 40 % of the period was spare, failed, and fell back - the dips.
  Now it only tries with 58 % spare and at most every two minutes: steady 36 fps + smoothing. For a steady 72 the
  frame must get cheaper: `render_scale = 0.85` (28 % fewer pixels of the 4352 x 2668 picture) is the first thing to try.

## 0.8.0: the camera rebuilt around its origin

Traced in the exe (all addresses for witcher2.exe 2013-05-09):
- Everything that needs the camera in a game tick constructs a `CRenderFrameInfo` from the viewport (ctor 0xAA43A0,
  six callers: the renderer's frame, the HUD / 3D markers 0x9B667D, the viewport's frame generation 0xAAEF03,
  0x9D1D61, 0xAAAAA5, 0xAAAE36). The ctor's camera step (0xAA426E) calls the viewport hook
  (`hook->vtbl[0x24](viewport, &info.camera)`), which runs the active camera component's `CalcCamera` (0xA84EDB)
  -> `CRenderCamera::Set` (0xB071EE) -> the matrix builder (0xB067F5), then caches screen-to-world (0xAA4167).
  A second step (0xAA428E) may change fov / far plane from the environment and rebuilds the same camera.
- The matrix builder W2VR hooks is the right place to change a camera (all of the above end in it). What was wrong:
  the mod chose ONE camera object by votes (address, call site, projection match) and head-tracked only that one, and
  it took the newest head pose at every build. The other consumers of the same tick kept the game's forward-looking
  camera, and two builds in one tick could use two head poses.
- Now the constructor is hooked: a camera at `info + 0x10` of a frame info constructed this tick IS the viewport's
  camera (no votes), every one of them gets the head pose, and the pose is latched once per game tick.
  Log: `camera: origin hooked ...` and `camera origin: N frame infos constructed, M viewport cameras head-tracked`.
  `camera_origin = false` goes back to the old selection.

## 0.7.0: traced in the exe - pad, HUD; a stage-by-stage frame dump for the textures

- **Pad (traced, exe 0x9D2817):** the game's input poll reads keyboard and mouse through DirectInput (exclusive,
  foreground) and the pad (XInputGetState, user 0) only after them. When a DirectInput read fails because the game
  window is not the foreground window, the poll re-acquires and returns (0x9D2B47 -> 0x9D2D81) - the pad is skipped.
  In a headset the window is often not in front, and the mod keeps the game running unfocused, so the game ran but
  ignored the pad. Now a lost DirectInput device reports "nothing pressed" (`pad_without_focus`), the window is
  brought to the front once when VR starts (`window_to_front`), and the log has an `input:` line every 10 s (window
  in front or not, the game's input mode, lost reads).
- **HUD cut off (traced, exe 0xAAEB8E / 0xAAED18):** the viewport lays the HUD out on a 1280 x (1280 / aspect) stage
  with an aspect taken from a table (16:9, 4:3, 5:4, 16:10, 5:3 + multi-monitor), not from the frame. With the
  letterbox removed the frame is about 1.63 but the HUD was still a 16:9 stage scaled to the frame's height - wider
  than the frame. The table now holds the frame's real aspect (`hud_native_aspect`).
- **Textures:** the shaders are not in the exe (they are compiled from the game's data), so the speck's origin cannot
  be read from it. Instead the mod records one frame stage by stage: `bin\W2VR\stages\*.png` (automatically once,
  about 20 s into gameplay, and on F10) - colour | alpha of every full-size render target as the game leaves it.
  They show whether the specks are already in the G-buffer colour (texture data), appear in the lighting, or in
  post-processing.

## 0.6.2: blood colour, User.ini repaired again, full-resolution textures

From the 0.6.1 log: User.ini had been rewritten (by the Configurator / the launcher's options) to TextureDownscale=2,
MaxTextureSize=1, MaxCube/SpotShadowSize=1 and 720x576 - that is why the 0.6.1 screenshot is smeared.
- Sizes below 256 (MaxTextureSize, MaxAtlasTextureSize, Max*ShadowSize) are repaired at every start (was: only 0).
- `vr_texture_quality = max`: TextureDownscale / Atlas / Detail downscale set to 0 at every start (`keep` = leave them).
- `shadow_dither_uniform = false` (was `remove_shadow_dither = true` since 0.5.0): blood has been green, purple or
  teal ever since that patch went in, so the game reads that texture for more than the shadow filter. Back to the
  game's own texture.

## 0.6.1: textures written once in video memory, a bigger texture budget, steady pacing under smart smoothing

What the 0.6.0 log showed: the game reads the pad fine (hundreds of reads with input, nothing blanked outside the VR
menu) - so the pad is ignored by the game's own setting: Options > Controls > Gamepad. SetLOD is never used. The
specks in the screenshot sit in lit areas and the dead soldier's clothes show pure red / green / blue patches:
textures with wrong contents, not a lighting dither.
- **managed_direct_lock**: textures the game creates in the managed pool now exist once, as dynamic video-memory
  textures that the game and D3DX lock and write directly. No second copy that can go out of step, and the
  32-bit game no longer carries a system-memory duplicate of every texture.
- **vr_texture_budget = 2048**: TextureMemoryBudget is raised to at least 2048 MB (only raised; 0 = off). The headset
  frame is 4352 x 2668, and its render targets eat the room the game's 600 MB budget assumed; the reported symptom of
  a too-small budget on modern NVIDIA cards is broken / black textures.
- **Smart smoothing**: while the headset runs its frame smoothing (Pimax Smart Smoothing, SteamVR Motion Smoothing,
  ASW - the runtime asks for half-rate frames), the game is paced at exactly that rate (`smoothing_lock`), so the
  synthesised frames come from evenly spaced pairs; it tries the full rate for 10 s whenever the game has 40 % of the
  period to spare. Changing a VR-panel setting no longer flips the stereo method to same-tick and back.
- **Screenshot (Delete)** now also saves the HUD panel's picture (`..._hud.png`), to see what the HUD shows.

## 0.6.0: texture uploads fixed (one level at a time), direct start file

From reading TefMeister/witcher-2-vr (a Witcher 2 VR research project: engine notes, no stereo yet) and checking it
against W2VR's own code:
- **Likely cause of garbage texels, fixed.** That project's import list shows the game loads textures with
  `D3DXCreateTextureFromFileInMemory`. D3DX writes each mip level through the level's *surface*, straight into the
  video-memory texture W2VR creates in place of the managed one; the game then streams other levels through the
  *texture's* LockRect. W2VR answered every such unlock by copying the whole system-memory copy (UpdateTexture),
  which does not hold the D3DX-written levels: they were overwritten with empty / stale data. Now only the unlocked
  level is copied (UpdateSurface); read-only locks copy nothing. Log: `d3d9: managed texture uploads: N single-level
  copies, M whole-texture fallbacks` (M should be 0).
- `steam_appid.txt` (20920) next to witcher2.exe: the exe starts the game directly (no launcher, and no Steam
  first-run prompt, which makes the game fail with "Direct3D 9 device initialization error" while it is open).
  Steam must be running.
- Note from the same research: the game's debug channel listens on TCP ports 47000/47001 on all network interfaces
  while it runs (any command can be sent to it). Keep the PC behind a firewall / router.

## 0.5.9: speckled textures (texture streaming), the de-dither filter, HUD fit, pad diagnostics

- **The speckle/grain is not the screen-door dither.** A pixel analysis of the 0.5.8 screenshot finds no correlation
  with the game's 16x16 Bayer pattern at any offset; the specks are fixed to the textures themselves. Likely cause, now
  fixed: REDengine streams textures and limits each one's sharpest usable mip level with `SetLOD`. That call only works
  on D3DPOOL_MANAGED textures, and the D3D9Ex device the mod needs (to share the picture with the headset) has none, so
  the GPU drew mip levels that were not loaded yet (zeros or a recycled texture's pixels). W2VR now remembers the level
  per texture and applies it as D3DSAMP_MAXMIPLEVEL when the texture is bound (`managed_lod_emulation = true`).
  The log line `d3d9: SetLOD (texture streaming) emulated: N calls ...` confirms the game uses it.
- The de-dither filter never ran (its precompiled shaders were rejected by Direct3D: "shaders could not be created").
  It is now compiled at start-up with the system's d3dcompiler_47.dll.
- HUD panel: kept inside 70 % of the headset's own view (`hud_panel_fit`), so its edges are not out at the lens edge.
- Controller: a `pad:` line every 10 s shows how often the game reads the pad, whether input arrives and whether the
  VR menu is blanking it.

## 0.5.8: Play goes straight into the game and VR

- `W2VR_SkipLauncher_Install.bat` (run once from `bin`) replaces the Witcher 2 launcher with a 17 KB stand-in
  (`W2VR_SkipLauncher.exe`, source in `source/launcher`). It starts `bin\witcher2.exe` at once, inheriting Steam's
  environment, as the real launcher does, so the Steam version's DRM is satisfied. The original is kept as `Launcher_original.exe`:
  hold SHIFT while pressing Play to get it. Undo with `W2VR_SkipLauncher_Uninstall.bat` or Steam's "verify files".
- The headset is already asked at start-up (0.5.7), so the game window opens at the headset's resolution and VR
  starts with the game.

## 0.5.7: any OpenXR headset - resolution, aspect and FOV detected at every start

- Before the game reads User.ini, W2VR starts XrBridgeHost and asks the headset for its per-eye resolution and
  per-eye field of view (any OpenXR runtime: Pimax, SteamVR / Index / Vive, Meta Link / Virtual Desktop, WMR, Varjo...).
  The game's resolution and aspect ratio are set from that, and with symmetric_projection the centred view is made as
  much larger as that headset's FOV asymmetry needs, so the pixel density stays the same. A different headset is
  picked up on its first launch; before, the first launch used the previous headset's size.
- The package no longer ships a Pimax Dream Air headset_size.txt (it's created on the first run).
- Very wide or asymmetric eyes (Pimax wide modes) were capped at a 2x centred-view ratio; the cap is now 3x.
- In play the eye FOV, pose (canted displays included) and projection still come from the headset every frame.
- headset_detect = true / headset_detect_ms = 0 (5 s, 15 s on the first run). With the headset off, the last values are
  used. The log shows "xr: headset detected: WxH per eye, FOV ..." with the runtime and system name.

## 0.5.6: research notes, finer dither test option

What the research turned up (GitHub, cheat tables, Nexus, NVIDIA 3D Vision reports, the exe):
- The grain that "sits on textures and swims when the head moves" is the game's screen-door dither. A fixed 16x16
  Bayer pattern decides per pixel which of two layers shows: LOD cross-fades (m_lodDissolveTransitionTime,
  MS_DISSOLVE_ENABLED materials), auto-hide distance fades (m_autoHideDistance), the player fading out when the
  camera is close (m_cameraHidePlayerDistMin/Max), and decal/terrain layer blends. The pattern is locked to the screen,
  so it slides over the world as the head turns. On a monitor, Ubersampling averages it out.
- Why uniform made blood green: the pattern's half split (which pixels of every 2x2 block are above 0.5) is also used
  to decode colour. A uniform value removes that split. The new `remove_dither = fine` keeps the split exactly; this is
  verified for all 256 texels in tests/check_dither.py. It only folds the rest to a 2x2 grid (4 levels).
- Cheat tables: the camera-only table reads the view matrix at the same site as the head-tracking mod (exe+0x12473)
  and writes the main view matrix through a generic 64-byte copy at exe+0x10E1F. W2VR already overrides the view
  one level lower (the builder at exe+0x7067F5), so they confirm W2VR hooks the right camera. No new address was needed.
- Nexus: TextureMemoryBudget is the reported fix for black or late textures on RTX 30/40/50 cards.
  W2VR does not change it.
- Witcher 2's native 3D Vision had one-eye shadow errors even after patches; full-screen effects assume one centred
  view. This matches W2VR keeping symmetric_projection on.

## 0.5.5: OpenXR layers and headset smoothing

- **API layers:** XrBridgeHost.exe uses the standard OpenXR loader (64-bit). It loads every implicit layer registered
  under `HKLM\Software\Khronos\OpenXR\1\ApiLayers\Implicit` (OpenXR Toolkit, Pimax / Varjo / Ultraleap layers,
  fpsVR, ...), explicit ones via `XR_ENABLE_API_LAYERS`, and `XR_API_LAYER_PATH`. Nothing is disabled or filtered.
  It renders with D3D11 swapchains, which D3D11-only layers need. Its OpenXR application name is `XrBridge` and its
  process is `XrBridgeHost.exe`: per-app profiles (OpenXR Toolkit, Pimax Play) go on that.
- **Headset smoothing / reprojection:** the runtime decides (Pimax Smart Smoothing, SteamVR Motion Smoothing,
  ASW-style layers). The host submits every display frame with each picture's own render pose, and the mod's frame cap
  follows the panel's full refresh. That way the runtime can switch its smoothing on and off itself, and the mod never
  locks it at half rate. The mod's own reprojection (`SLOT_REPROJECT`) is not used.
- **`stereo_method = auto`** (new default): same-tick at the headset's full refresh. When the headset runs at a reduced
  rate for its smoothing (display period over 1.33x the shortest seen, for 1.5 s), it switches to full stereo, so
  both eyes come from the same game tick. Synthesised frames are then built from consistent eye pairs instead of one
  eye a frame older. w2vr.log: `stereo: headset at 36 of 72 Hz - its frame smoothing is active: full stereo`.

## 0.5.4: texture filtering for a headset

The remaining grain sits on textures and crawls when the head moves: fine texture detail sampled sharper than the
screen can show (mip LOD bias / point mip filtering, no anisotropic filtering), magnified by the lenses. The mod now
hooks SetSamplerState. For material textures (not render targets, with mip levels) it raises a negative LOD bias to
`texture_lod_bias_min` (0), makes point mip filtering trilinear, and uses anisotropic filtering
(`texture_anisotropy = 16`). Render targets (G-buffer, shadow maps, post-processing) keep exactly the game's states.
Only changes reach the device (actual state tracked against the game's). w2vr.log reports every 10 s how often the game
set a negative bias or point mip filtering. VR panel > Engine: Texture filtering for VR, LOD bias, anisotropy (live).

Compared with TheWitcher2-HeadTracking (6DOF, OpenTrack): it rotates the main camera's view matrix where the community
freecam reads it (exe+0x12473, ecx == 0). W2VR composes the eye cameras in the camera builder (exe+0x7067F5). Both act
before culling, lighting and shadows, so the head pose itself is applied at the right level. Don't install both: two
mods turning one camera conflict (w2vr.log warns if the .asi is next to the game).

## 0.5.3: one shadow again, colours right

- **Symmetric eye view back on** (`symmetric_projection = true`). 0.5.2 turned it off for speed, and each eye was then
  rendered off-centre (log: `off -0.272` / `+0.272`). The full deferred reconstruction handles that: the screen-to-world
  matrix (0xAA4167) is the viewport times the camera's inverse view-projection, off-centre terms included. The
  screen-space passes don't: the sun shadow mask, SSAO, fog and light shafts build their view rays from fov / aspect
  alone. In each eye the shadows landed shifted the opposite way, giving two shadows that move with the head. Centred
  eye views fix that. The render size goes back to 4352 x 2668 at the headset's pixel density. With same-tick that is
  about the eye rate the 4080 managed in full stereo (~68 eye pictures/s). Lower `render_scale` if it drops below 72.
- **`remove_dither` off by default.** The uniform Bayer texture (0.5.0) also changes colours: the game decodes some
  colours (blood, glowing highlights) with that pattern, and they came out green / teal. The shadow-filter rotation
  texture stays uniform (`remove_shadow_dither = true`), which removes the checker in shadows.
- **De-dither filter at 0.5** (`dedither`): smooths the remaining screen-door pattern in each eye picture without
  touching colours. VR panel > Engine; 0 = off.

## 0.5.2: only the game, repaired User.ini, the faster defaults back

- **The DLL does nothing outside witcher2.exe.** Configurator.exe (and any other program in bin) loads xinput1_3.dll
  too. Up to 0.5.1 the mod ran inside it: its window hooks resized the Configurator's dialog (cut-off UI), its
  controller hook ran there, and it overwrote w2vr.log with the Configurator's run. In any other program it is now a
  plain XInput forwarder.
- **User.ini repair.** `MaxTextureSize`, `MaxAtlasTextureSize`, `MaxCubeShadowSize` and `MaxSpotShadowSize` = 0 are
  not valid values. The game then caps textures at its minimum, which smears every texture. Such zeros are put back
  to 2048 / 4096 / shadow maps 1024 (2048 at ShadowQuality 3) every launch. Once (marker W2VR\ini_restored_052.txt),
  TextureDownscale, texture budget, MaxTextureSize, decals, rain and mesh distance go back to your original User.ini
  (User.ini.w2vr_backup) wherever that was better.
- **Defaults back to what ran well:** `stereo_method = same_tick`, `symmetric_projection = false` (render at the
  headset's own 3420 x 2668). Full stereo at the symmetric 4352 x 2668 renders both eyes per tick, about 2.5x the GPU
  work of 0.4.7: the 4080 reached ~34 ticks/s, so the headset fell to half rate (36 Hz). Both remain in the VR panel
  (View > Stereo method, Symmetric eye view) for a faster GPU.

## User.ini and the Configurator (0.5.1)

The mod no longer writes any quality or effect setting to User.ini. Only `Fullscreen=0`, `VSync=0` and the render
resolution (`[Viewport]`) are written. Depth of field, motion blur, vignette and sharpen are forced off in the renderer
instead (live, VR panel > Engine). 0.4.8's shadow quality raise is gone. Each launch, w2vr.log lists the quality values
the game is about to use, and warns if TextureDownscale, Decals or Rain are reduced.

The Configurator (bin\Configurator.exe) matches every value against fixed lists (TextureDownscale 0/1/2, switches 0/1,
AllowDecals 0.0/0.5/1.0, a fixed resolution list). The VR resolution (e.g. 4352 x 2668) is not in its list, so it
shows 720 x 576 / 5:4, and **OK saves everything it shows**. That is harmless for the resolution (the mod writes it
back at launch) but not for the quality settings. When you use it, check TextureDownscale = NoDownscale,
TextureMemoryBudget = HighBudget or VeryHighBudget, ShadowQuality / ShadowedLights, AllowDecals = HIGH,
AllowRain = Enabled, UberSampling = Disabled, then OK.

## The grain removed at its source (0.5.0)

The grain is the game's screen-door dither, and the dither comes from one texture. At start-up the renderer builds
five small procedural textures with D3DXFillTexture (exe 0x53ECE0). Run in the emulator (tests/check_dither.py,
the game's own code):
- **0x53EF90** fills a **16 x 16 Bayer ordered-dither matrix** (thresholds 1, 128, 32, 159, 8, 135 ... / 255: every 2 x 2
  block spans 75 % of the range). It is the alpha threshold of the game's dithered blends: decal and ground layers,
  LOD cross-fades, "transparent" shadows. These are the two-level pixel blobs in the screenshot.
- **0x53F140** fills 16 x 16 rotation angles in the same Bayer order: the per-pixel rotation of the shadow filter's
  sample pattern (interleaved PCF). This is the checker in shadows.

`UberSampling` (N x N passes with sub-pixel camera offsets, 0xB14A8A, N = 2..16) averages these patterns away on a
monitor; nothing cheaper exists in the exe (its other UberSampling checks only pick a different render target).

0.5.0 swaps the two fill callbacks (the single push of each, 0x5424D6 / 0x542587) for ones that write one value to
every texel: the Bayer texel at 0.5 (a clean 50 % alpha test instead of a screen door) and one fixed rotation. That
happens inside the hooked CreateDevice, before the game can build them. w2vr.log shows `screen-door dither removed at
the source` and then `dither textures built uniform (256 + 256 texels ...)`.

Side effects: dithered fades (LOD changes, objects fading near the camera) switch at the halfway point instead of
dissolving, and soft shadow edges use one fixed filter pattern (they can show slight stepping instead of noise). Both
can be switched back: `remove_dither = false`, `remove_shadow_dither = false`. The 0.4.8 smoothing filter is now off by
default (`dedither = 0`). It is still in the VR panel.

## Crash when loading a save (0.4.9)

0.4.8 compiled the de-dither shaders at run time with the game's d3dx9_39.dll, on the render thread, at the first 3D
frame: exactly when a save loads. The game compiles its own material shaders with the same D3DX on its loader
thread, and the D3DX compiler is not thread-safe. The log stopped there with no crash line.
- The shaders are now precompiled vs_3_0 / ps_3_0 bytecode inside the DLL (built with vkd3d-compiler from the HLSL
  kept in dedither.cpp; disassembly checked). D3DX is not called at all.
- The filter's draw is now inside BeginScene / EndScene (at Present the game's scene is closed, so 0.4.8's draw would
  have failed there).
- Crashes are logged again: the game installs its own crash handler over the mod's, and it exits silently. The
  game's call is now intercepted: w2vr.log gets `CRASH code ... at module+offset` with registers and stack, then the
  game's handler runs.
- `full_stereo_tolerant` (default true) switches 0.4.8's tolerant frame-camera match; `dedither = 0` turns the filter
  off. Both can be ruled out separately if anything still crashes.

## The grain is the game's own dither (0.4.8)

Measured on the W2VR screenshot: the grain is a 1-pixel checker and hard-edged two-level pixel blobs, strongest on
textured geometry and absent from the sky. Two materials (stone / dirt layer) or lit / shadowed alternate pixel by
pixel. That is screen-door dithering, and it is native to The Witcher 2. Without Ubersampling, players have reported
"grid shadows", "dithered lighting" and a "mesh pattern over the textures" since 2011. The renderer smooths lighting with
a cross-bilateral filter (`postfx_cbf.fx`, called unconditionally after the lights at exe 0xB143D3; SSAO has its own
`NOT_SKIN` pass). That filter deliberately stops on bright, high-contrast surfaces. On a monitor the PCUber profile hides
the rest with `UberSampling=2`, the frame drawn four times with sub-pixel offsets and averaged. That is 4x per eye, not
viable in VR. The headset's lenses magnify each pixel, so the pattern shows as grain.

- **De-dither filter** (`dedither = 1.0`, VR panel > Engine, live): an edge-preserving 3 x 3 filter on each eye picture,
  right after it leaves the back buffer. It weights neighbours by RELATIVE brightness difference (dither steps of
  10 - 40 % are smoothed; real edges are kept). On the screenshot the checker energy halves and the sharpest silhouette
  keeps 88 % of its contrast. The shader is compiled at start-up with the game's own D3DX; `de-dither: filter ready` in
  w2vr.log confirms it. `dedither_range` (default 0.35) sets how much contrast still counts as dither.
- **Finer shadows** (`vr_shadow_quality = true`): User.ini `ShadowQuality` 3, point / spot shadow maps 1024 (only ever
  raised). The dither softens low-resolution shadow maps, and your User.ini had 256 / 512.
- **Full stereo comes back**: the watchdog that switches to same-tick AER when the renderer never sees the eye
  cameras now does so per scene. The 0.4.7 log shows it firing during the intro (another camera) and then staying off
  for gameplay. It now retries whenever the main camera changes. The frame camera is also matched within a few cm /
  1 degree when the game adjusted it after the build (shake, cutscene touch-ups), instead of only bit-for-bit. The two
  eyes then come from the same tick again; same-tick AER showed moving things a frame apart (halos).
- **headset_size.txt** in the zip now has your four values (`3420 2668 1.2725 1.0000`). The 0.4.7 file had only the size,
  which overwrote the symmetric-view ratio, so 0.4.7 rendered at 3420 x 2668 instead of 4352 x 2668.

Not fixable by filtering: the larger blobs on nearby ground are a decal layer dithered in texture space, so they grow
with the surface. They stay put (they don't shimmer). `UberSampling=2` in User.ini would remove them at 4x the GPU cost.

## The game hangs on the medallion splash (0.4.7)

On CPUs with **32 or more logical processors** (e.g. Ryzen 9 16-core, Core i9-13900 / 14900) The Witcher 2 stops
at its medallion splash screen. The community fix is starting it with a restricted CPU affinity
(`start /affinity FF`). The cause, in the exe:

```
0x930A6E  GetProcessAffinityMask(proc, &procMask, &sysMask)
0x930AAD  if (procMask != sysMask) return 8;                      // early exit
0x930ACF  for (bit = 1; bit <= sysMask; bit = 1 << ++n) { SetThreadAffinityMask(bit); cpuid; strcat(...) }
```

A 32-bit process on such a machine gets `sysMask = 0xFFFFFFFF`, which no bit can exceed, and x86 wraps `1 << 32`
back to 1, so the loop never ends. Any affinity restriction makes `procMask != sysMask`, so the routine takes its early
exit. That's why the affinity trick works.

**The fix (built in, `fix_many_core_hang = true`):** the mod redirects the game's `GetProcessAffinityMask` import.
For exactly that one call (recognised by the bytes after it, `mov eax,[ebp-8]; cmp eax,[ebp-4]; je +7; mov al,8`)
and only with more than 16 logical processors, it reports the process mask with its top bit cleared. The routine
takes its own early exit, exactly the path the affinity workaround leads to, but the game's real affinity is untouched
and every core stays in use. `tests/check_compat.py` checks that those bytes occur once in the exe, right after the
call in that routine, and reproduces the endless loop at 32 processors (31 or fewer always ends).

**Fallback:** `W2VR_Launch.bat` (in `bin`) starts the game limited to the first 16 logical processors. Use it only if
the game still hangs; in Steam set the launch options to `"<path to bin>\W2VR_Launch.bat" %command%`.

After a clean reinstall, also make sure `Documents\Witcher 2` can be created (OneDrive-redirected Documents can
block it), and copy the whole `mod` folder into `bin` again.

## The grain: the game's sharpen filter (0.4.6)

The 0.4.5 test ruled out shadow acne: with the shadow maps off the grain stayed. The player's `User.ini` had
**`AllowSharpen=1`**, and the mod's `disable_sharpen` was off. The game's sharpen pass boosts fine detail and edge
contrast. In a headset (the image is resampled again by the compositor) that shows as grainy dark specks on bright,
detailed surfaces (sunlit stone, wood) and dark halos along edges, which is exactly the pattern in the screenshots.
Sharpen is one more test in the post-process mask (`AllowSharpen` +0x5F → bit 0x100, `+0x5C00AC`). It's now a live
renderer switch like DOF, **off by default** (and `AllowSharpen=false` in User.ini). Emulated: it clears exactly bit
0x100. The shadow depth-bias sliders stay available but default to 0 (the game's own bias).

Also seen in the player's config: the **FOV-90** UserContent mod is mounted (`Config\UserContent.ini`:
`Mount=FOV-90`). In VR the headset sets the view, so it only lowers mesh detail: the detail scale follows the game's
own fov with `engine_keep_lod`. Unmount it for VR (empty the `Mount=` line).

## The grain on sunlit surfaces: shadow acne? (0.4.5 - ruled out)

The 0.4.4 screenshots (symmetric view on, SSAO on) still showed grainy dark specks, but **only on sunlit surfaces**
(shadowed ground was clean), and no less than before. So it isn't SSAO or a projection mismatch. It is shadow acne.

- **What the frame shows:** the frame's target list shows the sun's shadows as three 1024×1024 cascades in a
  depth-only 1024×3072 target (colour format FOURCC `NULL`). There is no setting for their size; the config table has
  only spot / cube shadow sizes.
- **Why VR makes acne:** the eye view is about 104° vertically (wider still when symmetric), against roughly 60° in
  the flat game. The cascades are fitted to that view, so each shadow texel covers several times more ground. The
  game's depth bias was tuned for the flat view and no longer covers it, so lit surfaces shadow themselves at random.
- **The fix,** the standard one stereo-fix tools (geo-11 / HelixMod / 3DMigoto frame analysis) point to (fix the
  one pass at fault): extra slope-scaled and constant depth bias (`D3DRS_SLOPESCALEDEPTHBIAS` / `D3DRS_DEPTHBIAS`),
  added to the game's own values and **only while drawing into shadow maps**. That means depth-only targets that are
  not screen-sized, so the main view's depth (and its exact depth tests) is never touched. Defaults: slope 2.0,
  constant 0.0003. Both are live sliders in Engine; too much bias detaches shadows from their objects (peter-panning).
- **Test switch:** Engine → "Test: shadow maps off" skips the shadow-map draws. If the grain goes away with it, it's
  acne, and the two sliders tune it out. The log reports `shadow maps: N draws, extra depth bias ...` every 10 s.

## Audit and fixes (0.4.4): no DOF anywhere, AO and shadows kept clean

- **Second DOF path found and closed:** the renderer's post-process setup (`+0x5C0311`) has a branch that ignores
  every setting. When the frame's normal post-processing is off (frame info +0x2767) but +0x278D is set, it writes
  the mask as the constant **0x2060**: gameplay, cutscene and scatter DOF together. That's the path that could still
  blur cutscenes and dialogue. The DOF switch now patches that constant to 0 as well. Emulated with the game's own
  code: unpatched 0x2060, patched 0.
- **DOF / vignette coverage:** the per-frame mask (`+0x5BFFE8`) is the only other writer of the post-process bits.
  Its only caller is the function above, and the mask is stored once per frame (`[frame+0xDC]`). Gameplay DOF
  (0x20), cutscene DOF (0x40), scatter DOF (0x2000) and vignette (0x80) are all forced off live. Cutscene DOF tracks
  (`m_useDofTrack`, `DOF_Override`) only feed parameters into those passes.
- **Ambient occlusion and shadows stay on, without the grain:** the game's screen-space passes (SSAO with its
  depth-aware blur, fog, light shafts) rebuild positions assuming a centred view. A headset's off-centre eye view
  (Pimax: ±0.196) breaks that: the blur rejects its samples and the raw SSAO noise shows as grainy dark specks and
  halos. **Symmetric eye view** is now on by default: each eye is rendered with a centred view wide enough to hold
  the headset's view, and the headset is told exactly that view. SSAO is back on (`disable_ssao = false`). Shadows
  were never touched by the mod. The extra width is measured from the headset and stored in `headset_size.txt`
  (`w h rx ry`); from the next launch the render size grows by it, so the pixel density stays the same.
- **The same-tick eye tag is centred now:** same-tick (and AER) must tell its two eyes apart when their views are
  identical, which is always the case with symmetric views. The tag used to shift a frustum off-centre by 0.007.
  Now the left eye's view is 1% wider and the right eye's 2%, both centred. The draw matcher (0.4% tolerance) tells
  them apart, and screen-space effects see no offset. Full stereo needs no tag (each pass knows its eye).
- **HUD panel:** the log now also counts the 2D draws that belong to the 3D picture (glow, scene copies) and are
  kept off the panel (`... kept out`), next to the HUD draws taken from the back buffer and from the final target.



From the 0.4.2 log: the HUD and UI scaled correctly, but there was still grain on lit surfaces and a faint copy of the
game on the HUD panel.

- **Ghost image on the HUD panel:** post-process composites (bloom / light shafts from the 1/2- and 1/4-size
  screen buffers) were drawn onto the final target after the scene and were taken as HUD. A draw sampling any
  screen-shaped render target, down to 1/16 of the width, is now part of the 3D picture and never HUD.
- **Shader patch not needed in this setup:** with the engine camera and the HUD panel it did nothing useful, yet it
  replaced every vertex shader with a patched one. `patch_shaders = auto` (new default) analyses all shaders for
  draw classification and the HUD panel but leaves them unchanged. It patches only for the shader camera fallback
  or for a HUD drawn into the eye image (fitted / full).
- **SSAO:** it rebuilds positions assuming a centred view; a headset's off-centre eye views (Pimax: offset ±0.196)
  give grainy dark specks and halos. It's now a live renderer toggle like DOF (`AllowSSAO` +0x61 → mask bit 0x400),
  off by default. To keep SSAO, use **Symmetric eye view** (`symmetric_projection`): each eye is rendered with a
  centred view wide enough to hold the headset's view (about 20% more pixels), and the headset is told exactly
  that view.
- **The headset size was never saved:** the bridge's "wait for the recommended size" with a timeout of 0 never
  checked even once. That was the `timed out waiting for the host` warning every 10 s, and it left the game at
  3840×2160 (16:9) for a 3420×2668 eye. Fixed, and the package carries the Dream Air size.
- **Full stereo** no longer gives the eyes the identification tag, since each pass knows its eye.
- **The DLL reported the wrong version** (0.4.1 inside the 0.4.2 package); it now reports 0.4.3.
- **Your settings ship as the defaults:** the packaged `w2vr_config.txt` is the one from the test, with HUD panel
  distance 1.25 m and width 1.85 m (now also the built-in defaults). The only changes are `patch_shaders = auto`
  and the two new keys.

## Fixes from the first in-game test (0.4.2)

The first log (Pimax Dream Air, RTX 4080) and its screenshots showed grainy dark speckles and halos over every lit
surface, and a HUD that stayed in the eye images at full headset width. The causes found in the exe:

- **Full stereo lighting (the speckles):** right after every frame-camera build the game computes a "screen to world"
  matrix into frame info+0x2B0 (`+0x6A4167`: the pixel→clip transform × the camera's inverse view-projection).
  Deferred lighting, shadows, SSAO and fog rebuild each pixel's position from depth with it. Full stereo rebuilt the
  camera per eye but not this matrix, so the lighting used the head-centred camera while the geometry used the eye
  camera, which shows up as shadow acne and dark halos. Each eye pass now calls the game's own function after
  rebuilding its camera, and the matrix is restored afterwards. The test checks it against the game's function (2e-7);
  with the old behaviour it fails (error 1.0). Full stereo now refuses to engage if that function isn't found.
- **Head pose applied twice (HUD fit 1.00):** after about a minute the "main camera" vote moved to a temporary copy
  that the renderer makes of the already head-tracked camera (about 2,100 builds per second). The head pose and eye
  projection were then stacked on top of themselves. Now a camera whose values equal anything the mod just wrote is
  recognised as a copy: it is never composed again and never votes. The main camera also only changes when a rival
  clearly out-votes it (no flapping between a camera and its copy). Tested: a copy rebuilt at another address comes
  out unchanged.
- **Constant clash (`reserved-constant writes` in the thousands):** the game keeps skinning / instance data in
  c128..c255. Shaders that index constants relatively could read the mod's c252..c255 values instead of the game's.
  In game-camera mode those shaders are now analysed (draws still classified) but not patched, so the mod never
  writes into constants they read.
- **Gameplay HUD never reached the panel:** in gameplay the game draws the scene and HUD into an intermediate target
  and copies it to the back buffer at the end; menus draw to the back buffer directly. The panel now also takes 2D
  draws on that final target, but only after the scene has been composited into it that frame, and restores the
  game's own target afterwards. The log reports `HUD panel draws: ... from the back buffer, ... from the game's final
  target`, plus a one-time list of the frame's draw targets.
- **Frame cap dropped to 36 fps:** the Pimax runtime reports half rate (27.8 ms) while it smooths motion. The
  `headset` cap now keeps the highest rate the headset has reported.

New: **menus on the flat screen.** The script natives `IsPaused` / `IsActivelyPaused` (`+0x6A72B1`, `+0x6A78D6`) read
the game object (`[0x1404950]`): +0x5C pause count, +0x60 active-pause count, both void while the byte at
`0x160868F` is set. While the game is paused (pause menu, inventory, map, journal, character panels), the headset
shows the normal game picture on the flat virtual screen, and VR returns as soon as the game runs. The game's
"active pause" (most likely the quick-select wheel) stays in VR unless `flat_on_active_pause = true`. Toggle: View →
"Menus on the flat screen" (`flat_when_paused`).

## Audit (0.4.1)

A full pass over the source against the exe. Fixed:

- **Recentre keys clashed with the game:** Space is dodge and F9 is quickload in The Witcher 2. Recentre is now Home
  (`recenter_key`), and the fixed F9 binding is gone.
- **`window_scale = auto` never worked:** "auto" parsed to 0, which the range check reset to 1.
- **The resolution was read from the wrong User.ini keys.** The exe reads `[Viewport] Width/Height` into both its
  fullscreen and windowed sizes (`+0x707727..+0x70788A`); `FullScreen*/Windowed*` are only a fallback when those are
  missing. The mod now takes the resolution from `Width/Height`.
- **Render size for landscape eyes:** the longer side was always treated as the height, so a wider-than-tall eye
  came out too wide. Fixed in both User.ini sizing and `force_render_size`, rounded to a multiple of 4.
- **Mouse past the screen edge:** with a native-size window taller than the monitor, the lower menus were out of
  reach. Fixed by the mouse mapping above.
- **Motion blur, vignette and blur** are now live renderer patches like DOF, instead of User.ini only.
- **Leftover Assassin's Creed defaults:** `render_aspect` defaulted to 5:4 and the AC2 HUD aspect fix to on when the
  key was missing. Some screen and menu defaults also differed between code and config. Every key read by the code
  now has the same default as `w2vr_config.txt` (checked by script).
- **Full stereo:** the mid-frame copy of the first eye is marked as the mod's own work (the draw hooks ignore it).

Checked and fine as they are:

- **Proxy:** export argument sizes are right.
- **Init order:** User.ini, then window hooks, then D3D.
- **Device-time signatures:** every one is unique.
- **Full stereo:** thread safety between the game and render threads, the restore of the frame camera / present flag
  / LOD, and the same-tick fallback.
- **Same tick:** the clock and loop stubs.
- **HUD redirect:** state restore after each draw.
- **D3D9Ex:** the managed-pool conversion.
- **Cursor clipping:** it uses `GetWindowRect` (real screen coordinates).

## Install

1. Copy everything in `mod/` into `The Witcher 2\bin\` (next to `witcher2.exe`): `xinput1_3.dll`,
   `XrBridgeHost.exe`, `w2vr_config.txt`, `steam_appid.txt`, the `W2VR_SkipLauncher*` files and `W2VR_Launch.bat` (fallback only).
   **Straight into the game:** run `W2VR_SkipLauncher_Install.bat` there once. Steam / GOG "Play" then starts the game
   and VR directly, with no launcher window. Hold **SHIFT** while pressing Play to get the original launcher
   (Configurator, DLC). `W2VR_SkipLauncher_Uninstall.bat` (or Steam's "verify files") puts the launcher back.
2. **Remove the head-tracking mod while playing in VR** (`TheWitcher2-HeadTracking.asi` and its `dinput8.dll`). It
   rotates the same camera. The VR mod logs a warning if it finds it.
3. Start SteamVR (or another OpenXR runtime), then the game.
4. Every start, the mod asks the headset for its per-eye resolution and FOV before the game reads `User.ini`
   (up to 5 s; 15 s the first time) and sets the game's resolution and aspect ratio from them.

To uninstall: delete those files and the `W2VR` folder and restore `Documents\Witcher 2\Config\User.ini.w2vr_backup` as `User.ini`.

## Controls

| Key | Action |
|---|---|
| Insert, or hold L3 + R3 | VR panel (all settings, saved to `w2vr_config.txt`) |
| End | First person on / off |
| Home | Recentre (`recenter_key`; not Space / F9, which are dodge and quickload in The Witcher 2) |
| F8 | Stereo → head-tracked mono → flat screen |
| F7 | HUD mode: floating panel → fitted in view → full size |
| Delete | Screenshot (PNG next to the exe) |
| F10 | Save diagnostic images to `bin\W2VR\` |

## HUD mods (Dynamic HUD, ContextHUD)

Both work alongside W2VR and are a good match for VR: they hide most HUD elements outside combat, so less floats in
front of you. **Install only one**, because both replace `globals\gui\hud.swf`:

- **Dynamic HUD 1.3**: `dynamichud.dzip` in `CookedPC\`. Needs the Combat Log enabled (Options › Gameplay).
- **ContextHUD**: it ships a complete `base_scripts.dzip` (the Project Mersey script set, which also changes
  prices and other gameplay) plus `hud.swf`. It replaces your scripts wholesale, so back up `CookedPC\base_scripts.dzip`.

Neither scales the HUD (the HUD is a fixed 1280×720 Scaleform stage). Scaling is W2VR's job (VR panel › HUD).



## Engine research round 3 (GitHub and community)

- **Gibbed.RED** (github.com/yole/Gibbed.RED; GUI version on Nexus #1027): archive pack/unpack, `.w2strings`, a
  resource browser and a script decompiler. These are content tools; nothing on the renderer, camera or HUD.
  There's no public decomp or recomp of `witcher2.exe`, and REDkit/WolvenKit target Witcher 3 / Cyberpunk.
- **Widescreen community (WSGF, Flawless Widescreen, Widescreen Fixer, a hex edit of the `16/9` float):**
  since patch 1.1 the game forces 16:9 with black bars. Traced in this exe: the viewport set-size routine
  `+0x6AEB8E` picks a target aspect from the table at `0xE46DB4` (16:9, 16:9, 4:3, 5:4, 16:10, 5:3, 48:9, 27:16) and
  computes bars with `ftol` into `ebx` / `edi`. W2VR turns the two `mov reg,eax` into `xor reg,reg`. Emulated: a
  2064×2096 frame gives 2064×1162 + bars unpatched and the full frame patched; 3440×1440 reproduces the ultrawide
  complaint (2560 wide + pillars).
- **HUD:** the community's Witcher 2 UI mods are font replacements (`fonts.swf`, Nexus #990: the game exposes no font
  size) and AI-upscaled HUD art; there's no HUD-scale mod. That's why the HUD goes on its own full-resolution panel
  instead of being shrunk into the eye image. Witcher 3 got HUD scale/position mods; REDengine 2 never exposed it.

## HUD panel: how it works

- **Capture:** 2D draws into the back buffer that don't sample a screen-size render target (the HUD, menus, cursor,
  subtitles) are drawn into a back-buffer-sized target instead.
- **Alpha:** while they draw, separate alpha blending is set to `ONE / INVSRCALPHA`, so the result is correct
  premultiplied alpha.
- **State:** the viewport, scissor and blend states are mirrored from the game (Get* calls fail on a pure device) and
  restored after every redirected draw.
- **Each frame:** the target goes into the atlas's HUD rectangle (also over flat frames, so a menu over a paused world
  keeps its UI), then it's cleared. The host shows it as a head-locked, premultiplied quad.
- **Size:** width = 2 · distance · tan(game horizontal half-FOV) · `hud_size`, recomputed live from the game's own
  projection. Change the distance and the panel keeps its angular size; only the focus depth changes.
- **Fallback:** if a multisampled back buffer or a failed target rules the panel out, the HUD falls back to the
  fitted mode automatically.

## Full stereo (how it works)

Found in the exe (2013-05-09 build):

- `RenderCommand_RenderScene::Execute` (`+0x5DC56A`, render thread) passes the frame and scene to the renderer's
  frame function `+0x715317` (stdcall: renderer, frame, scene). The frame's `CRenderFrameInfo` is at `frame+0x10`,
  its render camera at `frame+0x20`, the render size at `frame+0x2B8/+0x2BC`, and the "present when done" flag at
  `frame+0x2B4`. Present is the frame function's last step (`+0x715958` → `+0x5D5FF5` → `IDirect3DDevice9::Present`,
  then `ValidateRect`).
- **The engine already re-renders one frame with a changed camera:** the tiled uber screenshot (`+0x715C00`) sets the
  frame camera's off-centre terms (`+0x70712C` → the camera builder), undoes the scene's per-render frame counter
  (`scene+0x74`, incremented at `+0x5C0148`) and calls the frame function again, once per tile.

W2VR does the same, once per eye:

1. **Game thread:** the main camera becomes the head-centred view covering both eyes (so streaming and LOD see the
   whole headset view), and both exact eye cameras of that tick are prepared.
2. **Render thread** (hook on the frame function, main frame only): left-eye camera into `frame+0x20`, matrices
   rebuilt by the game's own builder, present off, draw, copy out as the left eye; then the scene counter is undone,
   right-eye camera, present on, draw. The right eye is captured at Present, and the frame camera is put back.

Other frames (render-to-texture previews, screenshots) pass through untouched. Each pass's draws are tagged with that
pass's exact eye pose, so the headset reprojection uses the right pose for each eye. The HUD panel is cleared between
the passes, so it isn't drawn twice. Verified with the compiled DLL in the emulator (`tests/check_fullstereo.py`):

- each frame is drawn exactly twice;
- each pass's view and projection equal that eye's own camera built by the game's builder (7e-8);
- the eyes are 64 mm apart;
- the present flag and scene counter behave as above, and the frame camera is restored.

**Watchdog:** if VR stereo has run about 2 s with the head pose applied but no frame ever reached the hook, W2VR
falls back to same-tick AER and logs it. Choose Full stereo again in the panel to retry.

Costs and caveats: two full scene renders per game tick (the same GPU work as AER, but the game updates half as
often per displayed eye, so the CPU is cheaper). Effects that adapt over frames, like eye adaptation, see two
renders per tick, which only makes them adapt slightly faster. Lens flares use occlusion queries and could flicker
per eye; if anything looks wrong, use `same_tick`.

## Depth of field (forced off)

Every frame the renderer builds a post-process mask (`+0x5BFFE8`, frame info in esi). Each effect bit is set only if
the frame / environment / cutscene asks for it **and** the settings object allows it (`[0x2580E28]`, offsets from the
config table at `+0x707714`):

| Bit | Effect | Setting (offset) |
|---|---|---|
| 0x2 / 0x4 / 0x8 / 0x10 | bloom / light shafts / AA / blur | AllowBloom 0x50, AllowShafts 0x51, 0x52, AllowBlur 0x53 |
| **0x20** | **DOF (gameplay)** | **AllowDOF 0x54** |
| **0x40** | **cutscene DOF** | **AllowCutsceneDOF 0x5C** |
| **0x2000** | **scatter (bokeh) DOF** | **AllowScatterDOF 0x5D** |
| 0x80 / 0x100 / 0x200 | vignette / sharpen / rain | 0x5E, 0x5F, 0x60 |
| 0x400 / 0x800 / 0x1000 | SSAO / motion blur / fog | 0x61, 0x62, 0x63 |

**Motion blur (0x800), vignette (0x80) and fullscreen blur (0x10)** get the same treatment (one test each), so they
also stay off live, even if the game's options menu rewrites User.ini during a session.

There is no other path to the DOF passes. W2VR turns the three DOF tests' `je` into `jmp`, so none of the three DOF
bits can be set, whatever User.ini, the options menu or a cutscene asks for. It's a live toggle (Engine → "Depth of
field off"). `AllowDOF`, `AllowCutsceneDOF` and `AllowScatterDOF` are also written as false in User.ini. Verified by
running the game's mask function in the emulator (`tests/check_dof.py`, signatures read from the source). Each effect,
patched on its own, clears exactly its own bits (DOF 0x2060, motion blur 0x800, vignette 0x80, blur 0x10). With all
of them patched, bloom, shafts, AA, sharpen, rain, SSAO and fog are untouched.

## Same tick (how it works, and why it's different from the AC2 mod)

REDengine's main loop (`witcher2.exe+0x6A5E2A`) computes, per frame:
`dt = clock − last; dt = min(dt, 0.1); dt = max(dt, 0.2667 × previous dt); if (dt > 0) Tick(dt)`.
Freezing `QueryPerformanceCounter` (the Assassin's Creed method) fails here:

- The floor turns a frozen dt into 27% of the last frame, so the world still moves and the game runs fast.
- A true dt of 0 skips `Tick`, so no frame and no camera are built for the second eye.

W2VR instead sets the loop's final dt itself (at `+0x6A5ED5`):

- **First eye:** real time plus whatever the second eye didn't use.
- **Second eye:** 1e-5 s. The tick runs, but the world doesn't move.

During the second eye it also holds REDengine's engine clock (`+0x6C103A`, 98 callers: timers, animation, effects)
at the first eye's time. The loop's own clock read is exempt, so real time keeps being measured. The second eye also
reuses the first eye's game camera. Verified in the emulator: exact game-time conservation, the hold pattern, the
held vs. real clock reads, and preserved flags and XMM registers. Switch to `aer` in the panel if any system misbehaves.

## First person

Based on the FPC preset and the Enhanced Camera mod you sent:

- **How Enhanced Camera does it:** it drives the camera behaviour-graph variables `cameraFurther` / `camera_axis_X`
  / `camera_axis_Z` from `User.ini [Gameplay]` (its first-person template is `cameraFurther = -3.0`, X 0.1, Z -0.1),
  and disables vanilla's per-frame `theCamera.SetZoom(cameraFurtherCurrent)` in `movable.ws`.
- **How W2VR does it, without any script mod:** in the render camera, the eye goes `first_person_distance` (3.0 m)
  along the game camera's *pitched* view axis (the orbit pivot), plus `first_person_right` / `first_person_up`. With
  decoupled pitch the view stays level, your head looks around, and the mouse still orbits, so the eye stays at
  Geralt's head. `first_person_near` (0.18 m) clips his head and hair.
- **Limits:** when a wall pulls the game camera in, the pivot estimate lands ahead of Geralt. Lower
  `first_person_distance` live, or zoom out.
- **If you install Enhanced Camera with the FPC preset instead,** the game camera itself is already in first
  person (with its own collision). Keep W2VR's first person **off** then, or the offsets add up. Enhanced Camera ships
  a full `base_scripts.dzip`, so it conflicts with ContextHUD.

## Native stereo in the exe (researched)

Witcher 2 has built-in **NVIDIA 3D Vision Automatic** support:

- the NvAPI loader at `+0x42AEE0`
- `m_pStereoHandle`
- an 8×1 R32F stereo-parameter texture its shaders read
- per-camera `ConvergenceInside/Outside/Cutscene/Close` settings, plus script `ForceConvergence`

In that mode the *driver* duplicates each draw. The engine never renders a second camera, so there's no native
two-eye path to reuse for OpenXR, and W2VR's engine-camera AER is the right route. `block_nvidia_stereo` (default on)
makes the game's own `LoadLibraryA("nvapi.dll")` fail, so a leftover 3D Vision driver can't stack its stereo on top
of the VR eyes. Without nvapi the stereo texture stays neutral and the shaders' stereo correction does nothing.

## HUD and UI (researched)

- **How the HUD is built:** it's a Scaleform GFx movie (`globals/gui/hud.swf`, 1280×720 stage), with panels in
  `gui.swf`. The SWFs never set `Stage.scaleMode`; the engine does natively.
- **Panels and remapping:** full-screen panels fit their background to the screen (`FitBackground`, `m_Width` /
  `m_Height`). The HUD caches `Stage.width/height` and remaps screen rects to stage rects (`+0x5ABC20`).
- **No scale control in the game:** neither the engine nor the scripts expose a HUD scale. Scripts can only show or
  hide (`theHud.SetGuiVisibility`; vanilla binds **H** to toggle the whole GUI, handy for screenshots in VR). So
  scaling stays at the D3D level (W2VR's HUD shader scaling).
- **The game FOV sets the HUD size:** in VR the fitted HUD has the angular size of the game's own camera FOV. W2VR
  replaces the projection, so the game FOV (vanilla 53°, or Enhanced Camera's `CameraFOV`) now only sets the HUD fit
  and the LOD scale. A higher `CameraFOV` gives a bigger HUD.
- **HUD mods:** Dynamic HUD and ContextHUD reduce what's on screen, which suits VR; install only one.

## What is verified, and what isn't yet

Verified offline against **your** `witcher2.exe` (its code decrypted locally; it is encrypted by SteamStub 2.1):

- All hook signatures are unique in this build. They're found at device creation, after SteamStub has decrypted
  the code. The head-tracking mod's and the CE tables' camera sites (`+0x12473`, `+0x5B3874`, `+0x5D2A05`,
  `+0x70705x`, `+0x7072xx`) all match this build too.
- The camera maths, run against the game's own builder in an x86 emulator (`tests/`):
  - 400 random cameras and head poses: the eye view equals an independent derivation to 7e-6.
  - The headset FOV is always fully covered, pixels are square, and the engine's inverses stay exact.
  - The framework's shader-constant detector recovers exactly each eye's projection from REDengine's view-projection
    in all 800 upload layouts. This is what tells the mod which eye a draw belongs to.
  - The **compiled DLL's** hook, run in the emulator at all four stack alignments: it matches the native maths
    (4e-7), never applies the head pose twice on a rebuild, and the LOD stub is correct and preserves registers.
  - First person: the eye lands exactly on the orbit pivot, the view stays level, and the near plane is raised (2e-7).
  - The **letterbox patch**: the game's own viewport routine, emulated, gives the full frame at any aspect.
  - **Full stereo**: the compiled render hook draws each frame twice with exact eye cameras (see "Full stereo").
  - **DOF off**: the game's post-process mask, emulated, never enables gameplay, cutscene or scatter DOF.
  - The **compiled same-tick stubs**: game time is conserved exactly, the second eye's frames don't move the world,
    the clock is held only for other callers, and the loop's flags and XMM registers survive.

Not verified yet, because I have no game data or headset here. Watch for these on the first run:

1. **Is the main camera recognised?** The log (`bin\w2vr.log`) should show
   `camera: REDengine render camera builder hooked`, then `camera: main render camera ...`, and in the 10-second
   reports `head pose applied` > 0 and `3D` frames > 0.
2. **HUD panel:** the HUD, menus and mouse cursor should float on the panel, sharp. If part of the world shows up on
   the panel, or the HUD stays in the world image, send the log (the `d3d9`/`xr` lines) and use F7 for fitted mode
   meanwhile. Full-screen fades and damage overlays are also 2D, so they show on the panel too.
3. **Window at the full VR resolution:** the log should show `window: created with client 2064x2096 ...` and
   `d3d9: back buffer 2064x2096 ... windowed`. A `window: asked for client ..., Windows gave ...` warning means
   Windows still limited the window; the game still renders the full size then. If the game itself picks another
   size (`d3d9: the game asks for ...`), set `force_render_size = true`.
4. **Full stereo:** the 10-second log line `full stereo: N frames drawn for both eyes` with N > 0, and no
   `falling back to same-tick` warning. Lens flares or eye adaptation acting oddly per eye → `stereo_method = same_tick`.
   DOF: `engine: depth of field forced OFF` at start-up.
5. Same tick: the 10-second log line `same tick: active, N game frames (N/2 held)` with game time given ≈ real
   time. If anything stutters or animates oddly, set `stereo_method = aer`.
6. First person: tune `first_person_distance` / `up` live in the panel.
7. Cutscene camera cuts are handled by the camera-cut logic (it switches at once after 2 frames). If a cutscene shows
   flat or mono for long, send the log.

If you send me `bin\w2vr.log` after a short session (main menu → gameplay → a cutscene), I can tune from it.

## Troubleshooting

- **Black or flat image in the headset during gameplay**: check the log for `main render camera`. If the shaders
  never recognise a main camera, the mod falls back to "last built eye" (`engine_no_shader_fallback`). Set
  `camera_mode = shader` to try the framework's generic shader stereo instead.
- **Double vision / eyes swapped**: set `eye_tag = true` (default) and keep `stereo_method = aer`.
- **Motion sickness from camera pitch**: keep `decoupled_pitch = true`.
- **Too close or too far from Geralt**: `camera_offset_z` (metres, + = forward).
- **Launcher loops on Steam with the mod in `bin`** (reported for 3D Vision packs): put `steam_appid.txt` containing
  `20920` in `bin\` and start `witcher2.exe` directly with Steam running.

## Technical notes (for modders)

`CRenderCamera` layout, confirmed by emulating the exe's own code:

| Offset | Field |
|---|---|
| `+0x00` | position (Z-up world) |
| `+0x10` | Euler angles in degrees: roll, pitch, yaw. Rows = `Ry(roll)·Rx(pitch)·Rz(yaw)`; yaw 0 = +Y, anticlockwise |
| `+0x1C` / `+0x20` / `+0x24` / `+0x28` / `+0x2C` | vertical FOV, aspect, zoom, near, far |
| `+0x280` / `+0x284` | off-centre terms: P[2][0] = −o280, P[2][1] = o284 |
| `+0x40` | world→view, derived (view: x right, y up, z forward) |
| `+0x80` | world→local, derived |
| `+0x100` | inverse of `+0x40` |
| `+0x180` | projection, row-vector, w = z |
| `+0x140` | inverse projection |
| `+0x1C0` | view-projection |
| `+0x200` | inverse view-projection |
| `+0x270` | 1/tan(fov/2), screen-size/LOD scale |

The builder is `witcher2.exe+0x7067F5` (stdcall, camera as its only argument; 7 callers). `CRenderCamera::Set` is at
`+0x7071EE` and the FOV setter at `+0x707178`. The mod changes the builder's *inputs* and lets the engine derive
everything, with per-field anti-compounding for rebuilds without new input.

Build: `source/scripts/build.sh` (MinGW-w64, `i686-w64-mingw32-g++-posix`). Tests: `source/tests/run_tests.sh`
(needs a locally decrypted copy of your exe via `W2_UNPACKED=...`).

Credits: framework (AC2VR / DA2VR, XrBridge, vrkit) from the uploaded AC2 VR mod; CE camera tables by Heebo and the
original free-camera table author; the 6DOF head-tracking mod (camera hook site); TefMeister's `witcher-2-vr`
research (SteamStub 2.1, Z-up camera, User.ini keys, render thread); Steamless by atom0s (the decryption method used
locally for analysis); Dear ImGui, MinHook.

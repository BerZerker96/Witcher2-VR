// check_fov.cpp - the foveated mask / fill shader logic (src/w2fov.cpp kZone/kMaskPs/kFillPs), replicated in float:
// every pixel the fill reads from must be one the mask kept (shaded), for any centre, size and ring setting.
#include <cstdio>
#include <cmath>
static float cx, cy, unit, inner, outer;
static float Block(float px, float py) { float dx = (px + 0.5f - cx) * unit, dy = (py + 0.5f - cy) * unit; float d = sqrtf(dx*dx + dy*dy); return d < inner ? 1 : (d < outer ? 2 : 4); }
static bool Kept(float px, float py) { float b = Block(px, py); float rx = fmodf(px, b), ry = fmodf(py, b); return !(rx*rx + ry*ry > 0.5f); }
int main() {
    long bad = 0, masked = 0, total = 0; int cases = 0;
    const int sizes[][2] = { {2448, 2448}, {1832, 1920}, {3840, 3744}, {1001, 777} };
    const float rings[][2] = { {0.70f, 1.10f}, {0.55f, 0.90f}, {0.42f, 0.70f}, {0.05f, 0.10f}, {0.3f, 2.0f} };
    const float cents[][2] = { {0.5f, 0.5f}, {0.43f, 0.52f}, {0.57f, 0.47f}, {0.13f, 0.91f} };
    for (auto& sz : sizes) for (auto& r : rings) for (auto& c : cents) {
        cases++; int w = sz[0], h = sz[1]; cx = c[0] * w; cy = c[1] * h; unit = 2.f / h; inner = r[0]; outer = r[1];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            float px = x, py = y; total++;
            if (Kept(px, py)) continue;
            masked++;
            float b = Block(px, py); float ox = px - fmodf(px, b), oy = py - fmodf(py, b);
            float b2 = Block(ox, oy); if (b2 > b) { ox = px - fmodf(px, b2); oy = py - fmodf(py, b2); b = b2; }
            float b3 = Block(ox, oy); if (b3 > b) { ox = px - fmodf(px, b3); oy = py - fmodf(py, b3); b = b3; }
            if (!Kept(ox, oy) || ox >= w || oy >= h) { if (bad < 5) printf("  bad: %dx%d (%d,%d) -> (%g,%g)\n", w, h, x, y, ox, oy); bad++; }
        }
    }
    // balanced preset on a 2448x2448 eye: share of pixels whose shading is skipped
    cx = cy = 1224; unit = 2.f / 2448; inner = 0.55f; outer = 0.90f; long m = 0;
    for (int y = 0; y < 2448; y++) for (int x = 0; x < 2448; x++) if (!Kept(x, y)) m++;
    printf("check_fov: %d layouts, %ld pixels, %ld masked, %ld fills from an unshaded pixel; balanced preset skips %.0f%% of pixels\n",
           cases, total, masked, bad, 100.0 * m / (2448.0 * 2448));
    return bad ? 1 : 0;
}

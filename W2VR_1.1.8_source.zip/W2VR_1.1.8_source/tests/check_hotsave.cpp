// check_hotsave.cpp - hotkey options in the VR panel's option list (vrkit_options): both bindings are written to the
// config (keyboard under its *_key name, controller under *_pad), a binding moves off any other function, reset / clear
#include "vrkit_options.h"
#include <cstdio>
#include <string>
static int fails = 0, n = 0;
#define CHECK(c, m) do { n++; if (!(c)) { fails++; printf("FAIL: %s\n", m); } } while (0)
static std::string Read(const char* p) { std::string s; if (FILE* f = fopen(p, "rb")) { char b[4096]; size_t k; while ((k = fread(b, 1, sizeof b, f)) > 0) s.append(b, k); fclose(f); } return s; }
int main() {
    using namespace vrkit;
    std::string fpK = "end", fpP = "", rcK = "home", rcP = "", shK = "", shP = "";
    auto& o = Options::Get();
    o.AddHotkey("Hotkeys", "first_person_key", "first_person_pad", "First person", &fpK, &fpP);
    o.AddHotkey("Hotkeys", "recenter_key", "recenter_pad", "Recenter", &rcK, &rcP);
    o.AddHotkey("Hotkeys", "screenshot_key", "screenshot_pad", "Screenshot", &shK, &shP).defaultText = "delete";
    Option& fp = o.All()[0]; Option& rc = o.All()[1]; Option& sh = o.All()[2];   // (references from Add* move when the list grows)
    const char* path = "build/hotsave_test.txt";
    { FILE* f = fopen(path, "wb"); fputs("# my config\nfirst_person_key = end\nworld_scale = 1.00\n", f); fclose(f); }
    std::wstring wpath(path, path + strlen(path));
    o.SetBinding(fp, true, "back+a");
    CHECK(fpP == "back+a" && o.Dirty(), "controller binding set");
    std::string moved = o.SetBinding(rc, false, "end");
    CHECK(rcK == "end" && fpK.empty() && moved == "First person", "same key moves off the other function");
    CHECK(o.Save(wpath), "saved");
    std::string t = Read(path);
    CHECK(t.find("# my config") == 0 && t.find("world_scale = 1.00") != std::string::npos, "other lines kept");
    CHECK(t.find("first_person_key = \n") != std::string::npos, "cleared key written in place");
    CHECK(t.find("first_person_pad = back+a") != std::string::npos, "controller binding saved");
    CHECK(t.find("recenter_key = end") != std::string::npos && t.find("recenter_pad = ") != std::string::npos, "new keys appended");
    CHECK(!o.Dirty(), "clean after save");
    o.Reset(sh); CHECK(shK == "delete", "reset to the factory default");
    o.Clear(fp, 2); CHECK(fpP.empty(), "clear controller only");
    o.SetBinding(sh, true, "lb+rb"); o.Clear(sh, 3); CHECK(shK.empty() && shP.empty(), "clear both");
    o.Save(wpath); t = Read(path);
    CHECK(t.find("screenshot_key = \n") != std::string::npos && t.find("first_person_pad = \n") != std::string::npos, "cleared bindings saved");
    size_t c = 0, p = 0; while ((p = t.find("recenter_key", p)) != std::string::npos) { c++; p++; } CHECK(c == 1, "no duplicate lines after a second save");
    {   // the panel's own binding: rebindable, never cleared, never taken by another function
        std::string mk = "insert", mp = "ls+rs";
        o.AddHotkey("Hotkeys", "menu_key", "menu_pad", "Open / close this panel", &mk, &mp);
        Option& m = o.All().back(); m.keepBound = true; m.defaultText = "insert"; m.defaultText2 = "ls+rs";
        Option& f2 = o.All()[0];
        o.Clear(m, 3); CHECK(mk == "insert" && mp == "ls+rs", "panel binding cannot be cleared");
        std::string r = o.SetBinding(f2, false, "insert"); CHECK(r == "!Open / close this panel" && mk == "insert" && fpK != "insert", "another function cannot take the panel's key");
        r = o.SetBinding(f2, true, "ls+rs"); CHECK(r[0] == '!' && mp == "ls+rs", "nor its buttons");
        o.SetBinding(m, false, "f1"); CHECK(mk == "f1", "panel binding can be changed");
        o.Reset(m); CHECK(mk == "insert" && mp == "ls+rs", "and reset"); }
    printf("check_hotsave: %d/%d passed\n", n - fails, n);
    return fails ? 1 : 0;
}

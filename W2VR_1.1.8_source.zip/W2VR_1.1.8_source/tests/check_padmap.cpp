// check_padmap.cpp - DirectInput controllers in the Xbox layout (src/w2padmap.h)
#include "w2padmap.h"
#include <cstdio>
using namespace w2padmap;
static int fails = 0, n = 0;
#define CHECK(c, m) do { n++; if (!(c)) { fails++; printf("FAIL: %s\n", m); } } while (0)
int main() {
    // hat: the 8 directions, the bands around the diagonals, centred
    CHECK(Pov(0) == Up && Pov(9000) == Right && Pov(18000) == Down && Pov(27000) == Left, "4 directions");
    CHECK(Pov(4500) == (Up | Right) && Pov(13500) == (Down | Right) && Pov(22500) == (Down | Left) && Pov(31500) == (Up | Left), "diagonals give both (gave none)");
    CHECK(Pov(1000) == Up && Pov(3000) == (Up | Right) && Pov(8000) == Right && Pov(35000) == Up, "bands");
    CHECK(Pov(0xFFFFFFFF) == 0 && Pov(0xFFFF) == 0 && Pov(36000) == 0, "centred");
    bool everyAngle = true; for (uint32_t a = 0; a < 36000; a += 50) if (!Pov(a)) everyAngle = false;
    CHECK(everyAngle, "every angle gives a direction");
    // layouts: Cross / bottom = A everywhere
    Layout s = ForLayout(1), g = ForLayout(0), t = ForLayout(2);
    CHECK(s.btn[0] == 1 && s.btn[1] == 2 && s.btn[2] == 0 && s.btn[3] == 3 && s.back2 == 13, "PlayStation: Cross A, Circle B, Square X, Triangle Y, touchpad Back");
    CHECK(s.btn[6] == 8 && s.btn[7] == 9 && s.btn[8] == 10 && s.btn[9] == 11 && s.lt == 6 && s.rt == 7, "PlayStation: Share Options L3 R3 L2 R2");
    CHECK(t.btn[0] == 0 && t.btn[1] == 1 && t.btn[2] == 2 && t.btn[3] == 3 && t.lt == 6 && t.rt == 7, "Nintendo by position: B->A, A->B, Y->X, X->Y, ZL ZR");
    CHECK(g.btn[0] == 1 && g.btn[2] == 0 && g.btn[4] == 4 && g.btn[5] == 5, "generic D-input mode: 2 = A, 1 = X");
    // triggers
    CHECK(Trigger(-32768) == 0 && Trigger(32767) == 255 && Trigger(0) == 128, "axis trigger");
    uint8_t lt, rt;
    SharedZ(0, lt, rt); CHECK(lt == 0 && rt == 0, "shared Z at rest");
    SharedZ(4000, lt, rt); CHECK(lt == 0 && rt == 0, "shared Z dead zone");
    SharedZ(32767, lt, rt); CHECK(lt == 255 && rt == 0, "shared Z left full");
    SharedZ(-32768, lt, rt); CHECK(lt == 0 && rt == 255, "shared Z right full");
    SharedZ(20000, lt, rt); CHECK(lt > 100 && lt < 160 && rt == 0, "shared Z half");
    // which device
    CHECK(Score(true, false, 0x054C) > Score(true, false, 0x1234) && Score(true, false, 0) > Score(false, true, 0x057E) && Score(false, true, 0) > Score(false, false, 0), "gamepads first");
    Picker p; bool open[4] = { true, true, false, false }, act[4] = {};
    CHECK(p.Step(open, act, 10) == 0, "first open by default");
    act[1] = true; CHECK(p.Step(open, act, 20) == 1, "the one pressed wins");
    act[1] = false; CHECK(p.Step(open, act, 30) == 1, "stays when idle");
    act[0] = true; CHECK(p.Step(open, act, 40) == 0, "switches to the other when used");
    open[0] = false; act[0] = false; CHECK(p.Step(open, act, 50) == 1, "unplugged: the other");
    // activity is a change, not a level: an axis resting at an end (throttle, pedal) never counts
    Pad rest = { 0, 0, 0, 0, 32767, 0, 0 }, rest2 = rest; Pad press = rest; press.b = 0x1000; Pad moved = rest; moved.lx = 20000;
    CHECK(!Used(rest2, rest), "axis held at an end is not use");
    CHECK(Used(press, rest) && !Used(press, press), "a press is use, holding it is not");
    CHECK(Used(moved, rest) && !Used({ 0, 0, 0, 3000, 32767, 0, 0 }, rest), "a clear stick move is use, drift is not");
    CHECK(SharedZPlausible(0) && SharedZPlausible(-3000) && !SharedZPlausible(-32768) && !SharedZPlausible(32767), "shared Z only when Z rests centred");
    printf("check_padmap: %d/%d passed\n", n - fails, n);
    return fails ? 1 : 0;
}

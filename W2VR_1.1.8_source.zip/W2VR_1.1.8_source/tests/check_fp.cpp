// check_fp.cpp - first-person cutscene detection and blend (src/w2fp.h)
#include "w2fp.h"
#include <cstdio>
#include <cmath>
static int fails = 0, n = 0;
#define CHECK(c, m) do { n++; if (!(c)) { fails++; printf("FAIL: %s\n", m); } } while (0)
static void Run(w2fp::State& s, float fov, float secs, bool menu = false, bool want = true, bool cut = true, float blend = 0.35f) {
    for (float t = 0; t < secs; t += 1.f / 60) s.Update(fov, menu, want, cut, blend, 1.f / 60);
}
int main() {
    { w2fp::State s; Run(s, 60, 1); CHECK(fabsf(s.gameplayFov - 60) < 0.01f, "learns gameplay FOV"); CHECK(s.Weight() > 0.999f, "full weight in gameplay");
      Run(s, 45, 0.15f); CHECK(!s.cinematic, "short FOV change (<0.25 s) is not a cutscene");
      Run(s, 45, 0.2f); CHECK(s.cinematic, "held FOV change is a cutscene");
      Run(s, 45, 0.5f); CHECK(s.Weight() < 0.001f, "first person fades out in cutscene");
      Run(s, 60, 0.3f); CHECK(s.cinematic, "brief return does not resume");
      Run(s, 60, 0.3f); CHECK(!s.cinematic, "0.5 s back at gameplay FOV resumes");
      Run(s, 60, 0.5f); CHECK(s.Weight() > 0.999f, "first person back"); }
    { w2fp::State s; Run(s, 60, 1); Run(s, 45, 1, true, true, true); CHECK(!s.cinematic, "menu FOV ignored");
      Run(s, 70, 1); CHECK(fabsf(s.gameplayFov - 70) < 0.5f, "re-learned after menu closes"); CHECK(!s.cinematic, "no false cutscene after FOV setting change"); }
    { w2fp::State s; Run(s, 60, 1); Run(s, 45, 1, false, true, false); CHECK(s.Weight() > 0.999f, "cutscene_off=false keeps first person"); }
    { w2fp::State s; Run(s, 40, 1); Run(s, 60, 14); CHECK(s.cinematic, "still treated as cinematic before 15 s");
      Run(s, 60, 1.5f); CHECK(!s.cinematic && fabsf(s.gameplayFov - 60) < 0.5f, "recovers when first learned FOV was a cutscene's"); }
    { w2fp::State s; Run(s, 60, 1, false, false); CHECK(s.Weight() == 0, "off when not wanted");
      s.Update(60, false, true, true, 0.35f, 0.175f); float w = s.Weight(); CHECK(w > 0.4f && w < 0.6f, "halfway at half the blend time");
      s.Update(60, false, true, true, 0.35f, 0.02f); CHECK(s.Weight() > w, "monotonic");
      w2fp::State z; z.Update(60, false, true, true, 0, 0.016f); CHECK(z.Weight() == 1, "blend 0 = instant"); }
    { w2fp::State s; Run(s, 60, 1); s.Update(60, false, true, true, 0.35f, 5.f); CHECK(s.Weight() > 0.999f, "huge dt clamped, no NaN");
      s.Update(0, false, true, true, 0.35f, 0.016f); CHECK(fabsf(s.gameplayFov - 60) < 0.5f, "invalid FOV ignored"); }
    printf("check_fp: %d/%d passed\n", n - fails, n);
    return fails ? 1 : 0;
}

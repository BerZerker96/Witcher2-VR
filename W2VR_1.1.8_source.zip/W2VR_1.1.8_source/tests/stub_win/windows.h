// minimal stand-in so vrkit_options.cpp builds on Linux for tests/check_hotsave.cpp
#pragma once
#include <cstdio>
#include <string>
inline void OutputDebugStringA(const char* s) { fputs(s, stderr); }
inline FILE* _wfopen(const wchar_t* p, const wchar_t* m) {
    std::string a, b; for (; *p; ++p) a += (char)*p; for (; *m; ++m) b += (char)*m; return fopen(a.c_str(), b.c_str());
}

// check_bind.cpp - hotkey bindings (src/w2bind.h): parse / write, firing, hiding from the game, capture
#include "w2bind.h"
#include <cstdio>
using namespace w2bind;
static int fails = 0, n = 0;
#define CHECK(c, m) do { n++; if (!(c)) { fails++; printf("FAIL: %s\n", m); } } while (0)
int main() {
    CHECK(KeyParse("end").vk == 0x23 && !KeyParse("end").mods, "end");
    CHECK(KeyWrite(KeyParse("Ctrl + F7")) == "ctrl+f7", "ctrl+f7 canon");
    CHECK(KeyWrite(KeyParse("ctrl+f7"), true) == "Ctrl + F7", "ctrl+f7 shown");
    CHECK(KeyParse("shift+alt+k").mods == (Shift | Alt) && KeyParse("shift+alt+k").vk == 'K', "mods + letter");
    CHECK(KeyParse("").Empty() && KeyParse("none").Empty() && KeyParse("bogus").Empty() && KeyParse("ctrl").Empty(), "empty / invalid");
    CHECK(KeyParse("0x2d").vk == 0x2D && KeyWrite(KeyParse("0x2d")) == "insert", "hex (old configs)");
    CHECK(KeyParse("pageup").vk == 0x21 && KeyParse("delete").vk == 0x2E && KeyParse("home").vk == 0x24 && KeyParse("f8").vk == 0x77, "legacy names");
    CHECK(KeyWrite(KeyParse("numplus")) == "numplus" && KeyWrite(KeyParse("ctrl+numplus"), true) == "Ctrl + Num +", "num plus");
    { int k; const KeyName* t = KeyNames(&k); bool ok = true; for (int i = 0; i < k; i++) ok &= KeyParse(t[i].cfg).vk == t[i].vk && KeyWrite(KeyParse(t[i].cfg)) == t[i].cfg; CHECK(ok, "every key name round-trips"); }
    for (int c = 'A'; c <= 'Z'; c++) { char s[2] = { (char)c, 0 }; if (KeyParse(s).vk != c) { CHECK(false, "letters"); break; } }
    CHECK(PadParse("Back+A") == (0x20u | 0x1000u) && PadWrite(PadParse("a+back")) == "a+back", "pad canon order");
    CHECK(PadWrite(PadParse("lt+rt+y"), true) == "Y + LT + RT", "pad shown");
    CHECK(PadParse("l3+r3") == (0x40u | 0x80u) && PadParse("select") == 0x20u && PadParse("up") == 1u, "pad aliases");
    CHECK(PadParse("a+b+x+y+lb") == 0 && PadParse("a+zz") == 0 && PadParse("") == 0, "pad invalid / too many");
    { int k; const PadName* t = PadNames(&k); bool ok = true; for (int i = 0; i < k; i++) ok &= PadParse(t[i].cfg) == t[i].bit; CHECK(ok, "every pad name"); }
    {   PadMatcher m; std::vector<uint32_t> b = { 0x1000 /*A*/, 0x0100 | 0x1000 /*LB+A*/, 0x20 /*Back*/ };
        auto f = m.Step(0x1000, b); CHECK(f.size() == 1 && f[0] == 0, "A fires");
        f = m.Step(0x1000, b); CHECK(f.empty(), "held: no repeat");
        f = m.Step(0, b); f = m.Step(0x0100, b); CHECK(f.empty(), "LB alone: nothing");
        f = m.Step(0x1100, b); CHECK(f.size() == 1 && f[0] == 1, "LB+A fires, not A");
        f = m.Step(0x0100, b); f = m.Step(0x1100, b); CHECK(f.size() == 1 && f[0] == 1, "A again with LB held: combo again");
        f = m.Step(0x20 | 0x1100, b); CHECK(f.size() == 1 && f[0] == 2, "Back while combo held");
        f = m.Step(PadLT, { PadLT | PadRT }); f = m.Step(PadLT | PadRT, { PadLT | PadRT }); CHECK(f.size() == 1, "triggers combo"); }
    {   PadHider h; std::vector<uint32_t> b = { 0x0100 | 0x1000, 0x4 };
        CHECK(h.Step(0x0100, b) == 0, "first button of a combo reaches the game");
        CHECK(h.Step(0x1100, b) == 0x1100, "combo complete: hidden");
        CHECK(h.Step(0x1000, b) == 0x1000, "A still hidden after LB released");
        CHECK(h.Step(0, b) == 0, "released: nothing hidden");
        CHECK(h.Step(0x4, b) == 0x4, "single bound button always hidden");
        CHECK(h.Step(0x1000, b) == 0, "unbound A not hidden"); }
    {   PadCapture c; c.Begin(0x1000);          // started with A (the panel's accept) held
        CHECK(c.Step(0x1000) == 0, "held start button ignored");
        CHECK(c.Step(0) == 0, "released: still waiting");
        CHECK(c.Step(0x20) == 0 && c.Step(0x1020) == 0, "collecting Back+A");
        CHECK(c.Step(0x1000) == 0, "partly released: waiting");
        CHECK(c.Step(0) == (0x20u | 0x1000u), "Back+A captured");
        c.Begin(0); c.Step(0x1000); CHECK(c.Step(0) == 0x1000, "A alone after a fresh start");
        c.Begin(0); c.Step(PadLT | PadRT | 0x8000); CHECK(c.Step(0) == (PadLT | PadRT | 0x8000), "LT+RT+Y");
        c.Begin(0); c.Step(0x1000 | 0x2000 | 0x4000 | 0x8000); c.Step(0x1000 | 0x2000 | 0x4000 | 0x8000 | 0x100); CHECK(PadCount(c.Step(0)) == 4, "at most 4 buttons"); }
    {   CHECK(KeyParse("mouse4").vk == 5 && KeyWrite(KeyParse("ctrl+mouse5"), true) == "Ctrl + Mouse 5" && MouseButtonOfVk(4) == 2, "mouse buttons");
        std::vector<Key> b = { KeyParse("end"), KeyParse("ctrl+end"), KeyParse("shift+f7") };
        CHECK(PickKey(b, 0x23, 0) == 0, "plain end");
        CHECK(PickKey(b, 0x23, Ctrl) == 1, "ctrl+end picks the exact binding");
        CHECK(PickKey(b, 0x23, Shift) == 0, "shift held: plain end still fires");
        CHECK(PickKey(b, 0x76, 0) == -1 && PickKey(b, 0x76, Shift) == 2 && PickKey(b, 0x76, Ctrl) == -1, "shift+f7 only with shift");
        CHECK(KeyHidden(1, Shift) && KeyHidden(1, 0) && !KeyHidden(1u << Ctrl, 0) && KeyHidden(1u << Ctrl, Ctrl) && !KeyHidden(0, 0), "hiding follows firing");
        CHECK(!MenuKeyOk(0x0D) && !MenuKeyOk(0x26) && !MenuKeyOk(0x2E) && !MenuKeyOk(5) && MenuKeyOk(0x2D) && MenuKeyOk(0x70), "panel key rules");
        CHECK(!MenuPadOk(0x1000) && !MenuPadOk(0x0001) && MenuPadOk(0x20) && MenuPadOk(0x40 | 0x80) && MenuPadOk(0x1000 | 0x20) && MenuPadOk(PadLT) && !MenuPadOk(0), "panel button rules"); }
    printf("check_bind: %d/%d passed\n", n - fails, n);
    return fails ? 1 : 0;
}

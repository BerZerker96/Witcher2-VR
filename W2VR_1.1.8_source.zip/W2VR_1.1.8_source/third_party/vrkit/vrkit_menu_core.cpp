#include "vrkit_menu_core.h"
#include "vrkit_options.h"
#include <windows.h>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cctype>
#include "imgui.h"

namespace vrkit { namespace menu { namespace core {

namespace {
Settings g_s;
ImGuiContext* g_im = nullptr;
ImFont* g_fBody = nullptr; ImFont* g_fTitle = nullptr; ImFont* g_fTab = nullptr; ImFont* g_fHead = nullptr; ImFont* g_fSmall = nullptr;
bool g_open = false;
int g_page = 0, g_sel = 0;
// hotkey capture (the option index being bound, -1 = none) and a short note after a binding moved from another one
int g_capture = -1; DWORD g_capStart = 0; std::string g_note; DWORD g_noteTick = 0;
// mouse: cursor in panel pixels; shown once the mouse moves or clicks, hidden again by pad / keyboard navigation
float g_mx = 0, g_my = 0, g_mWheel = 0; bool g_mVis = false, g_mMoved = false; unsigned g_mBtn = 0, g_mPress = 0;
bool g_manualScroll = false;
bool g_onX = false;            // pad / keys: the focus is on the selected hotkey row's clear button (Left / Right)   // the wheel moved the list: do not pull it back to the selection until pad / keys navigate
LARGE_INTEGER g_qpf, g_last;

std::vector<int> PageItems(int page) {
    auto& opts = Options::Get().All();
    auto pages = Options::Get().Pages();
    std::vector<int> r;
    if (pages.empty()) return r;
    page = (std::min)(page, (int)pages.size() - 1);
    for (int k = 0; k < (int)opts.size(); ++k)
        if (opts[k].page == pages[page] && (!opts[k].visible || opts[k].visible())) r.push_back(k);
    return r;
}

void SaveNow() {
    if (Options::Get().Dirty() && !g_s.configPath.empty() && Options::Get().Save(g_s.configPath)) Log("vrkit: settings saved");
}
void BeginCapture(int idx) {
    auto& opts = Options::Get().All();
    if (idx < 0 || idx >= (int)opts.size() || opts[idx].type != OptType::Hotkey) return;
    g_capture = idx; g_capStart = GetTickCount(); g_note.clear();
    const HotkeyHost& h = GetHotkeyHost();
    if (h.begin) h.begin(opts[idx]);
}
void EndCapture(int r, const std::string& kb, const std::string& pad) {
    auto& opts = Options::Get().All();
    int idx = g_capture; g_capture = -1;
    if (idx < 0 || idx >= (int)opts.size() || r < 0) return;
    Option& o = opts[idx];
    std::string moved;
    if (r == 1) moved = Options::Get().SetBinding(o, false, kb);
    else if (r == 2) moved = Options::Get().SetBinding(o, true, pad);
    else if (r == 3) Options::Get().Clear(o, 3);
    if (!moved.empty() && moved[0] == '!') { g_note = "Not set: it opens this panel (\"" + moved.substr(1) + "\") - pick another."; g_noteTick = GetTickCount(); }
    else if (!moved.empty()) { g_note = "Taken off \"" + moved + "\" (one binding, one function)."; g_noteTick = GetTickCount(); }
    SaveNow();   // bindings are saved the moment they are set
}
void OnOpen() { g_mx = g_s.texW * 0.5f; g_my = g_s.texH * 0.55f; g_mVis = false; g_mPress = 0; g_mWheel = 0; g_manualScroll = false; g_capture = -1; }

void Close() {
    g_open = false;
    g_capture = -1; g_mVis = false; g_onX = false;
    input::SetBlocking(false);
    if (Options::Get().Dirty() && !g_s.configPath.empty()) {
        if (Options::Get().Save(g_s.configPath)) Log("vrkit: settings saved");
    }
}

void Navigate(uint32_t b) {
    auto pages = Options::Get().Pages();
    if (pages.empty()) return;
    if (b & input::PagePrev) { g_page = (g_page + (int)pages.size() - 1) % (int)pages.size(); g_sel = 0; }
    if (b & input::PageNext) { g_page = (g_page + 1) % (int)pages.size(); g_sel = 0; }
    auto items = PageItems(g_page);
    if (items.empty()) return;
    int n = (int)items.size();
    if (b & (input::Up | input::Down | input::PagePrev | input::PageNext)) g_onX = false;
    if (b & input::Up) g_sel = (g_sel + n - 1) % n;
    if (b & input::Down) g_sel = (g_sel + 1) % n;
    g_sel = (std::min)(g_sel, n - 1);
    Option& o = Options::Get().All()[items[g_sel]];
    if (o.type == OptType::Hotkey) {   // A: bind (or, on the clear button, clear), Left / Right: to / from the clear button, X: clear, Y: default (saved at once)
        if ((b & input::Left) && !o.keepBound) g_onX = true;
        if (b & input::Right) g_onX = false;
        if (b & input::Accept) { if (g_onX) { Options::Get().Clear(o, 3); SaveNow(); } else BeginCapture(items[g_sel]); return; }
        if (b & input::Clear) { Options::Get().Clear(o, 3); SaveNow(); }
        if (b & input::Reset) { Options::Get().Reset(o); SaveNow(); }
        return;
    }
    if (b & input::Left) Options::Get().Step(o, -1);
    if (b & input::Right) Options::Get().Step(o, +1);
    if (b & input::Accept) Options::Get().Activate(o);
    if (b & input::Reset) Options::Get().Reset(o);
}
} // namespace

bool InitImGui(const Settings& s) {
    if (g_im) return true;
    g_s = s;
    input::Configure(s.input);
    input::InstallHooks();
    IMGUI_CHECKVERSION();
    g_im = ImGui::CreateContext();
    ImGui::SetCurrentContext(g_im);
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr; io.LogFilename = nullptr;
    io.DisplaySize = ImVec2((float)s.texW, (float)s.texH);
    // a clear UI font from Windows at the requested size; ImGui's built-in font as fallback
    float os = s.fontOversample > 0 ? s.fontOversample : 1.f;
    ImFont* f = nullptr;
    wchar_t win[MAX_PATH]; char path[MAX_PATH * 2];
    if (GetWindowsDirectoryW(win, MAX_PATH)) {
        // witcher theme: Bahnschrift (Windows 10+), a condensed gothic sans close to the game's own Bell Gothic and very
        // legible at headset resolution; Segoe UI / Arial otherwise
        std::vector<const wchar_t*> faces;
        if (s.theme == 1) faces.push_back(L"\\Fonts\\bahnschrift.ttf");
        faces.push_back(L"\\Fonts\\segoeui.ttf"); faces.push_back(L"\\Fonts\\arial.ttf");
        for (const wchar_t* name : faces) {
            std::wstring p = std::wstring(win) + name;
            WideCharToMultiByte(CP_UTF8, 0, p.c_str(), -1, path, sizeof(path), nullptr, nullptr);
            if (GetFileAttributesW(p.c_str()) != INVALID_FILE_ATTRIBUTES && (f = io.Fonts->AddFontFromFileTTF(path, s.fontPx * os))) {
                g_fSmall = io.Fonts->AddFontFromFileTTF(path, s.fontPx * 0.80f * os);   // help text
                break;
            }
        }
    }
    if (!f) { ImFontConfig fc; fc.SizePixels = s.fontPx * os; f = io.Fonts->AddFontDefault(&fc); }
    g_fBody = g_fTitle = g_fTab = g_fHead = f;
    if (!g_fSmall) g_fSmall = f;
    if (s.theme == 1 && GetWindowsDirectoryW(win, MAX_PATH)) {
        // serif faces for the title and the page names (Palatino / Georgia / Constantia ship with Windows)
        for (const wchar_t* name : { L"\\Fonts\\palab.ttf", L"\\Fonts\\georgiab.ttf", L"\\Fonts\\constanb.ttf", L"\\Fonts\\pala.ttf", L"\\Fonts\\georgia.ttf" }) {
            std::wstring p = std::wstring(win) + name;
            if (GetFileAttributesW(p.c_str()) == INVALID_FILE_ATTRIBUTES) continue;
            WideCharToMultiByte(CP_UTF8, 0, p.c_str(), -1, path, sizeof(path), nullptr, nullptr);
            ImFont* t = io.Fonts->AddFontFromFileTTF(path, s.fontPx * 1.40f * os);
            ImFont* b = io.Fonts->AddFontFromFileTTF(path, s.fontPx * 0.82f * os);
            ImFont* h = io.Fonts->AddFontFromFileTTF(path, s.fontPx * 0.74f * os);
            if (t && b && h) { g_fTitle = t; g_fTab = b; g_fHead = h; }
            break;
        }
    }
    io.FontGlobalScale = 1.f / os;
    ImGuiStyle& st = ImGui::GetStyle();
    st.WindowRounding = 14.f; st.WindowBorderSize = 0.f; st.WindowPadding = ImVec2(0, 0);
    st.Colors[ImGuiCol_WindowBg] = ImVec4(0.035f, 0.035f, 0.045f, s.backgroundAlpha);   // dark, semi-transparent
    QueryPerformanceFrequency(&g_qpf); QueryPerformanceCounter(&g_last);
    return true;
}

void ShutdownImGui() {
    if (g_im) { ImGui::DestroyContext(g_im); g_im = nullptr; }
    g_open = false;
}

const Settings& Get() { return g_s; }

bool UpdateInput() {
    if (!g_im) return false;
    static int rehook = 0;
    if ((++rehook % 300) == 1) input::InstallHooks();   // the game may load XInput late
    uint32_t b = input::Poll();
    if (g_open && g_capture >= 0) {   // binding a hotkey: every key and button goes to the capture, nothing navigates
        std::string kb, pad; const HotkeyHost& h = GetHotkeyHost();
        int r = h.poll ? h.poll(kb, pad) : -1;
        if (r == 0 && GetTickCount() - g_capStart > 8000) r = -1;
        if (r != 0) EndCapture(r, kb, pad);
        ImGui::SetCurrentContext(g_im);
        return true;
    }
    if (b & input::Toggle) { if (g_open) Close(); else { g_open = true; OnOpen(); input::SetBlocking(true); } b &= ~input::Toggle; }
    else if (g_open && (b & input::Back)) { Close(); return false; }
    if (!g_open) return false;
    if (b & (input::Up | input::Down | input::Left | input::Right | input::PagePrev | input::PageNext | input::Accept)) { g_mVis = false; g_manualScroll = false; }
    Navigate(b);
    ImGui::SetCurrentContext(g_im);
    return true;
}

static void BuildDefault();
static void BuildWitcher();
void BuildFrame() { if (g_s.theme == 1) BuildWitcher(); else BuildDefault(); }

static void BuildDefault() {
    ImGui::SetCurrentContext(g_im);
    ImGuiIO& io = ImGui::GetIO();
    LARGE_INTEGER now; QueryPerformanceCounter(&now);
    io.DeltaTime = (std::max)(0.001f, (float)(now.QuadPart - g_last.QuadPart) / (float)g_qpf.QuadPart); g_last = now;
    io.DisplaySize = ImVec2((float)g_s.texW, (float)g_s.texH);
    ImGui::NewFrame();
    const float W = (float)g_s.texW, H = (float)g_s.texH, pad = g_s.fontPx * 0.6f;
    ImGui::SetNextWindowPos(ImVec2(0, 0)); ImGui::SetNextWindowSize(ImVec2(W, H));
    ImGui::Begin("##vrkit", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoScrollbar);
    // theme: near-black panel, crimson accents
    const ImU32 cText = IM_COL32(238, 234, 232, 255), cDim = IM_COL32(150, 140, 140, 255), cAcc = IM_COL32(255, 92, 82, 255),
                cSel = IM_COL32(140, 18, 22, 210), cWarn = IM_COL32(255, 190, 90, 255), cRed = IM_COL32(200, 28, 34, 255),
                cRedDark = IM_COL32(70, 10, 14, 235), cLine = IM_COL32(150, 24, 30, 200);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    // title band
    float bandH = g_s.fontPx * 1.9f;
    dl->AddRectFilledMultiColor(ImVec2(0, 0), ImVec2(W, bandH), IM_COL32(120, 12, 18, 245), IM_COL32(30, 4, 6, 235), IM_COL32(30, 4, 6, 235), IM_COL32(120, 12, 18, 245));
    dl->AddRectFilled(ImVec2(0, bandH - 4), ImVec2(W, bandH), cRed);
    float y = (bandH - g_s.fontPx) * 0.5f - 2;
    dl->AddText(ImVec2(pad, y), IM_COL32(255, 255, 255, 255), g_s.title.c_str());
    if (g_s.statusLine) { std::string st = g_s.statusLine(); ImVec2 ts = ImGui::CalcTextSize(st.c_str()); dl->AddText(ImVec2(W - pad - ts.x, y), IM_COL32(235, 190, 190, 255), st.c_str()); }
    y = bandH + g_s.fontPx * 0.45f;
    // page tabs: red pills
    auto pages = Options::Get().Pages();
    float x = pad;
    for (int p = 0; p < (int)pages.size(); ++p) {
        ImVec2 ts = ImGui::CalcTextSize(pages[p].c_str());
        ImVec2 a(x - 14, y - 6), b(x + ts.x + 14, y + ts.y + 6);
        if (p == g_page) { dl->AddRectFilled(a, b, cRed, 8.f); dl->AddText(ImVec2(x, y), IM_COL32(255, 255, 255, 255), pages[p].c_str()); }
        else { dl->AddRectFilled(a, b, cRedDark, 8.f); dl->AddRect(a, b, cLine, 8.f, 0, 2.f); dl->AddText(ImVec2(x, y), cDim, pages[p].c_str()); }
        x += ts.x + 40;
    }
    y += g_s.fontPx * 1.6f;
    dl->AddLine(ImVec2(pad, y - 8), ImVec2(W - pad, y - 8), cLine, 2.f);
    // rows (scrolled so the selection stays visible)
    auto items = PageItems(g_page);
    float rowH = g_s.fontPx * 1.35f, listTop = y, listBottom = H - g_s.fontPx * 5.2f;
    int visibleRows = (std::max)(1, (int)((listBottom - listTop) / rowH));
    int first = (std::max)(0, (std::min)(g_sel - visibleRows / 2, (int)items.size() - visibleRows));
    auto& opts = Options::Get().All();
    for (int r = first; r < (int)items.size() && r < first + visibleRows; ++r) {
        Option& o = opts[items[r]];
        float ry = listTop + (r - first) * rowH;
        if (r == g_sel) {
            dl->AddRectFilled(ImVec2(pad * 0.5f, ry - 4), ImVec2(W - pad * 0.5f, ry + rowH - 6), cSel, 6.f);
            dl->AddRectFilled(ImVec2(pad * 0.5f, ry - 4), ImVec2(pad * 0.5f + 7, ry + rowH - 6), cAcc, 3.f);
        }
        dl->AddText(ImVec2(pad, ry), cText, o.label.c_str());
        std::string v = Options::Get().DisplayText(o);
        bool adjustable = o.type != OptType::Action;
        std::string shown = o.type == OptType::Action ? "[ run ]" : (r == g_sel && adjustable ? "<  " + v + "  >" : v);
        ImVec2 vs = ImGui::CalcTextSize(shown.c_str());
        float vx = W - pad - vs.x;
        if (o.needsRestart) {
            const char* rs = "restart";
            ImVec2 rsz = ImGui::CalcTextSize(rs);
            dl->AddText(ImVec2(vx - rsz.x - 24, ry), cWarn, rs);
        }
        dl->AddText(ImVec2(vx, ry), r == g_sel ? cAcc : cText, shown.c_str());
    }
    if (items.empty()) dl->AddText(ImVec2(pad, listTop), cDim, "(nothing on this page)");
    // help for the selected option + controls
    float hy = H - g_s.fontPx * 4.6f;
    dl->AddLine(ImVec2(pad, hy - 10), ImVec2(W - pad, hy - 10), cLine, 2.f);
    if (!items.empty()) {
        const Option& o = opts[items[(std::min)(g_sel, (int)items.size() - 1)]];
        std::string h = o.help;
        if (!o.key.empty()) h += (h.empty() ? "" : "   ") + std::string("[") + o.key + "]";
        ImGui::SetCursorScreenPos(ImVec2(pad, hy));
        ImGui::PushTextWrapPos(W - pad);
        ImGui::PushStyleColor(ImGuiCol_Text, cDim);
        ImGui::TextWrapped("%s", h.c_str());
        ImGui::PopStyleColor(); ImGui::PopTextWrapPos();
    }
    const char* keys = "A: change   Y: undo   LB/RB: page   B: close";
    dl->AddText(ImVec2(pad, H - g_s.fontPx * 1.4f), cDim, keys);
    ImGui::End();
    ImGui::Render();
}


// ---------------------------------------------------------------- "witcher" theme
// Dark leather-black panel, a double frame (dark bronze outside, gold hairline inside) with diamond corner studs and
// small ornaments in the middle of each edge, the title in a serif crimson, page names in gold, On/Off as red
// switches. Colours are linear-ish sRGB for the headset quad.
namespace {
inline ImU32 C(int r, int g, int b, int a = 255) { return IM_COL32(r, g, b, a); }
void Diamond(ImDrawList* dl, ImVec2 c, float r, ImU32 fill, ImU32 edge) {
    ImVec2 p[4] = { ImVec2(c.x, c.y - r), ImVec2(c.x + r, c.y), ImVec2(c.x, c.y + r), ImVec2(c.x - r, c.y) };
    dl->AddConvexPolyFilled(p, 4, fill); dl->AddPolyline(p, 4, edge, ImDrawFlags_Closed, 1.5f);
}
// corner piece: an L of two lines with a stud at the corner and a small tick
void Corner(ImDrawList* dl, ImVec2 c, float sx, float sy, float len, ImU32 gold, ImU32 bronze) {
    // stud on the frame corner, an inner gold bracket with a bronze echo, and a small diamond inside the bracket
    Diamond(dl, c, 11.f, C(150, 26, 24), gold);
    ImVec2 i(c.x + sx * 24, c.y + sy * 24);
    dl->AddLine(i, ImVec2(i.x + sx * len, i.y), gold, 2.5f);
    dl->AddLine(i, ImVec2(i.x, i.y + sy * len), gold, 2.5f);
    dl->AddLine(ImVec2(i.x + sx * 8, i.y + sy * 8), ImVec2(i.x + sx * len * 0.55f, i.y + sy * 8), bronze, 2.f);
    dl->AddLine(ImVec2(i.x + sx * 8, i.y + sy * 8), ImVec2(i.x + sx * 8, i.y + sy * len * 0.55f), bronze, 2.f);
    Diamond(dl, ImVec2(i.x + sx * len, i.y), 4.5f, gold, gold);
    Diamond(dl, ImVec2(i.x, i.y + sy * len), 4.5f, gold, gold);
    Diamond(dl, ImVec2(i.x + sx * 20, i.y + sy * 20), 5.5f, C(150, 26, 24), gold);
}
// a horizontal rule that thins out towards the ends, with a diamond in the middle
void Rule(ImDrawList* dl, float x0, float x1, float y, ImU32 gold, ImU32 bronze) {
    float m = (x0 + x1) * 0.5f;
    dl->AddRectFilledMultiColor(ImVec2(x0, y - 1), ImVec2(m, y + 1), C(0, 0, 0, 0), gold, gold, C(0, 0, 0, 0));
    dl->AddRectFilledMultiColor(ImVec2(m, y - 1), ImVec2(x1, y + 1), gold, C(0, 0, 0, 0), C(0, 0, 0, 0), gold);
    Diamond(dl, ImVec2(m, y), 6.f, bronze, gold);
}
} // namespace

namespace {
// the emblem next to the title: two crossed swords in a double ring (an original design for the panel)
void Emblem(ImDrawList* dl, ImVec2 c, float r, ImU32 steel, ImU32 gold, ImU32 red) {
    dl->AddCircleFilled(c, r, C(18, 14, 12, 235), 48);
    dl->AddCircle(c, r, steel, 48, 2.5f);
    dl->AddCircle(c, r * 0.84f, gold, 48, 1.2f);
    for (int k = 0; k < 8; k++) {   // studs on the ring
        float a = k * 3.14159265f / 4.f;
        dl->AddCircleFilled(ImVec2(c.x + cosf(a) * r * 0.92f, c.y + sinf(a) * r * 0.92f), r * 0.045f, gold, 8);
    }
    for (int sgn = -1; sgn <= 1; sgn += 2) {   // two blades crossing at the centre
        float ax = (float)sgn * 0.62f, ay = -0.78f;           // tip direction (up-left / up-right)
        ImVec2 tip(c.x + ax * r * 0.80f, c.y + ay * r * 0.80f), pom(c.x - ax * r * 0.62f, c.y - ay * r * 0.62f);
        ImVec2 n(-ay, ax);                                     // across the blade
        ImVec2 gd(c.x - ax * r * 0.30f, c.y - ay * r * 0.30f); // crossguard position
        float w = r * 0.075f;
        ImVec2 blade[4] = { ImVec2(tip.x, tip.y), ImVec2(gd.x + n.x * w, gd.y + n.y * w), ImVec2(gd.x - n.x * w, gd.y - n.y * w), ImVec2(tip.x, tip.y) };
        dl->AddConvexPolyFilled(blade, 3, steel);
        dl->AddLine(ImVec2(tip.x, tip.y), gd, C(255, 255, 255, 90), 1.f);   // fuller highlight
        dl->AddLine(ImVec2(gd.x + n.x * r * 0.22f, gd.y + n.y * r * 0.22f), ImVec2(gd.x - n.x * r * 0.22f, gd.y - n.y * r * 0.22f), gold, r * 0.07f);
        dl->AddLine(gd, pom, C(90, 60, 40), r * 0.08f);                     // grip
        dl->AddCircleFilled(pom, r * 0.07f, gold, 12);                      // pommel
    }
    dl->AddCircleFilled(c, r * 0.07f, red, 12);
}
// a tab: a plate with cut corners
void Plate(ImDrawList* dl, ImVec2 a, ImVec2 b, float cut, ImU32 fill, ImU32 edge, float th) {
    ImVec2 p[8] = { ImVec2(a.x + cut, a.y), ImVec2(b.x - cut, a.y), ImVec2(b.x, a.y + cut), ImVec2(b.x, b.y - cut),
                    ImVec2(b.x - cut, b.y), ImVec2(a.x + cut, b.y), ImVec2(a.x, b.y - cut), ImVec2(a.x, a.y + cut) };
    dl->AddConvexPolyFilled(p, 8, fill);
    dl->AddPolyline(p, 8, edge, ImDrawFlags_Closed, th);
}
// text with extra spacing between the letters (engraved small capitals for tabs and section names)
float SpacedWidth(const std::string& t, float sp) { float w = 0; for (char ch : t) { char b[2] = { ch, 0 }; w += ImGui::CalcTextSize(b).x + sp; } return t.empty() ? 0 : w - sp; }
void SpacedText(ImDrawList* dl, ImVec2 p, ImU32 col, const std::string& t, float sp) {
    for (char ch : t) { char b[2] = { ch, 0 }; dl->AddText(p, col, b); p.x += ImGui::CalcTextSize(b).x + sp; }
}
// mouse cursor in the panel's look: a forged steel pointer - dark outline, silver blade with a lit edge, gold rim and a
// crimson stud; the stud glows over anything clickable, the pointer dips while a button is held. Large (about a line of
// text) so it stays easy to find in the headset.
void Cursor(ImDrawList* dl, ImVec2 p, float s, bool hot, bool down) {
    if (down) { p.x += s * 0.03f; p.y += s * 0.03f; }
    auto P = [&](float x, float y) { return ImVec2(p.x + x * s, p.y + y * s); };
    const ImVec2 tip = P(0, 0), l = P(0, 0.94f), n = P(0.25f, 0.72f), t1 = P(0.45f, 1.10f), t2 = P(0.60f, 1.02f), n2 = P(0.40f, 0.65f), r = P(0.72f, 0.65f);
    const ImVec2 outline[] = { tip, l, n, t1, t2, n2, r };
    // soft shadow
    ImVec2 sh[7]; for (int i = 0; i < 7; i++) sh[i] = ImVec2(outline[i].x + s * 0.07f, outline[i].y + s * 0.09f);
    dl->AddTriangleFilled(sh[0], sh[1], sh[2], IM_COL32(0, 0, 0, 110)); dl->AddTriangleFilled(sh[0], sh[2], sh[6], IM_COL32(0, 0, 0, 110));
    dl->AddTriangleFilled(sh[2], sh[3], sh[4], IM_COL32(0, 0, 0, 110)); dl->AddTriangleFilled(sh[2], sh[4], sh[5], IM_COL32(0, 0, 0, 110));
    // blade: steel body, lighter left half (lit edge), tail
    const ImU32 body = down ? IM_COL32(150, 146, 140, 255) : IM_COL32(196, 194, 188, 255), lit = IM_COL32(242, 240, 232, 255), dark = IM_COL32(112, 108, 102, 255);
    dl->AddTriangleFilled(tip, l, n, lit);
    dl->AddTriangleFilled(tip, n, r, body);
    dl->AddTriangleFilled(n, t1, t2, dark); dl->AddTriangleFilled(n, t2, n2, dark);
    dl->AddLine(tip, P(0.30f, 0.62f), IM_COL32(255, 255, 250, 160), s * 0.04f);   // fuller (the blade's groove)
    // outline: black, then the gold rim
    dl->AddPolyline(outline, 7, IM_COL32(8, 6, 6, 255), ImDrawFlags_Closed, s * 0.11f);
    dl->AddPolyline(outline, 7, hot ? IM_COL32(236, 196, 110, 255) : IM_COL32(196, 162, 92, 255), ImDrawFlags_Closed, s * 0.045f);
    // crimson stud (glows over something clickable)
    ImVec2 c = P(0.24f, 0.46f);
    if (hot) dl->AddCircleFilled(c, s * 0.20f, IM_COL32(226, 54, 50, 70), 20);
    dl->AddCircleFilled(c, s * 0.10f, hot ? IM_COL32(236, 64, 56, 255) : IM_COL32(170, 22, 28, 255), 14);
    dl->AddCircle(c, s * 0.10f, IM_COL32(196, 162, 92, 255), 14, s * 0.03f);
}
std::string Upper(std::string t) { for (auto& ch : t) ch = (char)toupper((unsigned char)ch); return t; }
} // namespace

static void BuildWitcher() {
    ImGui::SetCurrentContext(g_im);
    ImGuiIO& io = ImGui::GetIO();
    LARGE_INTEGER now; QueryPerformanceCounter(&now);
    io.DeltaTime = (std::max)(0.001f, (float)(now.QuadPart - g_last.QuadPart) / (float)g_qpf.QuadPart); g_last = now;
    io.DisplaySize = ImVec2((float)g_s.texW, (float)g_s.texH);
    ImGui::NewFrame();
    const float W = (float)g_s.texW, H = (float)g_s.texH, fp = g_s.fontPx;
    ImGui::SetNextWindowPos(ImVec2(0, 0)); ImGui::SetNextWindowSize(ImVec2(W, H));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));
    ImGui::Begin("##vrkitw", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBackground);
    const int A = (int)(g_s.backgroundAlpha * 255.f + 0.5f);
    // The Witcher 2's own menus: near-black panels, worn steel ornament, crimson for what is active, white text
    const ImU32 steel = C(176, 174, 168), steelDim = C(98, 96, 92), gold = C(196, 162, 92), goldDim = C(140, 116, 70),
                text = C(232, 228, 220), textDim = C(150, 144, 134), red = C(178, 24, 30), redHi = C(226, 54, 50), redDeep = C(86, 10, 14),
                ink = C(12, 11, 11, A), ink2 = C(30, 27, 26, A);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const float m = 10.f;
    // panel and frame: steel band, gold hairline, corner pieces
    dl->AddRectFilledMultiColor(ImVec2(m, m), ImVec2(W - m, H - m), ink2, ink2, ink, ink);
    dl->AddRectFilledMultiColor(ImVec2(m, m), ImVec2(W - m, m + 110), C(0, 0, 0, A / 3), C(0, 0, 0, A / 3), C(0, 0, 0, 0), C(0, 0, 0, 0));
    dl->AddRect(ImVec2(m, m), ImVec2(W - m, H - m), steelDim, 6.f, 0, 6.f);
    dl->AddRect(ImVec2(m + 9, m + 9), ImVec2(W - m - 9, H - m - 9), goldDim, 2.f, 0, 1.2f);
    const float cl = 60.f, ci = m + 4;
    Corner(dl, ImVec2(ci, ci), 1, 1, cl, steel, steelDim);           Corner(dl, ImVec2(W - ci, ci), -1, 1, cl, steel, steelDim);
    Corner(dl, ImVec2(ci, H - ci), 1, -1, cl, steel, steelDim);      Corner(dl, ImVec2(W - ci, H - ci), -1, -1, cl, steel, steelDim);
    Diamond(dl, ImVec2(W * 0.5f, H - m - 2), 8.f, redDeep, steel);

    const float pad = fp * 1.4f;
    // mouse this frame
    const bool mouse = g_mVis;
    const ImVec2 mp(g_mx, g_my);
    const bool lClick = mouse && (g_mPress & 1), rClick = mouse && (g_mPress & 2), mClick = mouse && (g_mPress & 4);
    bool hot = false;   // the cursor is over something clickable
    auto In = [&](ImVec2 a, ImVec2 b) { return mouse && mp.x >= a.x && mp.x < b.x && mp.y >= a.y && mp.y < b.y; };
    bool clickUsed = false;
    {   // close button (top right, left of the corner piece)
        float cs = fp * 0.95f; ImVec2 c(W - m - 96.f, m + 38.f), a(c.x - cs * 0.5f, c.y - cs * 0.5f), b(c.x + cs * 0.5f, c.y + cs * 0.5f);
        bool hv = In(a, b); hot |= hv;
        Plate(dl, a, b, cs * 0.22f, hv ? redDeep : C(26, 24, 23, 220), hv ? gold : steelDim, 1.4f);
        float k = cs * 0.24f; ImU32 xc = hv ? C(250, 238, 214) : textDim;
        dl->AddLine(ImVec2(c.x - k, c.y - k), ImVec2(c.x + k, c.y + k), xc, 2.2f); dl->AddLine(ImVec2(c.x - k, c.y + k), ImVec2(c.x + k, c.y - k), xc, 2.2f);
        if (hv && lClick) { clickUsed = true; Close(); }
    }
    // title row: emblem + serif title (white with a crimson shadow), version / status underneath
    float y = m + fp * 0.5f;
    {
        ImGui::PushFont(g_fTitle);
        const char* t = g_s.title.c_str();
        ImVec2 ts = ImGui::CalcTextSize(t);
        float er = ts.y * 0.62f, gapE = fp * 0.5f;
        float tx = (W - (ts.x + er * 2 + gapE)) * 0.5f + er * 2 + gapE;
        Emblem(dl, ImVec2(tx - gapE - er, y + ts.y * 0.52f), er, steel, gold, red);
        dl->AddText(ImVec2(tx + 2, y + 3), C(70, 6, 8, 230), t);
        dl->AddText(ImVec2(tx, y), text, t);
        y += ts.y;
        ImGui::PopFont();
    }
    {
        std::string sub = g_s.subtitle;
        if (g_s.statusLine) { std::string st = g_s.statusLine(); sub = sub.empty() ? st : sub + "   \xC2\xB7   " + st; }
        if (!sub.empty()) { ImVec2 ss = ImGui::CalcTextSize(sub.c_str()); dl->AddText(ImVec2((W - ss.x) * 0.5f, y), textDim, sub.c_str()); y += ss.y; }
    }
    y += fp * 0.45f;
    // tabs: engraved plates in small capitals; the open one crimson with a gold edge and a stud under it
    auto pages = Options::Get().Pages();
    ImGui::PushFont(g_fTab);
    const float sp = fp * 0.08f, tpadX = fp * 0.6f, cut = fp * 0.28f;
    std::vector<std::string> up; std::vector<float> wv; float total = 0;
    for (auto& p : pages) { up.push_back(Upper(p)); wv.push_back(SpacedWidth(up.back(), sp) + tpadX * 2); total += wv.back(); }
    float gap = fp * 0.35f;
    float avail = W - 2 * pad, need = total + gap * (pages.size() ? pages.size() - 1 : 0);
    float shrink = need > avail ? avail / need : 1.f;
    float x = (W - need * shrink) * 0.5f;
    float tabH = ImGui::CalcTextSize("AG").y + fp * 0.42f;
    {   // a click on a tab opens it
        float tx = x;
        for (int p = 0; p < (int)pages.size(); ++p) {
            float w = wv[p] * shrink;
            if (In(ImVec2(tx, y), ImVec2(tx + w, y + tabH))) {
                hot = true;
                if (lClick && !clickUsed) { clickUsed = true; if (p != g_page) { g_page = p; g_sel = 0; g_manualScroll = false; } g_capture = -1; }
            }
            tx += w + gap * shrink;
        }
    }
    for (int p = 0; p < (int)pages.size(); ++p) {
        bool cur = p == g_page;
        float w = wv[p] * shrink;
        ImVec2 a(x, y), b(x + w, y + tabH);
        if (cur) {
            Plate(dl, a, b, cut, redDeep, gold, 2.f);
            dl->AddRectFilledMultiColor(ImVec2(a.x + 3, a.y + 3), ImVec2(b.x - 3, (a.y + b.y) * 0.5f), C(190, 40, 40, 90), C(190, 40, 40, 90), C(0, 0, 0, 0), C(0, 0, 0, 0));
            Diamond(dl, ImVec2((a.x + b.x) * 0.5f, b.y + 1), 5.5f, red, gold);
        } else Plate(dl, a, b, cut, C(26, 24, 23, 230), steelDim, 1.2f);
        float tw = SpacedWidth(up[p], sp);
        ImVec2 tp((a.x + b.x - tw) * 0.5f, a.y + (tabH - ImGui::CalcTextSize("AG").y) * 0.5f);
        SpacedText(dl, ImVec2(tp.x + 1.5f, tp.y + 1.5f), C(0, 0, 0, 200), up[p], sp);
        SpacedText(dl, tp, cur ? C(250, 238, 214) : textDim, up[p], sp);
        x += w + gap * shrink;
    }
    ImGui::PopFont();
    y += tabH + fp * 0.55f;
    Rule(dl, pad, W - pad, y, steelDim, redDeep);
    y += fp * 0.35f;

    // rows with section headers; scrolled so the selected row (and its header) stays in view
    auto items = PageItems(g_page);
    auto& opts = Options::Get().All();
    struct Entry { bool head; int item; std::string name; float y, h; };
    std::vector<Entry> ent;
    const float rowH = fp * 1.30f, headH = fp * 1.30f;
    float yy = 0; std::string lastG = "\x01";
    for (int r = 0; r < (int)items.size(); ++r) {
        const std::string& g = opts[items[r]].group;
        if (g != lastG) { lastG = g; if (!g.empty()) { ent.push_back({ true, -1, g, yy, headH }); yy += headH; } }
        ent.push_back({ false, r, "", yy, rowH }); yy += rowH;
    }
    const float listTop = y, listBottom = H - m - fp * 4.7f, viewH = listBottom - listTop;
    static float scroll = 0;
    static int scrollPage = -1; if (scrollPage != g_page) { scrollPage = g_page; scroll = 0; }
    if (g_mWheel != 0 && In(ImVec2(m, listTop - 4), ImVec2(W - m, listBottom + 2))) { scroll -= g_mWheel * rowH * 1.5f; g_manualScroll = true; }
    if (g_manualScroll) { if (yy <= viewH) scroll = 0; else scroll = (std::min)((std::max)(0.f, scroll), yy - viewH); }
    else {   // keep the selection (and the header right above it) inside the view
        float selY = 0, selTop = 0;
        for (size_t e = 0; e < ent.size(); ++e) if (!ent[e].head && ent[e].item == g_sel) { selY = ent[e].y; selTop = (e > 0 && ent[e - 1].head) ? ent[e - 1].y : selY; break; }
        if (selTop < scroll) scroll = selTop;
        if (selY + rowH > scroll + viewH) scroll = selY + rowH - viewH;
        if (yy <= viewH) scroll = 0; else scroll = (std::min)((std::max)(0.f, scroll), yy - viewH);
        if (g_sel == 0) scroll = 0;
    }
    dl->PushClipRect(ImVec2(m + 12, listTop - 4), ImVec2(W - m - 12, listBottom + 2), true);
    int stripe = 0;
    for (size_t ei = 0; ei < ent.size(); ++ei) {
        Entry& e = ent[ei];
        float ry = listTop + e.y - scroll;
        if (ry < listTop - 1 || ry + e.h > listBottom + 1) { if (!e.head) stripe++; continue; }   // whole rows only
        if (e.head && ei + 1 < ent.size() && ry + e.h + ent[ei + 1].h > listBottom + 1) continue;   // no header without its first row
        if (e.head) {   // section: small capitals in gold, a stud before it and a rule fading out after it
            ImGui::PushFont(g_fHead);
            std::string t = Upper(e.name);
            float th = ImGui::CalcTextSize("AG").y, tyy = ry + (e.h - th) * 0.62f;
            Diamond(dl, ImVec2(pad * 0.75f + 4, tyy + th * 0.5f), 4.5f, red, gold);
            SpacedText(dl, ImVec2(pad + 1, tyy + 1), C(0, 0, 0, 200), t, fp * 0.06f);
            SpacedText(dl, ImVec2(pad, tyy), gold, t, fp * 0.06f);
            float tw = SpacedWidth(t, fp * 0.06f);
            float lx0 = pad + tw + fp * 0.5f, lx1 = W - pad, ly = tyy + th * 0.55f;
            if (ei + 1 < ent.size() && !ent[ei + 1].head && opts[items[ent[ei + 1].item]].type == OptType::Hotkey) {   // column titles
                const float cw2 = fp * 5.4f, cw1 = fp * 4.8f, gapc = fp * 0.35f;
                const char* cols[2] = { "KEYBOARD", "CONTROLLER" };
                float cx[2] = { W - pad - cw2 - gapc - cw1 * 0.5f, W - pad - cw2 * 0.5f };
                for (int c = 0; c < 2; c++) { float w = SpacedWidth(cols[c], fp * 0.05f); SpacedText(dl, ImVec2(cx[c] - w * 0.5f, tyy), goldDim, cols[c], fp * 0.05f); }
                lx1 = W - pad - cw2 - gapc - cw1 - fp * 0.4f;
            }
            dl->AddRectFilledMultiColor(ImVec2(lx0, ly - 0.75f), ImVec2(lx1, ly + 0.75f), goldDim, C(0, 0, 0, 0), C(0, 0, 0, 0), goldDim);
            ImGui::PopFont();
            stripe = 0;
            continue;
        }
        Option& o = opts[items[e.item]];
        float rx0 = pad * 0.6f, rx1 = W - pad * 0.6f;
        const bool rowHover = In(ImVec2(rx0, ry - 4), ImVec2(rx1, ry + rowH - 6));
        if (rowHover) { hot = true; if (g_mMoved && g_capture < 0) g_sel = e.item; }
        bool sel = e.item == g_sel;
        if (rowHover && mClick && !clickUsed && g_capture < 0) { clickUsed = true; Options::Get().Reset(o); if (o.type == OptType::Hotkey) SaveNow(); }
        if (sel) {
            dl->AddRectFilledMultiColor(ImVec2(rx0, ry - 4), ImVec2(rx1, ry + rowH - 6), C(130, 18, 22, 175), C(60, 8, 10, 70), C(60, 8, 10, 70), C(130, 18, 22, 175));
            dl->AddLine(ImVec2(rx0, ry - 4), ImVec2(rx1, ry - 4), C(196, 162, 92, 110), 1.f);
            dl->AddLine(ImVec2(rx0, ry + rowH - 6), ImVec2(rx1, ry + rowH - 6), C(196, 162, 92, 110), 1.f);
            dl->AddRectFilled(ImVec2(rx0, ry - 4), ImVec2(rx0 + 5, ry + rowH - 6), redHi);
        } else if ((stripe & 1) == 1) dl->AddRectFilled(ImVec2(rx0, ry - 4), ImVec2(rx1, ry + rowH - 6), C(255, 240, 220, 6));
        stripe++;
        float lx = pad + fp * 0.35f;
        if (o.type == OptType::Hotkey && o.keepBound) lx += fp * 0.92f + fp * 0.45f;   // no clear button (the panel's own binding), label kept in line
        else if (o.type == OptType::Hotkey) {   // clear button: both bindings of this function off (pad: Left then A; mouse: click)
            const float bs = fp * 0.92f;
            ImVec2 a(lx, ry + (fp - bs) * 0.5f), b(lx + bs, ry + (fp + bs) * 0.5f);
            const bool any = (o.s && !o.s->empty()) || (o.s2 && !o.s2->empty());
            const bool hv = In(ImVec2(a.x - 3, a.y - 3), ImVec2(b.x + 3, b.y + 3)) && g_capture < 0;
            const bool foc = sel && g_onX && !mouse && g_capture < 0;
            if (hv) hot = true;
            ImU32 fill = (hv || foc) ? redDeep : C(24, 22, 21, 230);
            ImU32 edge = (hv || foc) ? gold : any ? steelDim : C(70, 66, 62);
            if (hv || foc) dl->AddRectFilled(ImVec2(a.x - 3, a.y - 3), ImVec2(b.x + 3, b.y + 3), C(226, 54, 50, 40), 4.f);   // glow
            Plate(dl, a, b, bs * 0.24f, fill, edge, (hv || foc) ? 2.f : 1.3f);
            const ImVec2 c((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f); const float k = bs * 0.22f;
            const ImU32 xc = (hv || foc) ? C(255, 240, 214) : any ? C(196, 162, 92) : C(92, 88, 82);   // gold X, dim when nothing is bound
            dl->AddLine(ImVec2(c.x - k, c.y - k), ImVec2(c.x + k, c.y + k), xc, 2.2f);
            dl->AddLine(ImVec2(c.x - k, c.y + k), ImVec2(c.x + k, c.y - k), xc, 2.2f);
            if (hv && (lClick || rClick) && !clickUsed) { clickUsed = true; g_sel = e.item; Options::Get().Clear(o, 3); SaveNow(); }
            lx = b.x + fp * 0.45f;
        }
        dl->AddText(ImVec2(lx, ry), sel ? C(255, 250, 240) : text, o.label.c_str());
        float right = W - pad;
        if (o.type == OptType::Bool) {
            float sh = fp * 0.74f, sw = sh * 2.1f, syy = ry + (fp - sh) * 0.5f + 2, sx = right - sw;
            bool on = o.b && *o.b;
            dl->AddRectFilled(ImVec2(sx, syy), ImVec2(sx + sw, syy + sh), on ? red : C(40, 36, 34), sh * 0.5f);
            dl->AddRect(ImVec2(sx, syy), ImVec2(sx + sw, syy + sh), on ? redHi : steelDim, sh * 0.5f, 0, 1.5f);
            float kx = on ? sx + sw - sh * 0.5f : sx + sh * 0.5f;
            dl->AddCircleFilled(ImVec2(kx, syy + sh * 0.5f), sh * 0.38f, on ? C(250, 240, 226) : C(120, 114, 106), 20);
            if (rowHover && (lClick || rClick) && !clickUsed) { clickUsed = true; Options::Get().Step(o, +1); }
            const char* lab = on ? "On" : "Off";
            ImVec2 ls = ImGui::CalcTextSize(lab);
            dl->AddText(ImVec2(sx - ls.x - 14, ry), on ? C(240, 200, 190) : textDim, lab);
            right = sx - ls.x - 14;
        } else if (o.type == OptType::Hotkey) {   // two cells: keyboard | controller
            const HotkeyHost& hk = GetHotkeyHost();
            const bool cap = g_capture == items[e.item];
            const float cw2 = fp * 5.4f, cw1 = fp * 4.8f, gapc = fp * 0.35f;
            const float pulse = 0.5f + 0.5f * sinf((float)ImGui::GetTime() * 6.f);
            auto cell = [&](float x0, float x1, const std::string* v, bool padCell) {
                ImVec2 a(x0, ry - 3), b(x1, ry + fp + 3);
                bool hv = In(a, b); hot |= hv;
                bool set = v && !v->empty();
                std::string t = cap ? (padCell ? "or a button" : "Press a key") : set ? (hk.show ? hk.show(*v, padCell) : *v) : "-";
                ImU32 fill = cap ? C(70, 12, 14, 230) : set ? C(42, 32, 22, 235) : C(22, 21, 20, 220);
                ImU32 edge = cap ? C(200 + (int)(50 * pulse), 60, 50) : hv ? gold : sel ? goldDim : steelDim;
                Plate(dl, a, b, 6.f, fill, edge, cap || hv ? 2.f : 1.2f);
                ImFont* f = g_fBody;
                if (cap || ImGui::CalcTextSize(t.c_str()).x > (x1 - x0) - 16) f = g_fSmall;
                ImGui::PushFont(f);
                ImVec2 ts = ImGui::CalcTextSize(t.c_str());
                ImU32 tc = cap ? C(255, 226, 190) : set ? (sel ? C(250, 232, 196) : C(226, 214, 192)) : C(100, 96, 90);
                dl->PushClipRect(a, b, true);
                dl->AddText(ImVec2((x0 + x1 - ts.x) * 0.5f, ry + (fp - ts.y) * 0.5f), tc, t.c_str());
                dl->PopClipRect();
                ImGui::PopFont();
                if (hv && !clickUsed && g_capture < 0) {
                    if (lClick) { clickUsed = true; g_sel = e.item; BeginCapture(items[e.item]); }
                    else if (rClick) { clickUsed = true; if (!o.keepBound) { Options::Get().Clear(o, padCell ? 2 : 1); SaveNow(); } }
                }
            };
            cell(right - cw2 - gapc - cw1, right - cw2 - gapc, o.s, false);
            cell(right - cw2, right, o.s2, true);
            if (rowHover && lClick && !clickUsed && g_capture < 0) { clickUsed = true; BeginCapture(items[e.item]); }
            right = right - cw2 - gapc - cw1;
        } else {
            std::string shown = o.type == OptType::Action ? "Run" : Options::Get().DisplayText(o);
            ImVec2 vs = ImGui::CalcTextSize(shown.c_str());
            float vx = right - vs.x - (sel && o.type != OptType::Action ? fp * 0.9f : 0);
            if (rowHover && !clickUsed) {   // Run: click; values: click the left arrow for back, the value / right arrow for next, right-click back
                if (o.type == OptType::Action) { if (lClick) { clickUsed = true; Options::Get().Activate(o); } }
                else if (lClick) { clickUsed = true; Options::Get().Step(o, (mp.x >= vx - fp * 1.3f && mp.x < vx - fp * 0.1f) ? -1 : +1); }   // left arrow: back; anywhere else: next
                else if (rClick) { clickUsed = true; Options::Get().Step(o, -1); }
            }
            if (o.type == OptType::Action) {
                Plate(dl, ImVec2(vx - 16, ry - 3), ImVec2(right + 2, ry + vs.y + 3), 6.f, sel ? redDeep : C(36, 18, 18), sel ? gold : C(120, 40, 36), 1.5f);
                dl->AddText(ImVec2(vx - 7, ry), sel ? C(255, 240, 228) : text, shown.c_str());
            } else {
                if (sel) {
                    dl->AddTriangleFilled(ImVec2(vx - fp * 0.9f, ry + fp * 0.5f), ImVec2(vx - fp * 0.45f, ry + fp * 0.22f), ImVec2(vx - fp * 0.45f, ry + fp * 0.78f), gold);
                    dl->AddTriangleFilled(ImVec2(right, ry + fp * 0.5f), ImVec2(right - fp * 0.45f, ry + fp * 0.22f), ImVec2(right - fp * 0.45f, ry + fp * 0.78f), gold);
                }
                dl->AddText(ImVec2(vx, ry), sel ? C(250, 232, 196) : C(214, 206, 192), shown.c_str());
            }
            right = vx - (sel ? fp * 1.1f : 0);
        }
        if (o.needsRestart) {
            const char* rs = "restart";
            ImVec2 rsz = ImGui::CalcTextSize(rs);
            Plate(dl, ImVec2(right - rsz.x - 34, ry), ImVec2(right - 14, ry + rsz.y), 5.f, C(60, 40, 14, 200), goldDim, 1.f);
            dl->AddText(ImVec2(right - rsz.x - 24, ry), C(226, 190, 120), rs);
        }
    }
    dl->PopClipRect();
    if (g_capture >= 0 && (lClick || rClick) && !clickUsed) { g_capture = -1; clickUsed = true; }
    if (yy > viewH) {   // scroll marks
        if (scroll > 1) Diamond(dl, ImVec2(W * 0.5f, listTop - 6), 5.f, gold, gold);
        if (scroll + viewH < yy - 1) Diamond(dl, ImVec2(W * 0.5f, listBottom + 4), 5.f, gold, gold);
    }
    if (items.empty()) dl->AddText(ImVec2(pad, listTop), textDim, "(nothing on this page)");
    // help box (smaller text, at most three lines) and the controls line
    const float hy = listBottom + fp * 0.55f;
    Rule(dl, pad, W - pad, hy - fp * 0.3f, steelDim, redDeep);
    const float keysY = H - m - fp * 1.45f;
    if (!items.empty()) {
        const Option& o = opts[items[(std::min)(g_sel, (int)items.size() - 1)]];
        std::string helpText = o.help;
        if (g_capture >= 0 && g_capture < (int)opts.size()) {
            int left = 8 - (int)((GetTickCount() - g_capStart) / 1000); if (left < 0) left = 0;
            char b[512];
            snprintf(b, sizeof b, "Binding \"%s\": press a key or Mouse 3 / 4 / 5 (with Ctrl / Shift / Alt if you like) or a controller button - hold "
                     "buttons together for a combination, it is set when you let go. Esc: cancel.%s (%d s)", opts[g_capture].label.c_str(),
                     opts[g_capture].keepBound ? "" : " Backspace: clear both.", left);
            helpText = b;
        } else if (g_onX && o.type == OptType::Hotkey && !mouse) {
            helpText = "Clear: A takes both bindings of \"" + o.label + "\" off - the keyboard key and the controller buttons (saved at once). Right: back to binding.";
        } else if (!g_note.empty() && GetTickCount() - g_noteTick < 5000) helpText = g_note + "  " + helpText;
        ImGui::PushFont(g_fSmall);
        if (!o.key.empty()) {   // the config key, small, on the rule at the right (where to find it in the config file)
            ImVec2 ksz = ImGui::CalcTextSize(o.key.c_str());
            float kx = W - pad - ksz.x, ky = hy - fp * 0.3f - ksz.y * 0.5f;
            dl->AddRectFilled(ImVec2(kx - 10, ky), ImVec2(W - pad + 4, ky + ksz.y), C(14, 13, 14, 255));
            dl->AddText(ImVec2(kx, ky), C(120, 114, 104), o.key.c_str());
        }
        const float boxTop = hy, boxBottom = keysY - fp * 0.15f;
        dl->PushClipRect(ImVec2(pad, boxTop), ImVec2(W - pad, boxBottom), true);
        // help longer than the box rolls up slowly (hold, roll a line at a time, hold at the end, start over)
        static int helpSel = -1, helpPage = -1; static double helpT0 = 0;
        const double now = ImGui::GetTime();
        if (helpSel != g_sel || helpPage != g_page) { helpSel = g_sel; helpPage = g_page; helpT0 = now; }
        const float wrapW = (W - pad - fp * 0.5f) - (pad + fp * 0.5f);
        const float textH = ImGui::CalcTextSize(helpText.c_str(), nullptr, false, wrapW).y, lineH = ImGui::GetTextLineHeightWithSpacing();
        const float over = textH - (boxBottom - boxTop - fp * 0.1f);
        float off = 0;
        if (over > 1) {
            const double hold = 3.0, perLine = 1.6, roll = ceil(over / lineH) * perLine, cycle = hold + roll + hold;
            double t = fmod(now - helpT0, cycle);
            off = t < hold ? 0.f : t < hold + roll ? (float)((t - hold) / roll) * over : over;
        }
        ImGui::SetCursorScreenPos(ImVec2(pad + fp * 0.5f, hy + fp * 0.1f - off));
        ImGui::PushTextWrapPos(W - pad - fp * 0.5f);
        ImGui::PushStyleColor(ImGuiCol_Text, textDim);
        ImGui::TextWrapped("%s", helpText.c_str());
        ImGui::PopStyleColor(); ImGui::PopTextWrapPos();
        dl->PopClipRect();
        ImGui::PopFont();
    }
    {
        const Option& so = opts[items.empty() ? 0 : items[(std::min)(g_sel, (int)items.size() - 1)]];
        bool hkRow = !items.empty() && so.type == OptType::Hotkey;
        bool hkKeep = hkRow && so.keepBound;
        const char* keys = g_capture >= 0 ? "Esc  cancel      Backspace  clear      click elsewhere  cancel"
                         : mouse && hkKeep ? "Click  change the binding     Middle  default     Wheel  scroll"
                         : mouse && hkRow ? "Click  bind     Click X  clear both     Right-click a cell  clear it     Middle  default"
                         : mouse ? "Click  change     Right-click  back / clear     Wheel  scroll     Middle  default"
                         : hkRow && g_onX ? "A  clear both      Right  back      Y  default      LB / RB  tab      B  close"
                         : hkKeep ? "A  change the binding      Y  default      LB / RB  tab      B  close"
                         : hkRow ? "A  bind      Left  clear button      X  clear      Y  default      B  close"
                         : "A  change      Y  default      LB / RB  tab      B  close";
        ImVec2 ks = ImGui::CalcTextSize(keys);
        bool small = ks.x > W - 2 * pad - fp * 2;   // keep clear of the corner pieces
        if (small) { ImGui::PushFont(g_fSmall); ks = ImGui::CalcTextSize(keys); }
        dl->AddText(ImVec2((W - ks.x) * 0.5f, keysY + (small ? fp * 0.1f : 0)), goldDim, keys);
        if (small) ImGui::PopFont();
    }
    if (mouse) Cursor(dl, mp, fp * 1.65f, hot, (g_mBtn & 1) != 0);
    g_mPress = 0; g_mWheel = 0; g_mMoved = false;
    ImGui::End();
    ImGui::PopStyleColor();
    ImGui::Render();
}

bool IsOpen() { return g_open; }
void SetOpen(bool open) { if (open == g_open) return; if (open) { g_open = true; OnOpen(); input::SetBlocking(true); } else Close(); }
void MouseInput(float dx, float dy, float wheel, unsigned buttons, unsigned pressed) {
    if (!g_open) return;
    if (dx != 0 || dy != 0) { g_mVis = true; g_mMoved = true; }
    g_mx = (std::max)(0.f, (std::min)((float)g_s.texW - 1, g_mx + dx));
    g_my = (std::max)(0.f, (std::min)((float)g_s.texH - 1, g_my + dy));
    g_mBtn = buttons;
    if (!g_mVis && (pressed || wheel != 0)) { g_mVis = true; return; }   // hidden cursor: a click / scroll only shows it where it is
    g_mWheel += wheel; g_mPress |= pressed;
}
bool Capturing() { return g_open && g_capture >= 0; }

} } } // namespace vrkit::menu::core

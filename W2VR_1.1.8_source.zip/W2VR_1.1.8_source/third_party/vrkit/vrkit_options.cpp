#include "vrkit_options.h"
#include <windows.h>
#include <cstdio>
#include <cstdarg>
#include <cmath>
#include <algorithm>

namespace vrkit {

static void DefaultLog(const char* m) { OutputDebugStringA(m); OutputDebugStringA("\n"); }
static void (*g_log)(const char*) = DefaultLog;
void SetLog(void (*fn)(const char*)) { g_log = fn ? fn : DefaultLog; }
void Log(const char* fmt, ...) {
    char buf[1024]; va_list a; va_start(a, fmt); vsnprintf(buf, sizeof(buf), fmt, a); va_end(a);
    g_log(buf);
}

Options& Options::Get() { static Options o; return o; }
static HotkeyHost g_hk;
void SetHotkeyHost(const HotkeyHost& h) { g_hk = h; }
const HotkeyHost& GetHotkeyHost() { return g_hk; }

Option& Options::Add(Option o) {
    o.defaultText = ValueText(o);
    if (o.type == OptType::Hotkey && o.s2) o.defaultText2 = *o.s2;
    m_opts.push_back(std::move(o));
    return m_opts.back();
}
Option& Options::AddBool(const char* page, const char* key, const char* label, bool* v, const char* help, std::function<void()> cb) {
    Option o; o.page = page; o.key = key; o.label = label; o.help = help; o.type = OptType::Bool; o.b = v; o.onChange = cb; return Add(o);
}
Option& Options::AddInt(const char* page, const char* key, const char* label, int* v, int mn, int mx, int st, const char* help, std::function<void()> cb) {
    Option o; o.page = page; o.key = key; o.label = label; o.help = help; o.type = OptType::Int; o.i = v; o.minV = (float)mn; o.maxV = (float)mx; o.step = (float)st; o.onChange = cb; return Add(o);
}
Option& Options::AddFloat(const char* page, const char* key, const char* label, float* v, float mn, float mx, float st, int dec, const char* help, std::function<void()> cb) {
    Option o; o.page = page; o.key = key; o.label = label; o.help = help; o.type = OptType::Float; o.f = v; o.minV = mn; o.maxV = mx; o.step = st; o.decimals = dec; o.onChange = cb; return Add(o);
}
Option& Options::AddChoice(const char* page, const char* key, const char* label, std::string* v, std::vector<std::string> choices, const char* help, std::function<void()> cb) {
    Option o; o.page = page; o.key = key; o.label = label; o.help = help; o.type = OptType::Choice; o.s = v; o.choices = std::move(choices); o.onChange = cb; return Add(o);
}
Option& Options::AddAction(const char* page, const char* label, std::function<void()> run, const char* help) {
    Option o; o.page = page; o.label = label; o.help = help; o.type = OptType::Action; o.onChange = run; return Add(o);
}

Option& Options::AddHotkey(const char* page, const char* kk, const char* kp, const char* label, std::string* kb, std::string* pad, const char* help) {
    Option o; o.page = page; o.key = kk; o.key2 = kp; o.label = label; o.help = help; o.type = OptType::Hotkey; o.s = kb; o.s2 = pad;
    o.onChange = [] { if (g_hk.changed) g_hk.changed(); };
    return Add(o);
}
void Options::Clear(Option& o, int which) {
    if (o.type != OptType::Hotkey || o.keepBound) return;
    bool ch = false;
    if ((which & 1) && o.s && !o.s->empty()) { o.s->clear(); ch = true; }
    if ((which & 2) && o.s2 && !o.s2->empty()) { o.s2->clear(); ch = true; }
    if (ch) Changed(o);
}
std::string Options::SetBinding(Option& o, bool pad, const std::string& v) {
    std::string moved;
    if (o.type != OptType::Hotkey) return moved;
    std::string* dst = pad ? o.s2 : o.s;
    if (!dst) return moved;
    if (!v.empty())
        for (auto& x : m_opts) {   // a keepBound hotkey keeps its bindings: refuse
            if (&x == &o || x.type != OptType::Hotkey || !x.keepBound) continue;
            std::string* other = pad ? x.s2 : x.s;
            if (other && *other == v) return "!" + x.label;
        }
    if (!v.empty())
        for (auto& x : m_opts) {
            if (&x == &o || x.type != OptType::Hotkey) continue;
            std::string* other = pad ? x.s2 : x.s;
            if (other && *other == v) { other->clear(); moved = x.label; m_dirty = true; }
        }
    if (*dst != v) { *dst = v; Changed(o); }
    else if (!moved.empty() && o.onChange) o.onChange();
    return moved;
}

int Options::Arrange(const std::vector<Place>& layout) {
    std::vector<Option> out; out.reserve(m_opts.size());
    std::vector<bool> used(m_opts.size(), false);
    int missing = 0;
    for (auto& pl : layout) {
        bool found = false;
        for (size_t k = 0; k < m_opts.size(); ++k) {
            if (used[k]) continue;
            const Option& o = m_opts[k];
            bool match = pl.id[0] == '@' ? (o.type == OptType::Action && o.label == pl.id + 1) : (!o.key.empty() && o.key == pl.id);
            if (!match) continue;
            used[k] = true; found = true;
            Option c = m_opts[k]; c.page = pl.page; c.group = pl.group ? pl.group : "";
            out.push_back(std::move(c));
            break;
        }
        if (!found) { missing++; Log("vrkit: layout entry '%s' matches no option", pl.id); }
    }
    for (size_t k = 0; k < m_opts.size(); ++k) if (!used[k]) out.push_back(m_opts[k]);
    m_opts.swap(out);
    return missing;
}

std::vector<std::string> Options::Pages() const {
    std::vector<std::string> p;
    for (auto& o : m_opts) if (std::find(p.begin(), p.end(), o.page) == p.end()) p.push_back(o.page);
    return p;
}

void Options::Changed(Option& o) {
    if (!o.key.empty()) m_dirty = true;
    if (o.onChange) o.onChange();
}

void Options::Step(Option& o, int dir) {
    switch (o.type) {
    case OptType::Bool: *o.b = !*o.b; break;
    case OptType::Int: { int v = *o.i + dir * (int)o.step; v = (std::max)((int)o.minV, (std::min)((int)o.maxV, v)); if (v == *o.i) return; *o.i = v; break; }
    case OptType::Float: {
        float v = *o.f + dir * o.step;
        float q = powf(10.f, (float)o.decimals); v = roundf(v * q) / q;            // keep values tidy (0.75, not 0.7500001)
        v = (std::max)(o.minV, (std::min)(o.maxV, v));
        if (v == *o.f) return;
        *o.f = v; break;
    }
    case OptType::Choice: {
        if (o.choices.empty()) return;
        auto it = std::find(o.choices.begin(), o.choices.end(), *o.s);
        int n = (int)o.choices.size(), k = it == o.choices.end() ? 0 : (int)(it - o.choices.begin());
        k = ((k + dir) % n + n) % n;
        *o.s = o.choices[k]; break;
    }
    case OptType::Action: case OptType::Hotkey: return;
    }
    Changed(o);
}
void Options::Activate(Option& o) {
    if (o.type == OptType::Action) { if (o.onChange) o.onChange(); return; }
    Step(o, +1);   // bool: toggle, choice: next, number: one step up
}
void Options::Reset(Option& o) {
    if (o.type == OptType::Hotkey) {
        bool ch = false;
        if (o.s && *o.s != o.defaultText) { SetBinding(o, false, o.defaultText); ch = true; }
        if (o.s2 && *o.s2 != o.defaultText2) { SetBinding(o, true, o.defaultText2); ch = true; }
        (void)ch; return;
    }
    if (o.type == OptType::Action || ValueText(o) == o.defaultText) return;
    switch (o.type) {
    case OptType::Bool: *o.b = o.defaultText == "true"; break;
    case OptType::Int: *o.i = atoi(o.defaultText.c_str()); break;
    case OptType::Float: *o.f = (float)atof(o.defaultText.c_str()); break;
    case OptType::Choice: *o.s = o.defaultText; break;
    default: break;
    }
    Changed(o);
}

std::string Options::ValueText(const Option& o) const {
    char b[64];
    switch (o.type) {
    case OptType::Bool: return *o.b ? "true" : "false";
    case OptType::Int: snprintf(b, sizeof(b), "%d", *o.i); return b;
    case OptType::Float: snprintf(b, sizeof(b), "%.*f", o.decimals, *o.f); return b;
    case OptType::Choice: return *o.s;
    case OptType::Hotkey: return o.s ? *o.s : "";
    default: return "";
    }
}
std::string Options::DisplayText(const Option& o) const {
    switch (o.type) {
    case OptType::Bool: return *o.b ? "On" : "Off";
    case OptType::Choice: {
        for (size_t k = 0; k < o.choices.size(); ++k)
            if (o.choices[k] == *o.s) return k < o.choiceLabels.size() ? o.choiceLabels[k] : o.choices[k];
        return *o.s;
    }
    case OptType::Action: return "";
    case OptType::Hotkey: {
        auto sh = [&](const std::string* v, bool pad) { if (!v || v->empty()) return std::string("-"); return g_hk.show ? g_hk.show(*v, pad) : *v; };
        return sh(o.s, false) + "  |  " + sh(o.s2, true);
    }
    default: return ValueText(o);
    }
}

bool Options::Save(const std::wstring& path) {
    std::string all;
    if (FILE* f = _wfopen(path.c_str(), L"rb")) {
        char buf[4096]; size_t k;
        while ((k = fread(buf, 1, sizeof(buf), f)) > 0) all.append(buf, k);
        fclose(f);
    }
    bool crlf = all.find("\r\n") != std::string::npos || all.empty();
    // every (key, value) pair to write: an option's key, and a hotkey's controller key as well
    struct KV { std::string k, v; bool written; };
    std::vector<KV> kv;
    for (auto& o : m_opts) {
        if (!o.key.empty()) kv.push_back({ o.key, ValueText(o), false });
        if (o.type == OptType::Hotkey && !o.key2.empty() && o.s2) kv.push_back({ o.key2, *o.s2, false });
    }
    std::string out;
    size_t pos = 0;
    while (pos < all.size()) {
        size_t e = all.find('\n', pos); if (e == std::string::npos) e = all.size();
        std::string line = all.substr(pos, e - pos);
        bool cr = !line.empty() && line.back() == '\r'; if (cr) line.pop_back();
        size_t a = line.find_first_not_of(" \t");
        size_t eq = line.find('=');
        if (a != std::string::npos && line[a] != '#' && eq != std::string::npos) {
            std::string key = line.substr(a, eq - a);
            while (!key.empty() && (key.back() == ' ' || key.back() == '\t')) key.pop_back();
            for (auto& e : kv) if (e.k == key) { line = key + " = " + e.v; e.written = true; break; }
        }
        out += line; if (cr || (crlf && e < all.size())) out += "\r"; if (e < all.size()) out += "\n";
        pos = e + 1;
    }
    std::string nl = crlf ? "\r\n" : "\n";
    bool header = false;
    for (auto& e : kv) {
        if (e.written) continue;
        if (!header) { if (!out.empty() && out.back() != '\n') out += nl; out += nl + "# --- set from the in-game menu ---" + nl; header = true; }
        out += e.k + " = " + e.v + nl;
    }
    FILE* f = _wfopen(path.c_str(), L"wb");
    if (!f) { Log("vrkit: cannot write config"); return false; }
    fwrite(out.data(), 1, out.size(), f); fclose(f);
    m_dirty = false;
    return true;
}

} // namespace vrkit
